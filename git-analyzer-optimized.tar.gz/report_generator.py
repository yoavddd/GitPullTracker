import pandas as pd
import logging
import os
from typing import Dict, List
from datetime import datetime
import json
from tabulate import tabulate

class ReportGenerator:
    """
    Generates reports for pull request analysis
    """
    
    def __init__(self, output_dir: str):
        self.output_dir = output_dir
        self.logger = logging.getLogger(__name__)
        
        # Create output directory
        os.makedirs(output_dir, exist_ok=True)
        
        self.logger.info(f"Report generator initialized. Output directory: {output_dir}")
    
    def generate_comprehensive_report(self, 
                                    super_project_info: Dict,
                                    submodule_changes: Dict[str, Dict],
                                    super_project_prs: List[Dict],
                                    submodule_prs: Dict[str, List[Dict]]) -> Dict[str, str]:
        """
        Generate comprehensive report with all findings
        """
        self.logger.info("Generating comprehensive report...")
        
        report_files = {}
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        try:
            # 1. Generate super project report
            super_report_file = self._generate_super_project_report(
                super_project_info, super_project_prs, timestamp
            )
            report_files['super_project'] = super_report_file
            
            # 2. Generate individual submodule reports
            submodule_report_files = {}
            for submodule_path, prs in submodule_prs.items():
                if prs:  # Only generate report if there are PRs
                    report_file = self._generate_submodule_report(
                        submodule_path, submodule_changes.get(submodule_path, {}), prs, timestamp
                    )
                    submodule_report_files[submodule_path] = report_file
            
            report_files['submodules'] = submodule_report_files
            
            # 3. Generate combined summary report
            summary_file = self._generate_summary_report(
                super_project_info, submodule_changes, super_project_prs, submodule_prs, timestamp
            )
            report_files['summary'] = summary_file
            
            # 4. Generate combined CSV with all pull requests
            combined_file = self._generate_combined_pr_report(
                super_project_info, super_project_prs, submodule_prs, timestamp
            )
            report_files['combined_prs'] = combined_file
            
            # 5. Generate JSON data export
            json_file = self._generate_json_export(
                super_project_info, submodule_changes, super_project_prs, submodule_prs, timestamp
            )
            report_files['json_export'] = json_file
            
            self.logger.info(f"Generated {len(report_files)} report files")
            return report_files
            
        except Exception as e:
            self.logger.error(f"Error generating comprehensive report: {str(e)}")
            raise
    
    def _generate_super_project_report(self, project_info: Dict, prs: List[Dict], timestamp: str) -> str:
        """
        Generate super project pull request report
        """
        filename = f"super_project_prs_{timestamp}.csv"
        filepath = os.path.join(self.output_dir, filename)
        
        try:
            self.logger.info(f"Generating super project report: {filepath}")
            
            if not prs:
                # Create empty report with headers
                df = pd.DataFrame(columns=[
                    'PR_ID', 'Title', 'Created_By', 'Created_Date', 'Completed_Date',
                    'Source_Branch', 'Target_Branch', 'Merge_Commit', 'Status', 'URL'
                ])
                self.logger.warning("No pull requests found for super project")
            else:
                # Create DataFrame from PR data
                df = pd.DataFrame([
                    {
                        'PR_ID': pr['id'],
                        'Title': pr['title'],
                        'Created_By': pr['created_by'],
                        'Created_Date': pr['created_date'],
                        'Completed_Date': pr['completed_date'],
                        'Source_Branch': pr['source_branch'],
                        'Target_Branch': pr['target_branch'],
                        'Merge_Commit': pr['merge_commit'],
                        'Status': pr['status'],
                        'URL': pr['url']
                    }
                    for pr in prs
                ])
            
            # Save to CSV
            df.to_csv(filepath, index=False)
            
            # Also create a formatted text report
            text_filename = f"super_project_prs_{timestamp}.txt"
            text_filepath = os.path.join(self.output_dir, text_filename)
            
            with open(text_filepath, 'w') as f:
                f.write("SUPER PROJECT PULL REQUEST REPORT\n")
                f.write("=" * 50 + "\n\n")
                f.write(f"Analysis Period: {project_info.get('from_commit', 'N/A')} -> {project_info.get('to_commit', 'N/A')}\n")
                f.write(f"Total Commits in Range: {project_info.get('commit_count', 0)}\n")
                f.write(f"Pull Requests Found: {len(prs)}\n\n")
                
                if prs:
                    f.write(tabulate(df, headers='keys', tablefmt='grid', showindex=False))
                else:
                    f.write("No pull requests found in the specified commit range.\n")
            
            self.logger.info(f"Super project report saved: {filepath}")
            return filepath
            
        except Exception as e:
            self.logger.error(f"Error generating super project report: {str(e)}")
            raise
    
    def _generate_submodule_report(self, submodule_path: str, changes: Dict, prs: List[Dict], timestamp: str) -> str:
        """
        Generate individual submodule pull request report
        """
        safe_filename = submodule_path.replace('/', '_').replace('\\', '_')
        filename = f"submodule_{safe_filename}_prs_{timestamp}.csv"
        filepath = os.path.join(self.output_dir, filename)
        
        try:
            self.logger.info(f"Generating submodule report for '{submodule_path}': {filepath}")
            
            if not prs:
                # Create empty report with headers
                df = pd.DataFrame(columns=[
                    'PR_ID', 'Title', 'Created_By', 'Created_Date', 'Completed_Date',
                    'Source_Branch', 'Target_Branch', 'Merge_Commit', 'Status', 'URL'
                ])
                self.logger.warning(f"No pull requests found for submodule: {submodule_path}")
            else:
                # Create DataFrame from PR data
                df = pd.DataFrame([
                    {
                        'PR_ID': pr['id'],
                        'Title': pr['title'],
                        'Created_By': pr['created_by'],
                        'Created_Date': pr['created_date'],
                        'Completed_Date': pr['completed_date'],
                        'Source_Branch': pr['source_branch'],
                        'Target_Branch': pr['target_branch'],
                        'Merge_Commit': pr['merge_commit'],
                        'Status': pr['status'],
                        'URL': pr['url']
                    }
                    for pr in prs
                ])
            
            # Save to CSV
            df.to_csv(filepath, index=False)
            
            # Also create a formatted text report
            text_filename = f"submodule_{safe_filename}_prs_{timestamp}.txt"
            text_filepath = os.path.join(self.output_dir, text_filename)
            
            with open(text_filepath, 'w') as f:
                f.write(f"SUBMODULE PULL REQUEST REPORT: {submodule_path}\n")
                f.write("=" * 60 + "\n\n")
                f.write(f"Submodule Path: {submodule_path}\n")
                f.write(f"Commit Range: {changes.get('old_commit', 'N/A')} -> {changes.get('new_commit', 'N/A')}\n")
                f.write(f"Pull Requests Found: {len(prs)}\n\n")
                
                if prs:
                    f.write(tabulate(df, headers='keys', tablefmt='grid', showindex=False))
                else:
                    f.write("No pull requests found in the specified commit range.\n")
            
            self.logger.info(f"Submodule report saved: {filepath}")
            return filepath
            
        except Exception as e:
            self.logger.error(f"Error generating submodule report for '{submodule_path}': {str(e)}")
            raise
    
    def _generate_summary_report(self, 
                               super_project_info: Dict,
                               submodule_changes: Dict[str, Dict],
                               super_project_prs: List[Dict],
                               submodule_prs: Dict[str, List[Dict]],
                               timestamp: str) -> str:
        """
        Generate combined summary report
        """
        filename = f"combined_summary_{timestamp}.txt"
        filepath = os.path.join(self.output_dir, filename)
        
        try:
            self.logger.info(f"Generating summary report: {filepath}")
            
            with open(filepath, 'w') as f:
                f.write("PULL REQUEST ANALYSIS SUMMARY REPORT\n")
                f.write("=" * 50 + "\n\n")
                
                # Analysis overview
                f.write("ANALYSIS OVERVIEW\n")
                f.write("-" * 20 + "\n")
                f.write(f"Super Project Commit Range: {super_project_info.get('from_commit', 'N/A')} -> {super_project_info.get('to_commit', 'N/A')}\n")
                f.write(f"Total Commits in Super Project: {super_project_info.get('commit_count', 0)}\n")
                f.write(f"Submodules with Changes: {len(submodule_changes)}\n")
                f.write(f"Analysis Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
                
                # Super project summary
                f.write("SUPER PROJECT PULL REQUESTS\n")
                f.write("-" * 30 + "\n")
                f.write(f"Total PRs Found: {len(super_project_prs)}\n")
                if super_project_prs:
                    for pr in super_project_prs:
                        f.write(f"  • PR #{pr['id']}: {pr['title']}\n")
                f.write("\n")
                
                # Submodule summary
                f.write("SUBMODULE PULL REQUESTS\n")
                f.write("-" * 25 + "\n")
                
                total_submodule_prs = sum(len(prs) for prs in submodule_prs.values())
                f.write(f"Total Submodule PRs Found: {total_submodule_prs}\n\n")
                
                for submodule_path, changes in submodule_changes.items():
                    f.write(f"Submodule: {submodule_path}\n")
                    f.write(f"  Commit Range: {changes.get('old_commit', 'N/A')} -> {changes.get('new_commit', 'N/A')}\n")
                    
                    prs = submodule_prs.get(submodule_path, [])
                    f.write(f"  PRs Found: {len(prs)}\n")
                    
                    if prs:
                        for pr in prs:
                            f.write(f"    • PR #{pr['id']}: {pr['title']}\n")
                    else:
                        f.write("    • No pull requests found\n")
                    f.write("\n")
                
                # Overall statistics
                f.write("OVERALL STATISTICS\n")
                f.write("-" * 18 + "\n")
                f.write(f"Total Pull Requests: {len(super_project_prs) + total_submodule_prs}\n")
                f.write(f"Super Project PRs: {len(super_project_prs)}\n")
                f.write(f"Submodule PRs: {total_submodule_prs}\n")
                f.write(f"Submodules Analyzed: {len(submodule_changes)}\n")
            
            self.logger.info(f"Summary report saved: {filepath}")
            return filepath
            
        except Exception as e:
            self.logger.error(f"Error generating summary report: {str(e)}")
            raise
    
    def _generate_json_export(self,
                            super_project_info: Dict,
                            submodule_changes: Dict[str, Dict],
                            super_project_prs: List[Dict],
                            submodule_prs: Dict[str, List[Dict]],
                            timestamp: str) -> str:
        """
        Generate JSON export of all data
        """
        filename = f"analysis_data_{timestamp}.json"
        filepath = os.path.join(self.output_dir, filename)
        
        try:
            self.logger.info(f"Generating JSON export: {filepath}")
            
            export_data = {
                'analysis_metadata': {
                    'timestamp': datetime.now().isoformat(),
                    'super_project_info': super_project_info,
                    'total_submodules_changed': len(submodule_changes),
                    'total_super_project_prs': len(super_project_prs),
                    'total_submodule_prs': sum(len(prs) for prs in submodule_prs.values())
                },
                'super_project': {
                    'commit_info': super_project_info,
                    'pull_requests': super_project_prs
                },
                'submodules': {
                    submodule_path: {
                        'changes': changes,
                        'pull_requests': submodule_prs.get(submodule_path, [])
                    }
                    for submodule_path, changes in submodule_changes.items()
                }
            }
            
            with open(filepath, 'w') as f:
                json.dump(export_data, f, indent=2, default=str)
            
            self.logger.info(f"JSON export saved: {filepath}")
            return filepath
            
        except Exception as e:
            self.logger.error(f"Error generating JSON export: {str(e)}")
            raise
    
    def _generate_combined_pr_report(self, 
                                   super_project_info: Dict, 
                                   super_project_prs: List[Dict], 
                                   submodule_prs: Dict[str, List[Dict]], 
                                   timestamp: str) -> str:
        """
        Generate combined CSV report with all pull requests (super project + submodules)
        """
        filename = f"all_pull_requests_{timestamp}.csv"
        filepath = os.path.join(self.output_dir, filename)
        
        try:
            self.logger.info(f"Generating combined PR report: {filepath}")
            
            # Combine all pull requests into one list
            all_prs = []
            
            # Add super project PRs
            for pr in super_project_prs:
                pr_data = {
                    'Repository': 'Super Project',
                    'Repository_Path': super_project_info.get('repository_path', 'N/A'),
                    'PR_ID': pr['id'],
                    'Title': pr['title'],
                    'Created_By': pr['created_by'],
                    'Created_Date': pr['created_date'],
                    'Completed_Date': pr['completed_date'],
                    'Source_Branch': pr['source_branch'],
                    'Target_Branch': pr['target_branch'],
                    'Merge_Commit': pr.get('merge_commit', 'N/A'),
                    'Status': pr['status'],
                    'URL': pr.get('url', 'N/A')
                }
                all_prs.append(pr_data)
            
            # Add submodule PRs
            for submodule_path, prs in submodule_prs.items():
                for pr in prs:
                    pr_data = {
                        'Repository': f'Submodule: {submodule_path}',
                        'Repository_Path': submodule_path,
                        'PR_ID': pr['id'],
                        'Title': pr['title'],
                        'Created_By': pr['created_by'],
                        'Created_Date': pr['created_date'],
                        'Completed_Date': pr['completed_date'],
                        'Source_Branch': pr['source_branch'],
                        'Target_Branch': pr['target_branch'],
                        'Merge_Commit': pr.get('merge_commit', 'N/A'),
                        'Status': pr['status'],
                        'URL': pr.get('url', 'N/A')
                    }
                    all_prs.append(pr_data)
            
            # Create DataFrame and save
            if all_prs:
                df = pd.DataFrame(all_prs)
                # Sort by created date for better organization
                df['Created_Date'] = pd.to_datetime(df['Created_Date'])
                df = df.sort_values('Created_Date')
                df['Created_Date'] = df['Created_Date'].dt.strftime('%Y-%m-%d %H:%M:%S')
                df['Completed_Date'] = pd.to_datetime(df['Completed_Date']).dt.strftime('%Y-%m-%d %H:%M:%S')
            else:
                # Create empty DataFrame with headers
                df = pd.DataFrame(columns=[
                    'Repository', 'Repository_Path', 'PR_ID', 'Title', 'Created_By', 
                    'Created_Date', 'Completed_Date', 'Source_Branch', 'Target_Branch', 
                    'Merge_Commit', 'Status', 'URL'
                ])
                self.logger.warning("No pull requests found for combined report")
            
            # Save to CSV
            df.to_csv(filepath, index=False)
            
            self.logger.info(f"Combined PR report saved: {filepath}")
            self.logger.info(f"Total pull requests in combined report: {len(all_prs)}")
            
            return filepath
            
        except Exception as e:
            self.logger.error(f"Error generating combined PR report: {str(e)}")
            raise
    
    def print_console_summary(self,
                            super_project_info: Dict,
                            submodule_changes: Dict[str, Dict],
                            super_project_prs: List[Dict],
                            submodule_prs: Dict[str, List[Dict]]):
        """
        Print a summary to console
        """
        try:
            print("\n" + "=" * 60)
            print("PULL REQUEST ANALYSIS RESULTS")
            print("=" * 60)
            
            print(f"\nSuper Project Commit Range: {super_project_info.get('from_commit', 'N/A')} -> {super_project_info.get('to_commit', 'N/A')}")
            print(f"Submodules with Changes: {len(submodule_changes)}")
            print(f"Super Project PRs: {len(super_project_prs)}")
            
            total_submodule_prs = sum(len(prs) for prs in submodule_prs.values())
            print(f"Total Submodule PRs: {total_submodule_prs}")
            
            if submodule_changes:
                print("\nSubmodule Changes:")
                for submodule_path, changes in submodule_changes.items():
                    prs_count = len(submodule_prs.get(submodule_path, []))
                    print(f"  • {submodule_path}: {prs_count} PRs ({changes.get('old_commit', 'N/A')[:8]} -> {changes.get('new_commit', 'N/A')[:8]})")
            
            print("\n" + "=" * 60)
            
        except Exception as e:
            self.logger.error(f"Error printing console summary: {str(e)}")
