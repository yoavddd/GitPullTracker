# Jira Bug Integration System

## Overview

This is a comprehensive Python-based system designed to process CSV files containing bug data and automatically create corresponding issues in Jira. The system features intelligent WBS (Work Breakdown Structure) categorization, advanced duplicate detection, comprehensive logging, and a professional API interface. It's built to Google-level enterprise standards with robust error handling, test modes, and extensive configurability.

## System Architecture

The system follows a modular, enterprise-grade architecture with clear separation of concerns:

- **Command-line Interface**: Entry point with comprehensive argument handling
- **Professional API Interface**: Enterprise-grade programmatic interface for integration
- **Configuration Management**: JSON-based configuration with schema validation and environment variable support
- **CSV Processing**: Pandas-based processing with intelligent column mapping and data validation
- **Jira Integration**: Full REST API integration with authentication, error handling, and retry logic
- **WBS Structure Manager**: Intelligent bug categorization and epic assignment based on content analysis
- **Duplicate Detection**: Advanced pattern-based duplicate detection with caching and JQL queries
- **Comprehensive Logging**: Multi-level logging with structured output, performance tracking, and debug capabilities

The architecture prioritizes enterprise-level maintainability, testability, scalability, and extensibility through dependency injection, clear module boundaries, and comprehensive error handling.

## Key Components

### 1. Main Entry Point (`main.py`)
- Command-line argument parsing with comprehensive options
- Process orchestration with error handling
- Test mode and dry-run mode support
- WBS integration and enhanced logging

### 2. Professional API Interface (`api_interface.py`)
- Enterprise-grade programmatic interface
- Comprehensive system validation
- Bulk operations and analysis capabilities
- Structured logging and error reporting

### 3. Configuration Manager (`config_manager.py`)
- JSON schema validation for configuration files
- Environment variable override support for security
- Centralized configuration management with validation

### 4. CSV Processor (`csv_processor.py`)
- Flexible column mapping to handle various CSV formats
- Intelligent column name normalization
- Comprehensive data validation and cleaning
- Statistical analysis and quality reporting

### 5. Jira Integration (`jira_integration.py`)
- Full REST API communication with Jira
- Support for both password and API token authentication
- Advanced issue creation with customizable templates
- Error handling and retry logic

### 6. WBS Structure Manager (`wbs_structure_manager.py`)
- Intelligent bug categorization based on content analysis
- Automatic epic and component assignment
- Priority determination based on keywords and context
- WBS structure validation and export capabilities

### 7. Duplicate Checker (`duplicate_checker.py`)
- Advanced pattern-based duplicate detection using "QC ID" patterns
- In-memory caching with JQL fallback queries
- Performance optimization and statistical reporting
- Test mode support for development

### 8. Logger Setup (`logger_setup.py`)
- Multi-level configurable logging (DEBUG, INFO, WARNING, ERROR)
- Structured logging with performance tracking
- Console and file output with different formatters
- API operation logging and timing

## Data Flow

1. **Configuration Loading**: System reads JSON configuration file and validates against schema
2. **CSV Processing**: CSV file is loaded and validated, with flexible column mapping
3. **Duplicate Check**: System queries Jira to build cache of existing issues
4. **Issue Creation**: For each non-duplicate bug, a Jira issue is created using the configured template
5. **Logging**: All operations are logged with appropriate detail levels

## External Dependencies

### Python Libraries
- `pandas`: CSV data processing and manipulation
- `requests`: HTTP client for Jira REST API communication
- `jsonschema`: Configuration validation
- `pathlib`: Modern path handling
- `pytest`: Unit testing framework

### Jira Integration
- Jira REST API v2/v3
- Authentication via username/password or API tokens
- Project-specific issue creation
- Custom field support

## Deployment Strategy

The system is designed as a standalone Python application that can be deployed in several ways:

1. **Command-line Tool**: Direct execution with Python interpreter
2. **Containerized**: Docker deployment for consistent environments
3. **Scheduled Jobs**: Integration with cron or task schedulers
4. **CI/CD Pipeline**: Automated execution as part of testing workflows

Configuration is externalized through JSON files and environment variables, making it suitable for different deployment environments without code changes.

## Recent Changes

### June 30, 2025 - Complete System Implementation
- ✅ Built comprehensive Jira Bug Integration System with enterprise-level features
- ✅ Implemented intelligent WBS (Work Breakdown Structure) categorization system
- ✅ Added advanced duplicate detection using "QC ID" patterns with caching
- ✅ Created professional API interface (`api_interface.py`) for programmatic access
- ✅ Enhanced CSV processing with flexible column mapping and validation
- ✅ Implemented test mode for safe development and testing
- ✅ Added comprehensive logging with structured output and performance tracking
- ✅ Created demonstration script (`demo.py`) showing all system capabilities
- ✅ Built WBS Structure Manager for automatic bug categorization into UI, Backend, Performance, and Security categories
- ✅ Added priority determination based on content analysis
- ✅ Implemented automatic epic and component assignment
- ✅ Created comprehensive test data and validation
- ✅ Added full documentation (README.md) with usage examples and API reference

## User Preferences

Preferred communication style: Simple, everyday language.