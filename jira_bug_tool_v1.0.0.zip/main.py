#!/usr/bin/env python3
"""
JIRA Bug Creation Tool
A command-line tool to process CSV bug data and create JIRA issues with duplicate checking.
"""

import argparse
import sys
import os
import logging
from typing import List, Dict, Any

from jira_client import JiraClient
from csv_processor import CSVProcessor
from config_manager import ConfigManager
from logger_config import setup_logging


def main():
    """Main entry point for the JIRA bug creation tool."""
    parser = argparse.ArgumentParser(
        description='Process CSV bug data and create JIRA issues with duplicate checking'
    )
    parser.add_argument(
        '--csv-file',
        required=True,
        help='Path to the CSV file containing bug data'
    )
    parser.add_argument(
        '--config-file',
        default='config.json',
        help='Path to the JSON configuration file (default: config.json)'
    )
    parser.add_argument(
        '--log-level',
        default='INFO',
        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
        help='Set the logging level (default: INFO)'
    )
    parser.add_argument(
        '--dry-run',
        action='store_true',
        help='Perform a dry run without creating actual JIRA issues'
    )
    parser.add_argument(
        '--skip-connection-test',
        action='store_true',
        help='Skip JIRA connection test (useful for offline CSV validation)'
    )
    
    args = parser.parse_args()
    
    # Setup logging
    setup_logging(args.log_level)
    logger = logging.getLogger(__name__)
    
    logger.info("Starting JIRA Bug Creation Tool")
    logger.info(f"CSV file: {args.csv_file}")
    logger.info(f"Config file: {args.config_file}")
    logger.info(f"Dry run: {args.dry_run}")
    logger.info(f"Skip connection test: {args.skip_connection_test}")
    
    try:
        # Validate input files
        if not os.path.exists(args.csv_file):
            logger.error(f"CSV file not found: {args.csv_file}")
            sys.exit(1)
            
        if not os.path.exists(args.config_file):
            logger.error(f"Config file not found: {args.config_file}")
            sys.exit(1)
        
        # Load configuration
        logger.info("Loading configuration...")
        config_manager = ConfigManager(args.config_file)
        config = config_manager.load_config()
        
        # Initialize JIRA client
        logger.info("Initializing JIRA client...")
        jira_client = JiraClient(config)
        
        # Test JIRA connection (unless skipped)
        if not args.skip_connection_test:
            logger.info("Testing JIRA connection...")
            if not jira_client.test_connection():
                logger.error("Failed to connect to JIRA. Please check your credentials and URL.")
                if not args.dry_run:
                    sys.exit(1)
                else:
                    logger.warning("Connection failed, but continuing with dry run mode...")
        else:
            logger.info("Skipping JIRA connection test as requested")
        
        # Process CSV file
        logger.info("Processing CSV file...")
        csv_processor = CSVProcessor(args.csv_file)
        bugs = csv_processor.process_csv()
        
        if not bugs:
            logger.warning("No bugs found in CSV file.")
            sys.exit(0)
        
        logger.info(f"Found {len(bugs)} bugs in CSV file")
        
        # Process each bug
        created_count = 0
        skipped_count = 0
        error_count = 0
        
        for i, bug in enumerate(bugs, 1):
            logger.info(f"Processing bug {i}/{len(bugs)}: {bug.get('defect_id', 'Unknown ID')}")
            
            try:
                # Check if bug already exists (only if not skipping connection test)
                defect_id = bug.get('defect_id', '')
                if not defect_id:
                    logger.warning(f"Bug {i} has no defect_id, skipping")
                    skipped_count += 1
                    continue
                
                if not args.skip_connection_test:
                    search_pattern = f"QC ID {defect_id}"
                    logger.debug(f"Searching for existing bug with pattern: {search_pattern}")
                    
                    existing_issue = jira_client.search_existing_issue(search_pattern)
                    
                    if existing_issue:
                        logger.info(f"Bug {defect_id} already exists in JIRA: {existing_issue['key']}")
                        skipped_count += 1
                        continue
                else:
                    logger.debug(f"Skipping duplicate check for bug {defect_id} (connection test disabled)")
                
                # Create new bug
                if args.dry_run:
                    logger.info(f"[DRY RUN] Would create bug for defect_id: {defect_id}")
                    created_count += 1
                else:
                    logger.info(f"Creating new bug for defect_id: {defect_id}")
                    issue_key = jira_client.create_issue(bug)
                    
                    if issue_key:
                        logger.info(f"Successfully created bug: {issue_key}")
                        created_count += 1
                    else:
                        logger.error(f"Failed to create bug for defect_id: {defect_id}")
                        error_count += 1
                        
            except Exception as e:
                logger.error(f"Error processing bug {defect_id}: {str(e)}")
                error_count += 1
                continue
        
        # Summary
        logger.info("=" * 50)
        logger.info("PROCESSING SUMMARY")
        logger.info("=" * 50)
        logger.info(f"Total bugs processed: {len(bugs)}")
        logger.info(f"Bugs created: {created_count}")
        logger.info(f"Bugs skipped (already exist): {skipped_count}")
        logger.info(f"Errors: {error_count}")
        
        if error_count > 0:
            logger.warning(f"Completed with {error_count} errors. Check logs for details.")
            sys.exit(1)
        else:
            logger.info("All bugs processed successfully!")
            
    except KeyboardInterrupt:
        logger.info("Process interrupted by user")
        sys.exit(130)
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        logger.debug("Full error details:", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
