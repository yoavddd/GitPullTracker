"""
CSV Processor Module
Handles CSV file parsing and data validation.
"""

import csv
import logging
import pandas as pd
from typing import List, Dict, Any, Optional


class CSVProcessor:
    """Processor for CSV bug data files."""
    
    def __init__(self, csv_file_path: str):
        """Initialize CSV processor with file path."""
        self.logger = logging.getLogger(__name__)
        self.csv_file_path = csv_file_path
        self.logger.info(f"Initialized CSV processor for file: {csv_file_path}")
    
    def process_csv(self) -> List[Dict[str, Any]]:
        """Process CSV file and return list of bug dictionaries."""
        try:
            self.logger.info("Starting CSV processing...")
            
            # Read CSV file using pandas for better handling
            df = pd.read_csv(self.csv_file_path)
            
            # Log basic info about the CSV
            self.logger.info(f"CSV contains {len(df)} rows and {len(df.columns)} columns")
            self.logger.info(f"Columns: {list(df.columns)}")
            
            # Clean column names (remove spaces, lowercase, replace special chars)
            df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_').str.replace('[^a-zA-Z0-9_]', '', regex=True)
            
            # Remove empty rows
            df = df.dropna(how='all')
            
            # Convert DataFrame to list of dictionaries
            bugs = []
            for index, row in df.iterrows():
                bug_data = {}
                
                # Convert each column to string and clean
                for col in df.columns:
                    value = row[col]
                    if pd.isna(value):
                        bug_data[col] = ''
                    else:
                        bug_data[col] = str(value).strip()
                
                # Validate required fields
                if self._validate_bug_data(bug_data, index + 1):
                    bugs.append(bug_data)
                else:
                    self.logger.warning(f"Skipping invalid bug at row {index + 1}")
            
            self.logger.info(f"Successfully processed {len(bugs)} valid bugs from CSV")
            return bugs
            
        except FileNotFoundError:
            self.logger.error(f"CSV file not found: {self.csv_file_path}")
            return []
        except pd.errors.EmptyDataError:
            self.logger.error("CSV file is empty")
            return []
        except pd.errors.ParserError as e:
            self.logger.error(f"CSV parsing error: {str(e)}")
            return []
        except Exception as e:
            self.logger.error(f"Unexpected error processing CSV: {str(e)}")
            return []
    
    def _validate_bug_data(self, bug_data: Dict[str, Any], row_number: int) -> bool:
        """Validate bug data for required fields."""
        required_fields = ['defect_id']
        
        for field in required_fields:
            if field not in bug_data or not bug_data[field]:
                self.logger.warning(f"Row {row_number}: Missing required field '{field}'")
                return False
        
        # Additional validation
        defect_id = bug_data.get('defect_id', '')
        if len(defect_id.strip()) == 0:
            self.logger.warning(f"Row {row_number}: Empty defect_id")
            return False
        
        return True
    
    def get_csv_headers(self) -> List[str]:
        """Get CSV headers for validation."""
        try:
            with open(self.csv_file_path, 'r', newline='', encoding='utf-8') as file:
                reader = csv.reader(file)
                headers = next(reader)
                return [header.strip() for header in headers]
        except Exception as e:
            self.logger.error(f"Error reading CSV headers: {str(e)}")
            return []
    
    def validate_csv_structure(self) -> bool:
        """Validate CSV file structure."""
        try:
            headers = self.get_csv_headers()
            
            if not headers:
                self.logger.error("CSV file has no headers")
                return False
            
            # Check for required columns (case-insensitive)
            headers_lower = [h.lower() for h in headers]
            required_columns = ['defect_id', 'summary']
            
            missing_columns = []
            for col in required_columns:
                if col not in headers_lower:
                    missing_columns.append(col)
            
            if missing_columns:
                self.logger.error(f"CSV missing required columns: {missing_columns}")
                return False
            
            self.logger.info("CSV structure validation passed")
            return True
            
        except Exception as e:
            self.logger.error(f"CSV structure validation failed: {str(e)}")
            return False
    
    def preview_csv(self, num_rows: int = 5) -> List[Dict[str, Any]]:
        """Preview first few rows of CSV for debugging."""
        try:
            df = pd.read_csv(self.csv_file_path, nrows=num_rows)
            df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_').str.replace('[^a-zA-Z0-9_]', '', regex=True)
            
            preview_data = []
            for index, row in df.iterrows():
                row_data = {}
                for col in df.columns:
                    value = row[col]
                    if pd.isna(value):
                        row_data[col] = ''
                    else:
                        row_data[col] = str(value).strip()
                preview_data.append(row_data)
            
            return preview_data
            
        except Exception as e:
            self.logger.error(f"Error previewing CSV: {str(e)}")
            return []
