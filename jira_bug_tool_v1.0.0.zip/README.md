# JIRA Bug Creation Tool

A comprehensive Python command-line tool for processing CSV bug data and creating JIRA issues with duplicate checking and extensive logging.

## Features

- **CSV Processing**: Parse CSV files containing bug data with flexible column mapping
- **JIRA Integration**: Full JIRA REST API integration with Basic Authentication
- **Duplicate Prevention**: Automatic checking for existing bugs using "QC ID" pattern matching
- **Batch Processing**: Process multiple bugs efficiently with error handling
- **Comprehensive Logging**: Detailed logging for debugging and monitoring
- **Configuration Management**: JSON-based configuration with environment variable support
- **Epic Integration**: Automatically link created bugs to specified epics
- **Dry Run Mode**: Test functionality without creating actual JIRA issues

## Installation

1. **Extract the deployment ZIP** to your desired directory
2. **Install required Python packages**:
   ```bash
   pip install requests pandas
   ```

3. **Optional: Create a virtual environment**:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   pip install requests pandas
   ```

## Configuration

### 1. Edit config.json

Update the configuration file with your JIRA instance details:

```json
{
  "jira": {
    "url": "https://your-jira-instance.com",
    "username": "your-username",
    "password": "your-password",
    "project_key": "YOUR_PROJECT",
    "epic_key": "YOUR_EPIC_KEY",
    "structure_board_id": "5062"
  },
  "bug_template": {
    "issue_type": "Bug",
    "priority": "Medium",
    "assignee": "default-assignee",
    "reporter": "default-reporter",
    "components": ["Component1", "Component2"],
    "labels": ["automated-import", "qc-bug"],
    "custom_fields": {
      "customfield_10100": "QC Import"
    }
  }
}
