"""
JIRA Client Module
Handles all JIRA API interactions including authentication, searching, and issue creation.
"""

import base64
import json
import logging
import requests
from typing import Dict, Any, Optional, List
from urllib.parse import urljoin


class JiraClient:
    """Client for interacting with JIRA REST API."""
    
    def __init__(self, config: Dict[str, Any]):
        """Initialize JIRA client with configuration."""
        self.logger = logging.getLogger(__name__)
        self.config = config
        
        # Extract JIRA configuration
        jira_config = config.get('jira', {})
        self.base_url = jira_config.get('url', '').rstrip('/')
        self.username = jira_config.get('username', '')
        self.password = jira_config.get('password', '')
        self.project_key = jira_config.get('project_key', '')
        self.epic_key = jira_config.get('epic_key', '')
        self.structure_board_id = jira_config.get('structure_board_id', '')
        
        # Setup authentication
        self.session = requests.Session()
        self.session.timeout = 30
        self.session.verify = False  # Disable SSL certificate verification
        
        if self.username and self.password:
            # Use Basic Authentication with base64 encoding as provided by user
            user_pass = f"{self.username}:{self.password}"
            encoded_credentials = base64.b64encode(user_pass.encode()).decode()
            
            # Set headers for every session as requested by user
            self.session.headers.update({
                'Authorization': f'Basic {encoded_credentials}',
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'User-Agent': 'JIRA-Bug-Tool/1.0.0'
            })
            
            self.logger.info(f"Initialized JIRA client for {self.base_url}")
            self.logger.debug(f"Headers set: Authorization=Basic [HIDDEN], Content-Type=application/json, Accept=application/json")
        else:
            self.logger.error("JIRA credentials not provided")
            raise ValueError("JIRA username and password are required")
    
    def test_connection(self) -> bool:
        """Test connection to JIRA instance."""
        try:
            url = urljoin(self.base_url, '/rest/api/2/myself')
            self.logger.debug(f"Testing connection to: {url}")
            
            response = self.session.get(url)
            
            if response.status_code == 200:
                user_info = response.json()
                self.logger.info(f"Successfully connected to JIRA as: {user_info.get('displayName', 'Unknown')}")
                return True
            else:
                self.logger.error(f"Connection test failed: {response.status_code} - {response.text}")
                return False
                
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Connection test failed with exception: {str(e)}")
            return False
    
    def search_existing_issue(self, search_pattern: str) -> Optional[Dict[str, Any]]:
        """Search for existing issue containing the search pattern in summary."""
        try:
            # Extract defect ID from the search pattern
            defect_id = search_pattern.replace("QC ID ", "").strip()
            
            # Build multiple search patterns to handle different formats
            search_patterns = [
                f"QC ID {defect_id}",     # QC ID 12345
                f"QC ID# {defect_id}",    # QC ID# 12345
                f"QC ID #{defect_id}",    # QC ID #12345
                f"QC ID${defect_id}$",    # QC ID$12345$
                f"QC ID {defect_id}:",    # QC ID 12345:
                f"QC ID-{defect_id}",     # QC ID-12345
            ]
            
            # Try each pattern until we find a match
            for pattern in search_patterns:
                jql = f'project = "{self.project_key}" AND summary ~ "{pattern}"'
                
                url = urljoin(self.base_url, '/rest/api/2/search')
                params = {
                    'jql': jql,
                    'fields': 'key,summary,status',
                    'maxResults': 1
                }
                
                self.logger.debug(f"Searching with JQL: {jql}")
                
                response = self.session.get(url, params=params)
                
                if response.status_code == 200:
                    result = response.json()
                    issues = result.get('issues', [])
                    
                    if issues:
                        issue = issues[0]
                        self.logger.debug(f"Found existing issue with pattern '{pattern}': {issue['key']} - {issue['fields']['summary']}")
                        return issue
                else:
                    self.logger.debug(f"Search with pattern '{pattern}' failed: {response.status_code}")
                    
            self.logger.debug("No existing issue found with any pattern")
            return None
                
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Search request failed: {str(e)}")
            return None
        except Exception as e:
            self.logger.error(f"Unexpected error during search: {str(e)}")
            return None
    
    def create_issue(self, bug_data: Dict[str, Any]) -> Optional[str]:
        """Create a new JIRA issue from bug data."""
        try:
            # Get bug template from config
            bug_template = self.config.get('bug_template', {})
            
            # Extract defect ID for the summary
            defect_id = bug_data.get('defect_id', '')
            original_summary = bug_data.get('summary', 'No summary provided')
            
            # Create issue summary with QC ID pattern (using # format as requested)
            summary = f"QC ID# {defect_id} - {original_summary}"
            
            # Build description from all CSV columns
            description = self._build_description(bug_data)
            
            # Build issue data
            issue_data = {
                'fields': {
                    'project': {'key': self.project_key},
                    'summary': summary,
                    'description': description,
                    'issuetype': {'name': bug_template.get('issue_type', 'Bug')},
                }
            }
            
            # Add assignee if specified
            assignee = bug_template.get('assignee')
            if assignee:
                issue_data['fields']['assignee'] = {'name': assignee}
            
            # Add reporter if specified
            reporter = bug_template.get('reporter')
            if reporter:
                issue_data['fields']['reporter'] = {'name': reporter}
            
            # Add priority if specified
            priority = bug_template.get('priority')
            if priority:
                issue_data['fields']['priority'] = {'name': priority}
            
            # Add components if specified
            components = bug_template.get('components', [])
            if components:
                issue_data['fields']['components'] = [{'name': comp} for comp in components]
            
            # Add labels if specified
            labels = bug_template.get('labels', [])
            if labels:
                issue_data['fields']['labels'] = labels
            
            # Add custom fields from template
            custom_fields = bug_template.get('custom_fields', {})
            for field_id, field_value in custom_fields.items():
                issue_data['fields'][field_id] = field_value
            
            # Add epic link if specified
            if self.epic_key:
                # Try different epic link field names (depends on JIRA configuration)
                epic_fields = ['customfield_10014', 'customfield_10008', 'customfield_10006']
                for epic_field in epic_fields:
                    try:
                        issue_data['fields'][epic_field] = self.epic_key
                        break
                    except:
                        continue
            
            self.logger.debug(f"Creating issue with data: {json.dumps(issue_data, indent=2)}")
            
            # Create the issue
            url = urljoin(self.base_url, '/rest/api/2/issue')
            response = self.session.post(url, json=issue_data)
            
            if response.status_code == 201:
                result = response.json()
                issue_key = result.get('key')
                self.logger.info(f"Successfully created issue: {issue_key}")
                return issue_key
            else:
                self.logger.error(f"Issue creation failed: {response.status_code} - {response.text}")
                return None
                
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Issue creation request failed: {str(e)}")
            return None
        except Exception as e:
            self.logger.error(f"Unexpected error during issue creation: {str(e)}")
            return None
    
    def _build_description(self, bug_data: Dict[str, Any]) -> str:
        """Build detailed description from bug data."""
        description_parts = []
        
        # Add header
        description_parts.append("== Bug Details ==")
        description_parts.append("")
        
        # Add all CSV columns
        for key, value in bug_data.items():
            if value and str(value).strip():
                # Format key for display
                display_key = key.replace('_', ' ').title()
                description_parts.append(f"*{display_key}:* {value}")
        
        # Add footer
        description_parts.append("")
        description_parts.append("== Additional Information ==")
        description_parts.append("This issue was automatically created from CSV import.")
        
        return "\n".join(description_parts)
    
    def get_project_info(self) -> Optional[Dict[str, Any]]:
        """Get project information for validation."""
        try:
            url = urljoin(self.base_url, f'/rest/api/2/project/{self.project_key}')
            response = self.session.get(url)
            
            if response.status_code == 200:
                return response.json()
            else:
                self.logger.error(f"Failed to get project info: {response.status_code} - {response.text}")
                return None
                
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Project info request failed: {str(e)}")
            return None
    
    def get_issue_types(self) -> List[Dict[str, Any]]:
        """Get available issue types for the project."""
        try:
            url = urljoin(self.base_url, f'/rest/api/2/project/{self.project_key}')
            response = self.session.get(url)
            
            if response.status_code == 200:
                project_info = response.json()
                return project_info.get('issueTypes', [])
            else:
                self.logger.error(f"Failed to get issue types: {response.status_code} - {response.text}")
                return []
                
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Issue types request failed: {str(e)}")
            return []
