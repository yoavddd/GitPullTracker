"""
Jira Web Interface Creator
Creates Jira bugs through web interface automation and URL generation
"""

import logging
import json
import csv
from typing import Dict, Any, List
from urllib.parse import urlencode, quote
import webbrowser
import os
from pathlib import Path

class JiraWebInterface:
    """Creates Jira bugs through web interface methods"""
    
    def __init__(self, jira_config: Dict[str, Any]):
        """Initialize web interface creator"""
        self.jira_config = jira_config
        self.jira_url = jira_config.get('url', '').rstrip('/')
        self.project_key = jira_config.get('project_key', '')
        self.logger = logging.getLogger(__name__)
    
    def generate_create_bug_urls(self, bugs_data: List[Dict[str, Any]]) -> List[Dict[str, str]]:
        """
        Generate Jira URLs that pre-populate the create issue form
        
        Args:
            bugs_data: List of bug dictionaries from CSV
            
        Returns:
            List of dictionaries with bug info and URLs
        """
        urls = []
        
        for i, bug in enumerate(bugs_data):
            # Prepare URL parameters for Jira's create issue form
            params = {
                'pid': self._get_project_id(),  # Project ID
                'issuetype': '1',  # Bug issue type ID (usually 1)
                'summary': self._clean_text(bug.get('summary', f'Bug {i+1}')),
                'description': self._format_description(bug),
                'priority': self._map_priority(bug.get('priority', 'Medium')),
                'components': bug.get('component', ''),
                'labels': f"QC-Import,QC-{bug.get('qc_number', i+1)}"
            }
            
            # Remove empty parameters
            params = {k: v for k, v in params.items() if v}
            
            # Create the URL
            base_url = f"{self.jira_url}/secure/CreateIssue!default.jspa"
            query_string = urlencode(params)
            full_url = f"{base_url}?{query_string}"
            
            urls.append({
                'bug_number': bug.get('qc_number', f'Bug-{i+1}'),
                'summary': bug.get('summary', 'No summary'),
                'url': full_url,
                'manual_data': self._prepare_manual_data(bug)
            })
        
        return urls
    
    def create_html_report(self, bugs_data: List[Dict[str, Any]], output_file: str = 'jira_bugs_report.html') -> str:
        """
        Create an HTML report with clickable links to create Jira bugs
        
        Args:
            bugs_data: List of bug dictionaries
            output_file: Output HTML file path
            
        Returns:
            Path to created HTML file
        """
        urls = self.generate_create_bug_urls(bugs_data)
        
        html_content = f"""
<!DOCTYPE html>
<html>
<head>
    <title>Jira Bug Creation Report</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; }}
        .header {{ background-color: #0052cc; color: white; padding: 20px; border-radius: 5px; }}
        .bug-item {{ border: 1px solid #ddd; margin: 10px 0; padding: 15px; border-radius: 5px; }}
        .bug-number {{ font-weight: bold; color: #0052cc; }}
        .create-button {{ 
            background-color: #0052cc; 
            color: white; 
            padding: 10px 20px; 
            text-decoration: none; 
            border-radius: 3px; 
            display: inline-block; 
            margin: 10px 0;
        }}
        .create-button:hover {{ background-color: #003d99; }}
        .manual-data {{ background-color: #f5f5f5; padding: 10px; margin: 10px 0; border-radius: 3px; }}
        .instructions {{ background-color: #fff3cd; padding: 15px; margin: 20px 0; border-radius: 5px; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>Jira Bug Creation Report</h1>
        <p>Project: {self.project_key} | Total Bugs: {len(bugs_data)}</p>
    </div>
    
    <div class="instructions">
        <h3>Instructions:</h3>
        <ol>
            <li>Click the "Create in Jira" button for each bug</li>
            <li>Jira will open with the form pre-populated</li>
            <li>Review and adjust the information as needed</li>
            <li>Click "Create" in Jira to save the bug</li>
        </ol>
    </div>
"""

        for i, url_data in enumerate(urls):
            html_content += f"""
    <div class="bug-item">
        <div class="bug-number">Bug #{i+1}: {url_data['bug_number']}</div>
        <h3>{url_data['summary']}</h3>
        
        <a href="{url_data['url']}" target="_blank" class="create-button">Create in Jira</a>
        
        <div class="manual-data">
            <strong>Manual Entry Data (if needed):</strong><br>
            {url_data['manual_data']}
        </div>
    </div>
"""

        html_content += """
</body>
</html>
"""

        # Write to file
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        self.logger.info(f"HTML report created: {output_file}")
        return output_file
    
    def create_csv_import_file(self, bugs_data: List[Dict[str, Any]], output_file: str = 'jira_import.csv') -> str:
        """
        Create a CSV file formatted for Jira's CSV import feature
        
        Args:
            bugs_data: List of bug dictionaries
            output_file: Output CSV file path
            
        Returns:
            Path to created CSV file
        """
        # Jira CSV import format
        fieldnames = [
            'Summary',
            'Issue Type',
            'Priority',
            'Description',
            'Component/s',
            'Labels',
            'Reporter',
            'Assignee'
        ]
        
        with open(output_file, 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            
            for bug in bugs_data:
                row = {
                    'Summary': self._clean_text(bug.get('summary', 'Imported Bug')),
                    'Issue Type': 'Bug',
                    'Priority': self._map_priority(bug.get('priority', 'Medium')),
                    'Description': self._format_description(bug),
                    'Component/s': bug.get('component', ''),
                    'Labels': f"QC-Import QC-{bug.get('qc_number', 'Unknown')}",
                    'Reporter': self.jira_config.get('default_reporter', ''),
                    'Assignee': self.jira_config.get('default_assignee', '')
                }
                writer.writerow(row)
        
        self.logger.info(f"Jira import CSV created: {output_file}")
        return output_file
    
    def create_jira_rest_calls(self, bugs_data: List[Dict[str, Any]], output_file: str = 'jira_rest_calls.txt') -> str:
        """
        Create cURL commands for REST API calls
        
        Args:
            bugs_data: List of bug dictionaries
            output_file: Output file path
            
        Returns:
            Path to created file
        """
        with open(output_file, 'w') as f:
            f.write("# Jira REST API cURL Commands\n")
            f.write("# Replace YOUR_USERNAME and YOUR_PASSWORD with actual credentials\n\n")
            
            for i, bug in enumerate(bugs_data):
                issue_data = {
                    "fields": {
                        "project": {"key": self.project_key},
                        "summary": self._clean_text(bug.get('summary', f'Bug {i+1}')),
                        "description": self._format_description(bug),
                        "issuetype": {"name": "Bug"},
                        "priority": {"name": self._map_priority(bug.get('priority', 'Medium'))},
                        "labels": [f"QC-Import", f"QC-{bug.get('qc_number', i+1)}"]
                    }
                }
                
                json_data = json.dumps(issue_data, indent=2)
                
                f.write(f"# Bug {i+1}: {bug.get('qc_number', 'Unknown')}\n")
                f.write(f"curl -D- -u YOUR_USERNAME:YOUR_PASSWORD -X POST \\\n")
                f.write(f"  --data '{json_data}' \\\n")
                f.write(f"  -H \"Content-Type: application/json\" \\\n")
                f.write(f"  \"{self.jira_url}/rest/api/2/issue/\"\n\n")
        
        self.logger.info(f"cURL commands created: {output_file}")
        return output_file
    
    def _get_project_id(self) -> str:
        """Get project ID - simplified version"""
        return self.project_key
    
    def _clean_text(self, text: str) -> str:
        """Clean text for URL encoding"""
        if not text:
            return ""
        return str(text).strip()[:250]  # Limit length
    
    def _format_description(self, bug: Dict[str, Any]) -> str:
        """Format bug description"""
        description_parts = []
        
        if bug.get('description'):
            description_parts.append(f"Description: {bug['description']}")
        
        if bug.get('qc_number'):
            description_parts.append(f"QC Number: {bug['qc_number']}")
        
        if bug.get('steps'):
            description_parts.append(f"Steps to Reproduce: {bug['steps']}")
        
        if bug.get('expected_result'):
            description_parts.append(f"Expected Result: {bug['expected_result']}")
        
        if bug.get('actual_result'):
            description_parts.append(f"Actual Result: {bug['actual_result']}")
        
        if bug.get('environment'):
            description_parts.append(f"Environment: {bug['environment']}")
        
        return "\\n\\n".join(description_parts)
    
    def _map_priority(self, priority: str) -> str:
        """Map priority to Jira values"""
        priority_map = {
            'critical': 'Highest',
            'high': 'High', 
            'medium': 'Medium',
            'low': 'Low',
            'minor': 'Lowest'
        }
        return priority_map.get(str(priority).lower(), 'Medium')
    
    def _prepare_manual_data(self, bug: Dict[str, Any]) -> str:
        """Prepare manual entry data"""
        data_parts = []
        
        for key, value in bug.items():
            if value and key not in ['summary']:
                data_parts.append(f"<strong>{key.replace('_', ' ').title()}:</strong> {value}")
        
        return "<br>".join(data_parts)


def create_web_interface_solution(csv_file: str, config_file: str) -> Dict[str, str]:
    """
    Create web interface solution for Jira bug creation
    
    Args:
        csv_file: Path to CSV file with bug data
        config_file: Path to configuration file
        
    Returns:
        Dictionary with paths to created files
    """
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    
    # Load configuration
    with open(config_file, 'r') as f:
        config = json.load(f)
    
    # Load CSV data
    bugs_data = []
    with open(csv_file, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            bugs_data.append(row)
    
    logger.info(f"Loaded {len(bugs_data)} bugs from {csv_file}")
    
    # Create web interface
    web_interface = JiraWebInterface(config['jira'])
    
    # Create all output files
    outputs = {}
    
    # HTML report with clickable links
    outputs['html_report'] = web_interface.create_html_report(bugs_data)
    
    # CSV for Jira import
    outputs['csv_import'] = web_interface.create_csv_import_file(bugs_data)
    
    # cURL commands
    outputs['curl_commands'] = web_interface.create_jira_rest_calls(bugs_data)
    
    logger.info("Web interface solution created successfully!")
    return outputs


if __name__ == "__main__":
    # Example usage
    outputs = create_web_interface_solution(
        'sample_data/bugs_input.csv',
        'config/jira_config.json'
    )
    
    print("Created files:")
    for name, path in outputs.items():
        print(f"  {name}: {path}")