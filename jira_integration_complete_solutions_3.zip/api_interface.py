"""
API Interface Module
Provides a programmatic interface for the Jira Bug Integration System
"""

import json
from typing import Dict, Any, List, Optional
from pathlib import Path

from jira_integration import JiraIntegrator
from csv_processor import CSVProcessor
from config_manager import ConfigManager
from duplicate_checker import DuplicateChecker
from wbs_structure_manager import WBSStructureManager
from logger_setup import setup_logger, StructuredLogger


class JiraBugIntegrationAPI:
    """
    Main API class for Jira Bug Integration System
    Provides a programmatic interface for senior developers at Google-level standards
    """
    
    def __init__(self, config_path: str, test_mode: bool = False):
        """
        Initialize the Jira Bug Integration API
        
        Args:
            config_path: Path to JSON configuration file
            test_mode: If True, run in test mode without actual Jira API calls
        """
        self.logger = setup_logger()
        self.structured_logger = StructuredLogger('api')
        self.test_mode = test_mode
        
        # Initialize components
        self.structured_logger.log_operation_start("API_INITIALIZATION", {"config_path": config_path, "test_mode": test_mode})
        
        try:
            self.config_manager = ConfigManager(config_path)
            self.config = self.config_manager.load_config()
            
            self.csv_processor = CSVProcessor()
            self.jira_integrator = JiraIntegrator(self.config['jira'])
            self.duplicate_checker = DuplicateChecker(self.jira_integrator, test_mode=test_mode)
            self.wbs_manager = WBSStructureManager(self.config.get('wbs_structure', {}))
            
            self.structured_logger.log_operation_success("API_INITIALIZATION", {"components": "all_initialized"})
            
        except Exception as e:
            self.structured_logger.log_operation_failure("API_INITIALIZATION", str(e))
            raise
    
    def validate_system(self) -> Dict[str, Any]:
        """
        Comprehensive system validation
        
        Returns:
            Dictionary containing validation results for all components
        """
        self.structured_logger.log_operation_start("SYSTEM_VALIDATION")
        
        validation_results = {
            'overall_status': 'PENDING',
            'config_validation': {},
            'jira_connection': {},
            'wbs_structure': {},
            'components_status': {}
        }
        
        try:
            # Validate configuration
            validation_results['config_validation'] = self.config_manager.validate_jira_credentials()
            
            # Test Jira connection (unless in test mode)
            if not self.test_mode:
                connection_test = self.jira_integrator.test_connection()
                validation_results['jira_connection'] = {
                    'connected': connection_test,
                    'url': self.config['jira'].get('url', 'Not set')
                }
            else:
                validation_results['jira_connection'] = {
                    'connected': True,
                    'note': 'Test mode - connection skipped'
                }
            
            # Validate WBS structure
            validation_results['wbs_structure'] = self.wbs_manager.validate_wbs_structure()
            
            # Component status
            validation_results['components_status'] = {
                'csv_processor': 'READY',
                'jira_integrator': 'READY',
                'duplicate_checker': 'READY',
                'wbs_manager': 'READY'
            }
            
            # Determine overall status
            config_valid = validation_results['config_validation'].get('is_complete', False)
            jira_connected = validation_results['jira_connection'].get('connected', False)
            wbs_valid = validation_results['wbs_structure'].get('valid', False)
            
            if config_valid and jira_connected and wbs_valid:
                validation_results['overall_status'] = 'READY'
            elif config_valid and jira_connected:
                validation_results['overall_status'] = 'READY_WITH_WARNINGS'
            else:
                validation_results['overall_status'] = 'NOT_READY'
            
            self.structured_logger.log_operation_success("SYSTEM_VALIDATION", {"status": validation_results['overall_status']})
            
        except Exception as e:
            validation_results['overall_status'] = 'ERROR'
            validation_results['error'] = str(e)
            self.structured_logger.log_operation_failure("SYSTEM_VALIDATION", str(e))
        
        return validation_results
    
    def process_bugs_from_csv(self, csv_path: str, dry_run: bool = True) -> Dict[str, Any]:
        """
        Process bugs from CSV file and create Jira issues
        
        Args:
            csv_path: Path to CSV file containing bug data
            dry_run: If True, simulate without creating actual issues
            
        Returns:
            Processing results dictionary
        """
        self.structured_logger.log_operation_start("CSV_PROCESSING", {"csv_path": csv_path, "dry_run": dry_run})
        
        results = {
            'status': 'PENDING',
            'total_bugs': 0,
            'processed': 0,
            'created': 0,
            'skipped': 0,
            'errors': 0,
            'bug_details': [],
            'processing_summary': {},
            'wbs_categorization': {}
        }
        
        try:
            # Process CSV
            self.structured_logger.log_data_processing("CSV_LOAD", 0, {"file": csv_path})
            bugs_data = self.csv_processor.process_csv(csv_path)
            results['total_bugs'] = len(bugs_data)
            
            self.structured_logger.log_data_processing("CSV_LOADED", len(bugs_data), {"file": csv_path})
            
            # Initialize WBS categorization tracking
            wbs_categories = {}
            
            # Process each bug
            for i, bug_data in enumerate(bugs_data, 1):
                bug_number = bug_data.get('bug_number', f'Unknown-{i}')
                
                try:
                    self.structured_logger.log_operation_start(f"PROCESS_BUG_{bug_number}")
                    
                    # Check for duplicates
                    is_duplicate = self.duplicate_checker.is_duplicate(bug_number, self.config['jira']['project_key'])
                    
                    if is_duplicate:
                        results['skipped'] += 1
                        bug_result = {
                            'bug_number': bug_number,
                            'status': 'SKIPPED',
                            'reason': 'Duplicate found in Jira',
                            'wbs_category': None
                        }
                    else:
                        # Get WBS categorization
                        wbs_placement = self.wbs_manager.categorize_bug(bug_data)
                        category = wbs_placement['category']
                        
                        # Track WBS categories
                        if category not in wbs_categories:
                            wbs_categories[category] = 0
                        wbs_categories[category] += 1
                        
                        # Prepare Jira issue data
                        enhanced_template = self.wbs_manager.enhance_bug_template(bug_data, self.config['bug_template'])
                        jira_issue_data = self._prepare_issue_data(bug_data, enhanced_template)
                        
                        if dry_run:
                            results['created'] += 1
                            bug_result = {
                                'bug_number': bug_number,
                                'status': 'DRY_RUN_SUCCESS',
                                'wbs_category': category,
                                'epic': wbs_placement['epic'],
                                'components': wbs_placement['components'],
                                'priority': enhanced_template.get('priority', 'Medium'),
                                'issue_data': jira_issue_data
                            }
                        else:
                            # Create actual Jira issue
                            issue_key = self.jira_integrator.create_issue(jira_issue_data)
                            
                            if issue_key:
                                results['created'] += 1
                                bug_result = {
                                    'bug_number': bug_number,
                                    'status': 'CREATED',
                                    'jira_key': issue_key,
                                    'wbs_category': category,
                                    'epic': wbs_placement['epic'],
                                    'components': wbs_placement['components']
                                }
                            else:
                                results['errors'] += 1
                                bug_result = {
                                    'bug_number': bug_number,
                                    'status': 'ERROR',
                                    'reason': 'Failed to create Jira issue',
                                    'wbs_category': category
                                }
                    
                    results['bug_details'].append(bug_result)
                    results['processed'] += 1
                    
                    self.structured_logger.log_operation_success(f"PROCESS_BUG_{bug_number}", {"status": bug_result['status']})
                    
                except Exception as e:
                    results['errors'] += 1
                    error_result = {
                        'bug_number': bug_number,
                        'status': 'ERROR',
                        'reason': str(e),
                        'wbs_category': None
                    }
                    results['bug_details'].append(error_result)
                    
                    self.structured_logger.log_operation_failure(f"PROCESS_BUG_{bug_number}", str(e))
            
            # Generate processing summary
            results['processing_summary'] = {
                'total_processed': results['processed'],
                'success_rate': (results['created'] / results['total_bugs']) * 100 if results['total_bugs'] > 0 else 0,
                'duplicate_rate': (results['skipped'] / results['total_bugs']) * 100 if results['total_bugs'] > 0 else 0,
                'error_rate': (results['errors'] / results['total_bugs']) * 100 if results['total_bugs'] > 0 else 0
            }
            
            results['wbs_categorization'] = wbs_categories
            results['status'] = 'COMPLETED'
            
            self.structured_logger.log_operation_success("CSV_PROCESSING", results['processing_summary'])
            
        except Exception as e:
            results['status'] = 'ERROR'
            results['error'] = str(e)
            self.structured_logger.log_operation_failure("CSV_PROCESSING", str(e))
        
        return results
    
    def check_for_duplicates(self, bug_numbers: List[str], project_key: str) -> Dict[str, Any]:
        """
        Check multiple bug numbers for duplicates in Jira
        
        Args:
            bug_numbers: List of bug numbers to check
            project_key: Jira project key
            
        Returns:
            Dictionary with duplicate check results
        """
        self.structured_logger.log_operation_start("BULK_DUPLICATE_CHECK", {"count": len(bug_numbers)})
        
        results = {
            'total_checked': len(bug_numbers),
            'duplicates_found': 0,
            'unique_bugs': 0,
            'check_results': [],
            'duplicate_list': []
        }
        
        try:
            for bug_number in bug_numbers:
                is_duplicate = self.duplicate_checker.is_duplicate(bug_number, project_key)
                
                check_result = {
                    'bug_number': bug_number,
                    'is_duplicate': is_duplicate,
                    'pattern_searched': f"QC ID {bug_number}"
                }
                
                results['check_results'].append(check_result)
                
                if is_duplicate:
                    results['duplicates_found'] += 1
                    results['duplicate_list'].append(bug_number)
                else:
                    results['unique_bugs'] += 1
            
            self.structured_logger.log_operation_success("BULK_DUPLICATE_CHECK", {
                "duplicates": results['duplicates_found'],
                "unique": results['unique_bugs']
            })
            
        except Exception as e:
            self.structured_logger.log_operation_failure("BULK_DUPLICATE_CHECK", str(e))
            results['error'] = str(e)
        
        return results
    
    def get_wbs_analysis(self, csv_path: str) -> Dict[str, Any]:
        """
        Analyze CSV data and provide WBS categorization preview
        
        Args:
            csv_path: Path to CSV file
            
        Returns:
            WBS analysis results
        """
        self.structured_logger.log_operation_start("WBS_ANALYSIS", {"csv_path": csv_path})
        
        try:
            bugs_data = self.csv_processor.process_csv(csv_path)
            
            analysis = {
                'total_bugs': len(bugs_data),
                'categorization_breakdown': {},
                'epic_distribution': {},
                'priority_distribution': {},
                'component_mapping': {},
                'bug_samples': []
            }
            
            for bug_data in bugs_data:
                # Get WBS placement
                wbs_placement = self.wbs_manager.categorize_bug(bug_data)
                category = wbs_placement['category']
                epic = wbs_placement['epic']
                
                # Get priority
                priority = self.wbs_manager.determine_priority(bug_data, wbs_placement)
                
                # Track categorization
                if category not in analysis['categorization_breakdown']:
                    analysis['categorization_breakdown'][category] = 0
                analysis['categorization_breakdown'][category] += 1
                
                # Track epic distribution
                if epic not in analysis['epic_distribution']:
                    analysis['epic_distribution'][epic] = 0
                analysis['epic_distribution'][epic] += 1
                
                # Track priority distribution
                if priority not in analysis['priority_distribution']:
                    analysis['priority_distribution'][priority] = 0
                analysis['priority_distribution'][priority] += 1
                
                # Track component mapping
                components = wbs_placement.get('components', [])
                for component in components:
                    if component not in analysis['component_mapping']:
                        analysis['component_mapping'][component] = 0
                    analysis['component_mapping'][component] += 1
                
                # Collect sample
                if len(analysis['bug_samples']) < 5:
                    analysis['bug_samples'].append({
                        'bug_number': bug_data.get('bug_number'),
                        'summary': bug_data.get('summary'),
                        'wbs_category': category,
                        'epic': epic,
                        'priority': priority,
                        'components': components
                    })
            
            self.structured_logger.log_operation_success("WBS_ANALYSIS", {"total_bugs": len(bugs_data)})
            
            return analysis
            
        except Exception as e:
            self.structured_logger.log_operation_failure("WBS_ANALYSIS", str(e))
            return {"error": str(e)}
    
    def get_system_status(self) -> Dict[str, Any]:
        """
        Get comprehensive system status
        
        Returns:
            System status dictionary
        """
        try:
            status = {
                'api_version': '1.0.0',
                'test_mode': self.test_mode,
                'config_summary': self.config_manager.get_config_summary(),
                'wbs_summary': self.wbs_manager.get_wbs_summary(),
                'validation': self.validate_system()
            }
            
            return status
            
        except Exception as e:
            return {
                'api_version': '1.0.0',
                'status': 'ERROR',
                'error': str(e)
            }
    
    def _prepare_issue_data(self, bug_data: Dict[str, Any], enhanced_template: Dict[str, Any]) -> Dict[str, Any]:
        """
        Internal method to prepare Jira issue data
        
        Args:
            bug_data: Bug data from CSV
            enhanced_template: Enhanced bug template from WBS manager
            
        Returns:
            Formatted Jira issue data
        """
        jira_config = self.config.get('jira', {})
        
        issue_data = {
            'project': {'key': jira_config.get('project_key')},
            'issuetype': {'name': enhanced_template.get('issue_type', 'Bug')},
            'summary': f"QC ID {bug_data.get('bug_number', 'Unknown')} - {bug_data.get('summary', 'No summary provided')}",
            'description': self._prepare_description(bug_data, enhanced_template),
            'priority': {'name': enhanced_template.get('priority', 'Medium')},
        }
        
        # Add assignee if provided
        assignee = bug_data.get('assign_to', '').strip()
        if assignee and assignee.lower() != 'unassigned':
            issue_data['assignee'] = {'name': assignee}
        elif enhanced_template.get('default_assignee'):
            issue_data['assignee'] = {'name': enhanced_template['default_assignee']}
        
        # Add reporter
        reporter = bug_data.get('detected_by', '').strip()
        if reporter:
            issue_data['reporter'] = {'name': reporter}
        elif enhanced_template.get('default_reporter'):
            issue_data['reporter'] = {'name': enhanced_template['default_reporter']}
        
        # Add components
        if enhanced_template.get('components'):
            issue_data['components'] = [{'name': comp} for comp in enhanced_template['components']]
        
        # Add labels
        labels = enhanced_template.get('labels', [])
        labels.append(f"QC-{bug_data.get('bug_number', 'Unknown')}")
        issue_data['labels'] = labels
        
        # Add custom fields
        custom_fields = enhanced_template.get('custom_fields', {})
        for field_id, field_value in custom_fields.items():
            issue_data[field_id] = field_value
        
        return issue_data
    
    def _prepare_description(self, bug_data: Dict[str, Any], enhanced_template: Dict[str, Any]) -> str:
        """
        Prepare detailed description for Jira issue
        
        Args:
            bug_data: Bug information from CSV
            enhanced_template: Enhanced bug template
            
        Returns:
            Formatted description string
        """
        description_parts = []
        
        # Add bug description
        if bug_data.get('description'):
            description_parts.append(f"*Bug Description:*\n{bug_data['description']}")
        
        # Add bug details
        description_parts.append("\n*Bug Details:*")
        description_parts.append(f"• QC ID: {bug_data.get('bug_number', 'Not specified')}")
        description_parts.append(f"• Detected By: {bug_data.get('detected_by', 'Not specified')}")
        description_parts.append(f"• Assigned To: {bug_data.get('assign_to', 'Unassigned')}")
        
        # Add WBS information
        description_parts.append("\n*WBS Classification:*")
        custom_fields = enhanced_template.get('custom_fields', {})
        if 'wbs_category' in custom_fields:
            description_parts.append(f"• Category: {custom_fields['wbs_category']}")
        if 'wbs_epic' in custom_fields:
            description_parts.append(f"• Epic: {custom_fields['wbs_epic']}")
        
        # Add product and environment info
        if enhanced_template.get('product'):
            description_parts.append(f"• Product: {enhanced_template['product']}")
        if enhanced_template.get('environment'):
            description_parts.append(f"• Environment: {enhanced_template['environment']}")
        
        # Add additional notes
        if enhanced_template.get('additional_notes'):
            description_parts.append(f"\n*Additional Notes:*\n{enhanced_template['additional_notes']}")
        
        return "\n".join(description_parts)


# Convenience functions for easy API usage
def create_api_instance(config_path: str, test_mode: bool = False) -> JiraBugIntegrationAPI:
    """
    Create a new API instance
    
    Args:
        config_path: Path to configuration file
        test_mode: Whether to run in test mode
        
    Returns:
        JiraBugIntegrationAPI instance
    """
    return JiraBugIntegrationAPI(config_path, test_mode)


def quick_process_csv(config_path: str, csv_path: str, dry_run: bool = True, test_mode: bool = False) -> Dict[str, Any]:
    """
    Quick function to process CSV with minimal setup
    
    Args:
        config_path: Path to configuration file
        csv_path: Path to CSV file
        dry_run: Whether to run in dry-run mode
        test_mode: Whether to run in test mode
        
    Returns:
        Processing results
    """
    api = create_api_instance(config_path, test_mode)
    return api.process_bugs_from_csv(csv_path, dry_run)


def analyze_csv_wbs(config_path: str, csv_path: str) -> Dict[str, Any]:
    """
    Quick function to analyze CSV with WBS categorization
    
    Args:
        config_path: Path to configuration file
        csv_path: Path to CSV file
        
    Returns:
        WBS analysis results
    """
    api = create_api_instance(config_path, test_mode=True)
    return api.get_wbs_analysis(csv_path)