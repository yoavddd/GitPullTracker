#!/usr/bin/env python3
"""
Git Submodule Pull Request Analyzer

Analyzes submodule pointer changes between super project commits and extracts 
merged pull requests for each changed submodule range.
"""

import argparse
import json
import logging
import os
import sys
from typing import Dict, List

from git_analyzer import GitAnalyzer
from tfs_client import TFSClient
from report_generator import ReportGenerator
from logger_config import setup_logging

def load_config(config_path: str) -> Dict:
    """
    Load configuration from JSON file
    """
    try:
        logging.info(f"Loading configuration from: {config_path}")
        
        if not os.path.exists(config_path):
            logging.error(f"Configuration file not found: {config_path}")
            raise FileNotFoundError(f"Configuration file not found: {config_path}")
        
        with open(config_path, 'r') as f:
            config = json.load(f)
        
        # Validate required fields
        required_fields = ['tfs_url', 'tfs_token', 'repository_path', 'from_commit', 'to_commit']
        missing_fields = [field for field in required_fields if field not in config]
        
        if missing_fields:
            logging.error(f"Missing required configuration fields: {missing_fields}")
            raise ValueError(f"Missing required configuration fields: {missing_fields}")
        
        logging.info("Configuration loaded successfully")
        logging.debug(f"Configuration: {json.dumps({k: v if k != 'tfs_token' else '***' for k, v in config.items()}, indent=2)}")
        
        return config
        
    except Exception as e:
        logging.error(f"Error loading configuration: {str(e)}")
        raise

def validate_configuration(config: Dict) -> bool:
    """
    Validate configuration values
    """
    try:
        logging.info("Validating configuration...")
        
        # Check repository path
        repo_path = config['repository_path']
        if not os.path.exists(repo_path):
            logging.error(f"Repository path does not exist: {repo_path}")
            return False
        
        # Check if it's a git repository
        git_dir = os.path.join(repo_path, '.git')
        if not os.path.exists(git_dir):
            logging.error(f"Not a Git repository: {repo_path}")
            return False
        
        # Validate commit hashes (basic format check)
        from_commit = config['from_commit']
        to_commit = config['to_commit']
        
        if len(from_commit) < 7 or len(to_commit) < 7:
            logging.error("Commit hashes must be at least 7 characters long")
            return False
        
        logging.info("Configuration validation passed")
        return True
        
    except Exception as e:
        logging.error(f"Error validating configuration: {str(e)}")
        return False

def main():
    """
    Main application entry point
    """
    # Parse command line arguments
    parser = argparse.ArgumentParser(
        description="Analyze submodule pointer changes and extract pull requests"
    )
    parser.add_argument(
        '--config', 
        default='config.json',
        help='Path to configuration file (default: config.json)'
    )
    parser.add_argument(
        '--output-dir',
        default='./output',
        help='Output directory for reports (default: ./output)'
    )
    parser.add_argument(
        '--log-level',
        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
        default='INFO',
        help='Logging level (default: INFO)'
    )
    
    args = parser.parse_args()
    
    try:
        # Load configuration
        config = load_config(args.config)
        
        # Override output directory if specified
        if args.output_dir != './output':
            config['output_directory'] = args.output_dir
        
        # Override log level if specified
        if args.log_level != 'INFO':
            config['log_level'] = args.log_level
        
        # Set up logging
        output_dir = config.get('output_directory', './output')
        log_level = config.get('log_level', 'INFO')
        setup_logging(log_level, output_dir)
        
        logging.info("=" * 60)
        logging.info("STARTING GIT SUBMODULE PULL REQUEST ANALYZER")
        logging.info("=" * 60)
        
        # Validate configuration
        if not validate_configuration(config):
            logging.error("Configuration validation failed")
            sys.exit(1)
        
        # Initialize components
        logging.info("Initializing components...")
        
        git_analyzer = GitAnalyzer(config['repository_path'])
        demo_mode = config.get('demo_mode', False) or config.get('skip_tfs_connection', False)
        tfs_client = TFSClient(config['tfs_url'], config['tfs_token'], demo_mode=demo_mode)
        report_generator = ReportGenerator(output_dir)
        
        # Test TFS connection (skip if demo mode or skip_tfs_connection is enabled)
        skip_tfs = config.get('skip_tfs_connection', False) or config.get('demo_mode', False)
        if skip_tfs:
            logging.warning("TFS connection test skipped (demo mode or skip_tfs_connection enabled)")
        else:
            logging.info("Testing TFS connection...")
            if not tfs_client.test_connection():
                logging.error("Failed to connect to TFS. Please check your configuration.")
                sys.exit(1)
        
        logging.info("All components initialized successfully")
        
        # STEP 1: Analyze submodule changes
        logging.info("STEP 1: Analyzing submodule pointer changes...")
        demo_with_submodules = config.get('demo_with_submodules', False)
        submodule_changes = git_analyzer.analyze_submodule_changes(
            config['from_commit'], 
            config['to_commit'],
            demo_with_submodules
        )
        
        if not submodule_changes:
            logging.warning("No submodule changes detected between the specified commits")
        else:
            logging.info(f"Found changes in {len(submodule_changes)} submodules")
        
        # STEP 2: Get super project commit range info
        logging.info("STEP 2: Analyzing super project commit range...")
        super_project_info = git_analyzer.get_commit_range_info(
            config['from_commit'],
            config['to_commit']
        )
        
        # STEP 3: Extract super project pull requests
        logging.info("STEP 3: Extracting super project pull requests...")
        super_project_prs = tfs_client.get_pull_requests_in_commit_range(
            config['from_commit'],
            config['to_commit'],
            git_repo_path=config['repository_path']
        )
        
        logging.info(f"Found {len(super_project_prs)} pull requests in super project")
        
        # STEP 4: Extract submodule pull requests
        logging.info("STEP 4: Extracting submodule pull requests...")
        submodule_prs = {}
        
        for submodule_path, changes in submodule_changes.items():
            logging.info(f"Processing submodule: {submodule_path}")
            
            # Get submodule repository URL and extract repository name
            mock_submodules = submodule_changes if demo_with_submodules else None
            submodule_url = git_analyzer.get_submodule_repository_url(submodule_path, mock_submodules)
            if not submodule_url:
                logging.warning(f"Could not determine repository URL for submodule: {submodule_path}")
                submodule_prs[submodule_path] = []
                continue
            
            # Extract repository name from URL
            repo_name = tfs_client.get_submodule_repository_name(submodule_url)
            if not repo_name:
                logging.warning(f"Could not extract repository name from URL: {submodule_url}")
                submodule_prs[submodule_path] = []
                continue
            
            # Get pull requests for this submodule
            submodule_full_path = os.path.join(config['repository_path'], submodule_path)
            prs = tfs_client.get_pull_requests_in_commit_range(
                changes['old_commit'],
                changes['new_commit'],
                repository_name=repo_name,
                git_repo_path=submodule_full_path
            )
            
            submodule_prs[submodule_path] = prs
            logging.info(f"Found {len(prs)} pull requests for submodule '{submodule_path}'")
        
        # STEP 5: Generate reports
        logging.info("STEP 5: Generating reports...")
        
        report_files = report_generator.generate_comprehensive_report(
            super_project_info,
            submodule_changes,
            super_project_prs,
            submodule_prs
        )
        
        # Print console summary
        report_generator.print_console_summary(
            super_project_info,
            submodule_changes,
            super_project_prs,
            submodule_prs
        )
        
        logging.info("=" * 60)
        logging.info("ANALYSIS COMPLETED SUCCESSFULLY")
        logging.info("=" * 60)
        
        # Print report file locations
        print(f"\nReport files generated in: {output_dir}")
        for report_type, file_path in report_files.items():
            if isinstance(file_path, dict):
                for sub_path, sub_file in file_path.items():
                    print(f"  • {report_type}/{sub_path}: {sub_file}")
            else:
                print(f"  • {report_type}: {file_path}")
        
        return 0
        
    except KeyboardInterrupt:
        logging.info("Analysis interrupted by user")
        return 1
    except Exception as e:
        logging.error(f"Analysis failed: {str(e)}")
        logging.exception("Full error traceback:")
        return 1

if __name__ == "__main__":
    sys.exit(main())
