import git
import logging
import os
import re
from typing import Dict, List, Tuple, Optional

class GitAnalyzer:
    """
    Analyzes Git repository for submodule pointer changes between commits
    """
    
    def __init__(self, repo_path: str):
        self.repo_path = repo_path
        self.logger = logging.getLogger('git_diff')
        self.submodule_logger = logging.getLogger('submodule')
        
        try:
            self.repo = git.Repo(repo_path)
            self.logger.info(f"Successfully initialized Git repository at: {repo_path}")
        except git.exc.InvalidGitRepositoryError:
            self.logger.error(f"Invalid Git repository path: {repo_path}")
            raise
        except Exception as e:
            self.logger.error(f"Error initializing Git repository: {str(e)}")
            raise
    
    def get_commit_hash(self, commit_ref: str) -> str:
        """
        Convert commit reference (hash, tag, branch) to full commit hash
        """
        try:
            commit = self.repo.commit(commit_ref)
            commit_hash = commit.hexsha
            self.logger.debug(f"Resolved '{commit_ref}' to commit hash: {commit_hash}")
            return commit_hash
        except git.exc.BadName:
            self.logger.error(f"Invalid commit reference: {commit_ref}")
            raise
        except Exception as e:
            self.logger.error(f"Error resolving commit reference '{commit_ref}': {str(e)}")
            raise
    
    def analyze_submodule_changes(self, from_commit: str, to_commit: str, demo_with_submodules: bool = False) -> Dict[str, Dict[str, str]]:
        """
        Analyze submodule pointer changes between two commits
        Returns dict with submodule paths as keys and old/new commit hashes as values
        """
        self.logger.info(f"Starting submodule analysis between commits: {from_commit} -> {to_commit}")
        
        # Convert to full hashes
        from_hash = self.get_commit_hash(from_commit)
        to_hash = self.get_commit_hash(to_commit)
        
        self.logger.info(f"Full commit hashes: {from_hash} -> {to_hash}")
        
        # If demo mode with submodules is enabled, generate mock submodule changes
        if demo_with_submodules:
            self.logger.info("DEMO MODE: Generating mock submodule changes for testing")
            return self._generate_mock_submodule_changes()
        
        submodule_changes = {}
        
        try:
            # OPTIMIZED APPROACH: Direct submodule diff parsing
            submodule_changes = self._get_fast_submodule_changes(from_hash, to_hash)
            
            if submodule_changes:
                self.logger.info(f"Found {len(submodule_changes)} submodule changes")
                for path, change in submodule_changes.items():
                    self.logger.info(f"Submodule '{path}': {change['old_commit'][:8]} -> {change['new_commit'][:8]}")
            else:
                self.logger.info("No submodule changes detected")
            
            return submodule_changes
            
        except Exception as e:
            self.logger.error(f"Error analyzing submodule changes: {str(e)}")
            raise
    
    def _get_fast_submodule_changes(self, from_hash: str, to_hash: str) -> Dict[str, Dict[str, str]]:
        """
        Fast method to detect submodule changes using optimized Git commands
        """
        changes = {}
        
        try:
            # Method 1: Use git diff --submodule=short for direct submodule detection
            diff_output = self.repo.git.diff(from_hash, to_hash, submodule='short')
            
            if diff_output:
                self.logger.debug(f"Submodule diff output:\n{diff_output}")
                changes.update(self._parse_submodule_diff_output(diff_output))
            
            # Method 2: Check .gitmodules for submodule paths and compare their commits
            try:
                # Get submodule paths from .gitmodules
                submodule_paths = self._get_submodule_paths()
                
                for path in submodule_paths:
                    # Get commit hashes at both commits
                    old_commit = self._get_submodule_commit_at_revision(path, from_hash)
                    new_commit = self._get_submodule_commit_at_revision(path, to_hash)
                    
                    if old_commit and new_commit and old_commit != new_commit:
                        changes[path] = {
                            'old_commit': old_commit,
                            'new_commit': new_commit
                        }
                        self.logger.info(f"Found submodule change in '{path}': {old_commit[:8]} -> {new_commit[:8]}")
            
            except Exception as e:
                self.logger.warning(f"Error checking submodule paths: {e}")
            
            return changes
            
        except Exception as e:
            self.logger.error(f"Error in fast submodule detection: {e}")
            return {}
    
    def _parse_submodule_diff_output(self, diff_output: str) -> Dict[str, Dict[str, str]]:
        """
        Parse git diff --submodule=short output to extract submodule changes
        """
        changes = {}
        lines = diff_output.split('\n')
        
        for line in lines:
            if 'Submodule' in line and '..' in line:
                # Example: "Submodule lib_common abc123..def456 (commits not present)"
                parts = line.split()
                if len(parts) >= 3:
                    path = parts[1]
                    commit_range = parts[2]
                    if '..' in commit_range:
                        old_commit, new_commit = commit_range.split('..')
                        changes[path] = {
                            'old_commit': old_commit,
                            'new_commit': new_commit
                        }
        
        return changes
    
    def _get_submodule_paths(self) -> List[str]:
        """
        Get list of submodule paths from .gitmodules
        """
        try:
            gitmodules_content = self.repo.git.show('HEAD:.gitmodules')
            paths = []
            
            for line in gitmodules_content.split('\n'):
                line = line.strip()
                if line.startswith('path ='):
                    path = line.split('=', 1)[1].strip()
                    paths.append(path)
            
            return paths
        except Exception as e:
            self.logger.debug(f"Could not read .gitmodules: {e}")
            return []
    
    def _get_submodule_commit_at_revision(self, submodule_path: str, commit_hash: str) -> Optional[str]:
        """
        Get the commit hash of a submodule at a specific revision
        """
        try:
            # Use git ls-tree to get the submodule commit hash
            result = self.repo.git.ls_tree(commit_hash, submodule_path)
            
            if result:
                # Parse output: "160000 commit <hash> <path>"
                parts = result.split()
                if len(parts) >= 3 and parts[0] == '160000':
                    return parts[2]
            
            return None
        except Exception as e:
            self.logger.debug(f"Could not get submodule commit for {submodule_path} at {commit_hash}: {e}")
            return None
    
    def _generate_mock_submodule_changes(self) -> Dict[str, Dict[str, str]]:
        """
        Generate mock submodule changes for demo purposes
        """
        mock_changes = {
            'lib_common': {
                'old_commit': 'abc123def456789012345678901234567890123456',
                'new_commit': 'def456abc789012345678901234567890123456789',
                'url': 'http://tfs1:8080/tfs/SilverArrowCollection/VMSC_App/_git/LibCommon'
            },
            'lib_utils': {
                'old_commit': '789abc123def456789012345678901234567890123',
                'new_commit': '123456def789abc012345678901234567890123abc',
                'url': 'http://tfs1:8080/tfs/SilverArrowCollection/VMSC_App/_git/LibUtils'
            },
            'shared/core': {
                'old_commit': '456789abc123def012345678901234567890123def',
                'new_commit': '567890def456abc123012345678901234567890456',
                'url': 'http://tfs1:8080/tfs/SilverArrowCollection/VMSC_App/_git/SharedCore'
            }
        }
        
        self.logger.info(f"Generated {len(mock_changes)} mock submodule changes")
        for submodule_path, changes in mock_changes.items():
            self.submodule_logger.info(f"Mock submodule '{submodule_path}': {changes['old_commit'][:8]} -> {changes['new_commit'][:8]}")
        
        return mock_changes
    
    def _parse_submodule_diff(self, diff_output: str, from_hash: str, to_hash: str) -> Dict[str, Dict[str, str]]:
        """
        Parse git diff output to extract submodule pointer changes
        """
        self.logger.debug("Parsing submodule diff output")
        submodule_changes = {}
        
        # Split diff into sections
        diff_sections = re.split(r'\ndiff --git', diff_output)
        
        for section in diff_sections:
            if not section.strip():
                continue
                
            # Look for submodule changes (160000 is the mode for submodules)
            if '160000' in section:
                self.logger.debug(f"Found potential submodule section:\n{section}")
                
                # Extract submodule path
                path_match = re.search(r'a/(.*?)\s+b/(.*?)(?:\s|$)', section)
                if not path_match:
                    continue
                
                submodule_path = path_match.group(1)
                self.logger.debug(f"Analyzing submodule: {submodule_path}")
                
                # Extract old and new commit hashes
                commit_matches = re.findall(r'index ([a-f0-9]+)\.\.([a-f0-9]+)', section)
                if commit_matches:
                    old_commit, new_commit = commit_matches[0]
                    submodule_changes[submodule_path] = {
                        'old_commit': old_commit,
                        'new_commit': new_commit
                    }
                    self.logger.info(f"Submodule '{submodule_path}' changed: {old_commit} -> {new_commit}")
        
        return submodule_changes
    
    def _check_current_submodules(self, from_hash: str, to_hash: str, existing_changes: Dict[str, Dict[str, str]]):
        """
        Check current submodules for changes not captured in diff parsing
        """
        try:
            self.logger.debug("Checking current submodules for additional changes")
            
            # Get submodules from both commits
            from_submodules = self._get_submodules_at_commit(from_hash)
            to_submodules = self._get_submodules_at_commit(to_hash)
            
            self.logger.debug(f"From commit submodules: {list(from_submodules.keys())}")
            self.logger.debug(f"To commit submodules: {list(to_submodules.keys())}")
            
            # Compare submodule commits
            all_submodule_paths = set(from_submodules.keys()) | set(to_submodules.keys())
            
            for submodule_path in all_submodule_paths:
                if submodule_path in existing_changes:
                    continue  # Already found this change
                
                old_commit = from_submodules.get(submodule_path, "0000000000000000000000000000000000000000")
                new_commit = to_submodules.get(submodule_path, "0000000000000000000000000000000000000000")
                
                if old_commit != new_commit:
                    existing_changes[submodule_path] = {
                        'old_commit': old_commit,
                        'new_commit': new_commit
                    }
                    self.logger.info(f"Additional submodule change found: '{submodule_path}' {old_commit} -> {new_commit}")
                    
        except Exception as e:
            self.logger.warning(f"Error checking current submodules: {str(e)}")
    
    def _get_submodules_at_commit(self, commit_hash: str) -> Dict[str, str]:
        """
        Get submodule paths and their commit hashes at a specific commit
        """
        submodules = {}
        
        try:
            # Checkout to the specific commit temporarily
            original_head = self.repo.head.commit
            
            try:
                self.repo.git.checkout(commit_hash)
                
                # Read .gitmodules if it exists
                gitmodules_path = os.path.join(self.repo_path, '.gitmodules')
                if os.path.exists(gitmodules_path):
                    # Parse .gitmodules to get submodule paths
                    submodule_paths = self._parse_gitmodules(gitmodules_path)
                    
                    for submodule_path in submodule_paths:
                        try:
                            # Get the commit hash for this submodule
                            submodule_commit = self.repo.git.ls_tree(commit_hash, submodule_path).split()[2]
                            submodules[submodule_path] = submodule_commit
                            self.logger.debug(f"Submodule '{submodule_path}' at commit {commit_hash}: {submodule_commit}")
                        except Exception as e:
                            self.logger.debug(f"Could not get commit for submodule '{submodule_path}': {str(e)}")
                
            finally:
                # Return to original HEAD
                self.repo.git.checkout(original_head.hexsha)
                
        except Exception as e:
            self.logger.debug(f"Error getting submodules at commit {commit_hash}: {str(e)}")
        
        return submodules
    
    def _parse_gitmodules(self, gitmodules_path: str) -> List[str]:
        """
        Parse .gitmodules file to extract submodule paths
        """
        submodule_paths = []
        
        try:
            with open(gitmodules_path, 'r') as f:
                content = f.read()
            
            # Find all path definitions
            path_matches = re.findall(r'path\s*=\s*(.+)', content)
            submodule_paths = [path.strip() for path in path_matches]
            
            self.logger.debug(f"Found submodule paths in .gitmodules: {submodule_paths}")
            
        except Exception as e:
            self.logger.debug(f"Error parsing .gitmodules: {str(e)}")
        
        return submodule_paths
    
    def get_commit_range_info(self, from_commit: str, to_commit: str) -> Dict[str, any]:
        """
        Get information about the commit range in the super project
        """
        try:
            from_hash = self.get_commit_hash(from_commit)
            to_hash = self.get_commit_hash(to_commit)
            
            # Get commits in range
            commits = list(self.repo.iter_commits(f"{from_hash}..{to_hash}"))
            
            commit_info = {
                'from_commit': from_hash,
                'to_commit': to_hash,
                'commit_count': len(commits),
                'commits': [
                    {
                        'hash': commit.hexsha,
                        'message': commit.message.strip(),
                        'author': str(commit.author),
                        'date': commit.committed_datetime.isoformat()
                    }
                    for commit in commits
                ]
            }
            
            self.logger.info(f"Super project commit range: {len(commits)} commits between {from_hash} and {to_hash}")
            
            return commit_info
            
        except Exception as e:
            self.logger.error(f"Error getting commit range info: {str(e)}")
            raise
    
    def get_submodule_repository_url(self, submodule_path: str, mock_submodules: Dict = None) -> Optional[str]:
        """
        Get the repository URL for a submodule
        """
        # Handle mock submodules first
        if mock_submodules and submodule_path in mock_submodules:
            url = mock_submodules[submodule_path].get('url')
            self.logger.debug(f"Found mock URL for submodule '{submodule_path}': {url}")
            return url
        
        try:
            gitmodules_path = os.path.join(self.repo_path, '.gitmodules')
            if not os.path.exists(gitmodules_path):
                self.logger.warning(".gitmodules file not found")
                return None
            
            with open(gitmodules_path, 'r') as f:
                content = f.read()
            
            # Find the submodule section
            pattern = rf'\[submodule\s+"[^"]*{re.escape(submodule_path)}[^"]*"\](.*?)(?=\[submodule|\Z)'
            match = re.search(pattern, content, re.DOTALL | re.IGNORECASE)
            
            if match:
                section = match.group(1)
                url_match = re.search(r'url\s*=\s*(.+)', section)
                if url_match:
                    url = url_match.group(1).strip()
                    self.logger.debug(f"Found URL for submodule '{submodule_path}': {url}")
                    return url
            
            self.logger.warning(f"Could not find URL for submodule: {submodule_path}")
            return None
            
        except Exception as e:
            self.logger.error(f"Error getting submodule URL for '{submodule_path}': {str(e)}")
            return None
