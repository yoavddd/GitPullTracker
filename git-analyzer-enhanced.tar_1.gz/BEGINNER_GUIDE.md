# Complete Beginner's Guide to Git Submodule Pull Request Analyzer

## What This Program Does (In Simple Terms)

Imagine you have a big software project that uses smaller projects inside it (called "submodules"). When your team makes changes, they create "pull requests" to merge their work. This tool helps you see all the pull requests that were merged between two points in time, both in your main project and in all the smaller projects.

## Step-by-Step Setup (For Complete Beginners)

### Step 1: Download Python
1. Go to https://www.python.org/downloads/
2. Click "Download Python" (get version 3.8 or newer)
3. Run the installer
4. **IMPORTANT**: Check the box "Add Python to PATH" during installation
5. Click "Install Now"

### Step 2: Download All Program Files
Create a new folder on your computer called "git-analyzer" and download these files into it:

**Required Files (8 total):**
- main.py
- git_analyzer.py
- tfs_client.py
- report_generator.py
- logger_config.py
- config.json
- README.md
- setup.bat (for Windows users)

### Step 3: Install Required Libraries
**Windows Users:**
1. Double-click `setup.bat` - this will install everything automatically
2. If that doesn't work, open Command Prompt and run:
   ```
   pip install GitPython requests pandas colorlog tabulate
   ```

**Mac/Linux Users:**
Open Terminal and run:
```bash
pip install GitPython requests pandas colorlog tabulate
```

### Step 4: Configure Your Settings
Open `config.json` in any text editor (like Notepad) and change these values:

```json
{
    "tfs_url": "http://your-server:8080/tfs/YourCollection/YourProject/_git/YourRepo",
    "tfs_token": "your-personal-access-token-here",
    "repository_path": "C:\\path\\to\\your\\git\\repository",
    "from_commit": "starting-commit-hash",
    "to_commit": "ending-commit-hash",
    "output_directory": "./output",
    "log_level": "INFO"
}
```

**How to get each value:**

1. **tfs_url**: Copy from your TFS/Azure DevOps browser address bar
2. **tfs_token**: In TFS, go to User Settings → Personal Access Tokens → Create New
3. **repository_path**: Path to your Git repository folder on your computer
4. **from_commit** and **to_commit**: Git commit hashes you want to compare

### Step 5: Test Run (Demo Mode)
Before connecting to your real TFS server, test with demo mode:

Add these lines to your `config.json`:
```json
{
    "demo_mode": true,
    "skip_tfs_connection": true,
    "repository_path": "./test_repo"
}
```

## How to Run the Program

### Method 1: Double-Click (Windows)
Create a file called `run.bat` with this content:
```batch
@echo off
python main.py
pause
```
Double-click `run.bat` to run the program.

### Method 2: Command Line
1. Open Command Prompt (Windows) or Terminal (Mac/Linux)
2. Navigate to your git-analyzer folder
3. Run: `python main.py`

## Understanding the Output

### What You'll See on Screen
```
============================================================
STARTING GIT SUBMODULE PULL REQUEST ANALYZER
============================================================
Validating configuration...
Configuration validation passed
Initializing components...
All components initialized successfully
STEP 1: Analyzing submodule pointer changes...
STEP 2: Analyzing super project commit range...
STEP 3: Extracting super project pull requests...
STEP 4: Extracting submodule pull requests...
STEP 5: Generating reports...
============================================================
ANALYSIS COMPLETED SUCCESSFULLY
============================================================
```

### Files Created
The program creates an `output` folder with:

**Reports:**
- `super_project_prs_[timestamp].csv` - Main project pull requests (Excel can open this)
- `submodule_[name]_prs_[timestamp].csv` - Pull requests for each submodule
- `combined_summary_[timestamp].txt` - Human-readable summary
- `analysis_data_[timestamp].json` - All data in computer format

**Logs (for troubleshooting):**
- Various `.log` files in the `logs` folder

## Example Test Setup

### Create Test Repository
If you want to test without your real repository, create a test one:

1. Create folder: `test_repo`
2. Open Command Prompt in that folder
3. Run these commands:
   ```bash
   git init
   git config user.email "test@example.com"
   git config user.name "Test User"
   echo "# Test" > README.md
   git add README.md
   git commit -m "Initial commit"
   echo "More content" >> README.md
   git add README.md
   git commit -m "Second commit"
   git log --oneline
   ```
4. Copy the commit hashes from the last command and use them in your config.json

### Test Configuration
```json
{
    "tfs_url": "http://test-server:8080/tfs/TestCollection/TestProject/_git/TestRepo",
    "tfs_token": "test-token",
    "repository_path": "./test_repo",
    "from_commit": "first-commit-hash",
    "to_commit": "second-commit-hash",
    "output_directory": "./output",
    "log_level": "DEBUG",
    "demo_mode": true,
    "skip_tfs_connection": true
}
```

## Common Problems and Solutions

### "python is not recognized"
- Python isn't installed or not in PATH
- Reinstall Python and check "Add to PATH"

### "No module named 'git'"
- Libraries not installed
- Run: `pip install GitPython requests pandas colorlog tabulate`

### "Repository path does not exist"
- Wrong path in config.json
- Use full path like `C:\\Users\\YourName\\Documents\\MyRepo`

### "Failed to connect to TFS"
- TFS server not accessible
- Wrong tfs_url or tfs_token
- Try demo mode first to test everything else works

### "No submodule changes detected"
- Normal if there are no submodule changes between commits
- The tool will still show super project pull requests

## Reading the Results

### CSV Files (Open in Excel)
Each row is one pull request with columns:
- PR_ID: Pull request number
- Title: What the pull request does
- Created_By: Who created it
- Created_Date: When it was created
- Source_Branch: Branch that was merged
- Target_Branch: Branch it was merged into

### Summary File (Open in Notepad)
Shows overview:
- How many pull requests found
- List of submodules that changed
- Statistics summary

## Tips for Beginners

1. **Start with demo mode** to make sure everything works
2. **Check log files** if something goes wrong
3. **Use full file paths** in configuration (avoid relative paths)
4. **Keep your TFS token secure** - don't share it
5. **Run from Command Prompt** to see error messages

## Getting Help

If you're stuck:
1. Check the log files in `output/logs/`
2. Try demo mode to isolate the problem
3. Verify all file paths exist
4. Make sure Python and libraries are installed correctly

## Advanced Options

### Command Line Arguments
```bash
python main.py --config my_config.json --output-dir ./my_output --log-level DEBUG
```

### Different Log Levels
- DEBUG: Shows everything (lots of detail)
- INFO: Normal operation messages
- WARNING: Important issues
- ERROR: Only errors

This tool helps you track changes across complex projects with submodules, making it easier to understand what pull requests were merged and when!