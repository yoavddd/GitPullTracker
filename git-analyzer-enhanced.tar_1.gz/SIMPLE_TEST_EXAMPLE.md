# Simple Test Example - Step by Step

## What We're Going to Do
We'll test the Git Analyzer with a fake repository and fake TFS data to make sure everything works before you use it with your real data.

## Step 1: Download Everything
Download the **git-analyzer-complete.zip** file (23 KB) and extract all files to a folder.

## Step 2: Quick Test (Windows Users)
1. **Double-click `test_demo.bat`**
2. **Wait for it to finish** (takes about 30 seconds)
3. **Look in the `output` folder** for results

That's it! If this works, you're ready to use the real program.

## Step 2: Manual Test (All Users)
If the batch file doesn't work, do this manually:

### Install Python Libraries
```bash
pip install GitPython requests pandas colorlog tabulate
```

### Create Test Repository
```bash
mkdir test_repo
cd test_repo
git init
git config user.email "test@example.com"
git config user.name "Test User"
echo "# Test Repository" > README.md
git add README.md
git commit -m "Initial commit"
echo "More content" >> README.md
git add README.md
git commit -m "Update README"
cd ..
```

### Create Demo Config
Create file `config_demo.json`:
```json
{
    "tfs_url": "http://test-server:8080/tfs/TestCollection/TestProject/_git/TestRepo",
    "tfs_token": "demo-token",
    "repository_path": "./test_repo",
    "from_commit": "HEAD~1",
    "to_commit": "HEAD",
    "output_directory": "./output",
    "log_level": "INFO",
    "demo_mode": true,
    "skip_tfs_connection": true
}
```

### Run Test
```bash
python main.py --config config_demo.json
```

## What You Should See

### On Screen:
```
============================================================
STARTING GIT SUBMODULE PULL REQUEST ANALYZER
============================================================
Validating configuration...
Configuration validation passed
Initializing components...
TFS Client running in DEMO MODE - will return mock data
All components initialized successfully
STEP 1: Analyzing submodule pointer changes...
STEP 2: Analyzing super project commit range...
STEP 3: Extracting super project pull requests...
STEP 4: Extracting submodule pull requests...
STEP 5: Generating reports...
============================================================
ANALYSIS COMPLETED SUCCESSFULLY
============================================================
```

### Files Created:
In the `output` folder:
- `super_project_prs_[timestamp].csv` - Fake pull request data
- `combined_summary_[timestamp].txt` - Summary report
- `analysis_data_[timestamp].json` - Complete data
- `logs/` folder with detailed logs

## Example Output Files

### CSV File (open in Excel):
| PR_ID | Title | Created_By | Source_Branch | Target_Branch | Status |
|-------|-------|------------|---------------|---------------|---------|
| 1234 | Feature implementation for TestRepo #1 | Developer1 | feature/mock-feature-1 | main | completed |
| 1235 | Feature implementation for TestRepo #2 | Developer2 | feature/mock-feature-2 | main | completed |

### Summary File:
```
PULL REQUEST ANALYSIS SUMMARY REPORT
==================================================

ANALYSIS OVERVIEW
--------------------
Super Project Commit Range: abc123...def456
Total Commits in Super Project: 1
Submodules with Changes: 0
Analysis Date: 2025-06-30 12:34:56

SUPER PROJECT PULL REQUESTS
------------------------------
Total PRs Found: 2
  • PR #1234: Feature implementation for TestRepo #1
  • PR #1235: Feature implementation for TestRepo #2

OVERALL STATISTICS
------------------
Total Pull Requests: 2
Super Project PRs: 2
Submodule PRs: 0
```

## If Something Goes Wrong

### "python is not recognized"
- Install Python from python.org
- Make sure to check "Add to PATH" during installation

### "No module named..."
- Run: `pip install GitPython requests pandas colorlog tabulate`

### "Repository path does not exist"
- Make sure the test_repo folder was created
- Check that git init worked (you should see a .git folder)

### Other Errors
- Look in the `output/logs/` folder for detailed error information
- Check that all files from the zip were extracted properly

## After Test Succeeds

1. **Edit the real `config.json`** with your actual TFS server details
2. **Change `repository_path`** to your real Git repository
3. **Remove the demo mode lines** from config.json
4. **Run `python main.py`** to analyze your real data

## Real Configuration Example
```json
{
    "tfs_url": "http://tfs1:8080/tfs/SilverArrowCollection/VMSC_App/_git/IAFHalcon",
    "tfs_token": "your-real-token-here",
    "repository_path": "C:\\Dev\\your_project\\IAFHalcon",
    "from_commit": "ff54563f82eb31d22ecb78d4263434a471bee70f",
    "to_commit": "0e6a4bef3cbbfa0d79d3cd9fcee81b78d36e2ed7",
    "output_directory": "./output",
    "log_level": "INFO"
}
```

The test creates fake data to make sure everything is working. Once the test passes, you can use your real TFS server and Git repository!