"""
Work Breakdown Structure (WBS) Manager Module
Handles WBS hierarchy and project structure integration with Jira
"""

import json
from typing import Dict, Any, List, Optional
from pathlib import Path

from logger_setup import setup_logger


class WBSStructureManager:
    """Manages Work Breakdown Structure for organizing bugs in Jira project hierarchy"""
    
    def __init__(self, wbs_config: Dict[str, Any]):
        """
        Initialize WBS structure manager
        
        Args:
            wbs_config: WBS configuration from config file
        """
        self.logger = setup_logger()
        self.config = wbs_config
        self.structure = {}
        
        # Default WBS hierarchy if not provided
        self.default_hierarchy = {
            "root_component": "Quality Control",
            "default_epic": "QC-EPIC-001",
            "hierarchy_levels": ["Epic", "Story", "Bug"],
            "categories": {
                "UI": {
                    "epic": "QC-UI-EPIC",
                    "components": ["Frontend", "Mobile", "Web"],
                    "priority_mapping": {
                        "critical": "Highest",
                        "high": "High",
                        "medium": "Medium",
                        "low": "Low"
                    }
                },
                "Backend": {
                    "epic": "QC-BE-EPIC", 
                    "components": ["API", "Database", "Authentication"],
                    "priority_mapping": {
                        "critical": "Highest",
                        "high": "High",
                        "medium": "Medium",
                        "low": "Low"
                    }
                },
                "Performance": {
                    "epic": "QC-PERF-EPIC",
                    "components": ["Load Testing", "Performance"],
                    "priority_mapping": {
                        "critical": "Highest",
                        "high": "High", 
                        "medium": "Medium",
                        "low": "Low"
                    }
                },
                "Security": {
                    "epic": "QC-SEC-EPIC",
                    "components": ["Authentication", "Authorization", "Data Protection"],
                    "priority_mapping": {
                        "critical": "Highest",
                        "high": "High",
                        "medium": "Medium", 
                        "low": "Low"
                    }
                }
            }
        }
        
        self._initialize_structure()
        self.logger.info("WBS Structure Manager initialized")
    
    def _initialize_structure(self) -> None:
        """Initialize WBS structure with configuration and defaults"""
        # Merge provided config with defaults
        for key, value in self.default_hierarchy.items():
            if key not in self.config:
                self.config[key] = value
        
        self.structure = self.config
        self.logger.debug(f"WBS structure initialized: {json.dumps(self.structure, indent=2)}")
    
    def categorize_bug(self, bug_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Categorize bug based on description and summary to determine WBS placement
        
        Args:
            bug_data: Bug information from CSV
            
        Returns:
            Dictionary with WBS placement information
        """
        self.logger.debug(f"Categorizing bug: {bug_data.get('bug_number')}")
        
        summary = bug_data.get('summary', '').lower()
        description = bug_data.get('description', '').lower()
        bug_text = f"{summary} {description}"
        
        # Keyword-based categorization
        ui_keywords = ['ui', 'interface', 'button', 'page', 'mobile', 'screen', 'display', 'layout', 'css', 'html']
        backend_keywords = ['api', 'database', 'server', 'connection', 'timeout', 'authentication', 'login']
        performance_keywords = ['slow', 'performance', 'loading', 'timeout', 'speed', 'delay', 'latency']
        security_keywords = ['security', 'password', 'authentication', 'authorization', 'access', 'permission']
        
        category = "General"
        components = []
        epic = self.structure.get('default_epic', 'QC-EPIC-001')
        
        # Determine category based on keywords
        if any(keyword in bug_text for keyword in ui_keywords):
            category = "UI"
            if 'mobile' in bug_text or 'android' in bug_text or 'ios' in bug_text:
                components = ["Mobile"]
            elif 'page' in bug_text or 'browser' in bug_text:
                components = ["Web"]
            else:
                components = ["Frontend"]
        elif any(keyword in bug_text for keyword in backend_keywords):
            category = "Backend"
            if 'database' in bug_text or 'connection' in bug_text:
                components = ["Database"]
            elif 'api' in bug_text:
                components = ["API"]
            elif 'login' in bug_text or 'authentication' in bug_text:
                components = ["Authentication"]
            else:
                components = ["Backend"]
        elif any(keyword in bug_text for keyword in performance_keywords):
            category = "Performance"
            components = ["Performance"]
        elif any(keyword in bug_text for keyword in security_keywords):
            category = "Security"
            if 'password' in bug_text:
                components = ["Authentication"]
            else:
                components = ["Security"]
        
        # Get category-specific configuration
        category_config = self.structure.get('categories', {}).get(category, {})
        if category_config:
            epic = category_config.get('epic', epic)
            if not components:
                components = category_config.get('components', [])[:1]  # Take first component as default
        
        placement = {
            'category': category,
            'epic': epic,
            'components': components,
            'hierarchy_level': 'Bug',
            'parent_epic': epic
        }
        
        self.logger.info(f"Bug {bug_data.get('bug_number')} categorized as: {category} -> Epic: {epic}")
        
        return placement
    
    def determine_priority(self, bug_data: Dict[str, Any], wbs_placement: Dict[str, Any]) -> str:
        """
        Determine bug priority based on content analysis and WBS category
        
        Args:
            bug_data: Bug information from CSV
            wbs_placement: WBS placement information
            
        Returns:
            Priority level string
        """
        summary = bug_data.get('summary', '').lower()
        description = bug_data.get('description', '').lower()
        bug_text = f"{summary} {description}"
        
        # Critical keywords
        critical_keywords = ['crash', 'crashes', 'critical', 'security', 'data loss', 'cannot login', 'system down']
        high_keywords = ['error', 'fail', 'not working', 'timeout', 'incorrect', 'missing']
        low_keywords = ['cosmetic', 'minor', 'suggestion', 'enhancement', 'improvement']
        
        category = wbs_placement.get('category', 'General')
        
        # Base priority determination
        if any(keyword in bug_text for keyword in critical_keywords):
            base_priority = 'critical'
        elif any(keyword in bug_text for keyword in high_keywords):
            base_priority = 'high'
        elif any(keyword in bug_text for keyword in low_keywords):
            base_priority = 'low'
        else:
            base_priority = 'medium'
        
        # Get category-specific priority mapping
        category_config = self.structure.get('categories', {}).get(category, {})
        priority_mapping = category_config.get('priority_mapping', {
            'critical': 'Highest',
            'high': 'High',
            'medium': 'Medium',
            'low': 'Low'
        })
        
        jira_priority = priority_mapping.get(base_priority, 'Medium')
        
        self.logger.debug(f"Bug {bug_data.get('bug_number')} priority: {base_priority} -> {jira_priority}")
        
        return jira_priority
    
    def enhance_bug_template(self, bug_data: Dict[str, Any], base_template: Dict[str, Any]) -> Dict[str, Any]:
        """
        Enhance bug template with WBS-specific information
        
        Args:
            bug_data: Bug information from CSV
            base_template: Base bug template from configuration
            
        Returns:
            Enhanced template with WBS information
        """
        self.logger.debug(f"Enhancing template for bug: {bug_data.get('bug_number')}")
        
        # Get WBS placement
        wbs_placement = self.categorize_bug(bug_data)
        
        # Create enhanced template
        enhanced_template = base_template.copy()
        
        # Update priority based on WBS analysis
        enhanced_template['priority'] = self.determine_priority(bug_data, wbs_placement)
        
        # Add WBS-specific components
        if wbs_placement.get('components'):
            existing_components = enhanced_template.get('components', [])
            wbs_components = wbs_placement['components']
            enhanced_template['components'] = list(set(existing_components + wbs_components))
        
        # Add WBS-specific labels
        existing_labels = enhanced_template.get('labels', [])
        wbs_labels = [
            f"WBS-{wbs_placement['category']}",
            f"Epic-{wbs_placement['epic']}"
        ]
        enhanced_template['labels'] = list(set(existing_labels + wbs_labels))
        
        # Add epic link if supported
        enhanced_template['epic_link'] = wbs_placement.get('epic')
        
        # Add WBS metadata to custom fields
        custom_fields = enhanced_template.get('custom_fields', {})
        custom_fields.update({
            'wbs_category': wbs_placement['category'],
            'wbs_epic': wbs_placement['epic'],
            'wbs_hierarchy_level': wbs_placement['hierarchy_level']
        })
        enhanced_template['custom_fields'] = custom_fields
        
        # Update product information based on category
        if wbs_placement['category'] != 'General':
            enhanced_template['product'] = f"{enhanced_template.get('product', 'Main Product')} - {wbs_placement['category']}"
        
        self.logger.info(f"Template enhanced for bug {bug_data.get('bug_number')} with WBS category: {wbs_placement['category']}")
        
        return enhanced_template
    
    def get_wbs_summary(self) -> Dict[str, Any]:
        """
        Get summary of WBS structure configuration
        
        Returns:
            Dictionary with WBS summary information
        """
        summary = {
            'root_component': self.structure.get('root_component'),
            'default_epic': self.structure.get('default_epic'),
            'hierarchy_levels': self.structure.get('hierarchy_levels', []),
            'categories': list(self.structure.get('categories', {}).keys()),
            'total_epics': len([cat for cat in self.structure.get('categories', {}).values() if 'epic' in cat])
        }
        
        return summary
    
    def validate_wbs_structure(self) -> Dict[str, Any]:
        """
        Validate WBS structure configuration
        
        Returns:
            Validation results dictionary
        """
        validation = {
            'valid': True,
            'errors': [],
            'warnings': []
        }
        
        required_fields = ['root_component', 'default_epic', 'hierarchy_levels']
        for field in required_fields:
            if field not in self.structure:
                validation['errors'].append(f"Missing required field: {field}")
                validation['valid'] = False
        
        # Validate categories structure
        categories = self.structure.get('categories', {})
        if not categories:
            validation['warnings'].append("No categories defined in WBS structure")
        
        for category_name, category_config in categories.items():
            if 'epic' not in category_config:
                validation['warnings'].append(f"Category '{category_name}' missing epic definition")
            
            if 'components' not in category_config:
                validation['warnings'].append(f"Category '{category_name}' missing components definition")
        
        self.logger.info(f"WBS structure validation: {'PASSED' if validation['valid'] else 'FAILED'}")
        
        return validation
    
    def export_wbs_structure(self, output_path: str) -> None:
        """
        Export WBS structure to JSON file
        
        Args:
            output_path: Path to save the WBS structure
        """
        try:
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(self.structure, f, indent=2, ensure_ascii=False)
            
            self.logger.info(f"WBS structure exported to: {output_path}")
            
        except Exception as e:
            self.logger.error(f"Error exporting WBS structure: {str(e)}")
            raise