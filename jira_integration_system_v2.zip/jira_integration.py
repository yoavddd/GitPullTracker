"""
Jira Integration Module
Handles all interactions with Jira REST API
"""

import requests
import json
import os
from typing import Dict, Any, Optional, List
from urllib.parse import urljoin
from requests.auth import HTTPBasicAuth

from logger_setup import setup_logger


class JiraIntegrator:
    """Handles Jira API integration for creating and managing issues"""
    
    def __init__(self, jira_config: Dict[str, Any]):
        """
        Initialize Jira integrator
        
        Args:
            jira_config: Dictionary containing Jira configuration
        """
        self.logger = setup_logger()
        self.logger.info("Initializing Jira integrator...")
        
        # Get configuration from environment variables with fallbacks
        self.base_url = os.getenv('JIRA_URL', jira_config.get('url', ''))
        self.username = os.getenv('JIRA_USERNAME', jira_config.get('username', ''))
        self.password = os.getenv('JIRA_PASSWORD', jira_config.get('password', ''))
        self.api_token = os.getenv('JIRA_API_TOKEN', jira_config.get('api_token', ''))
        
        # Validate required configuration
        if not self.base_url:
            raise ValueError("Jira URL must be provided via JIRA_URL environment variable or config file")
        
        if not self.username:
            raise ValueError("Jira username must be provided via JIRA_USERNAME environment variable or config file")
        
        if not self.password and not self.api_token:
            raise ValueError("Either JIRA_PASSWORD or JIRA_API_TOKEN must be provided")
        
        # Setup authentication
        if self.api_token:
            self.auth = HTTPBasicAuth(self.username, self.api_token)
            self.logger.info("Using API token authentication")
        else:
            self.auth = HTTPBasicAuth(self.username, self.password)
            self.logger.info("Using password authentication")
        
        # SSL verification setting (important for corporate environments)
        self.verify_ssl = jira_config.get('verify_ssl', True)
        
        # Setup session
        self.session = requests.Session()
        self.session.auth = self.auth
        self.session.verify = self.verify_ssl
        self.session.headers.update({
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        })
        
        # Disable SSL warnings if verification is disabled
        if not self.verify_ssl:
            self.logger.warning("SSL certificate verification is DISABLED - use only for corporate environments with self-signed certificates")
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        
        # API endpoints
        self.api_base = urljoin(self.base_url, '/rest/api/2/')
        self.search_endpoint = urljoin(self.api_base, 'search')
        self.issue_endpoint = urljoin(self.api_base, 'issue')
        
        self.logger.info(f"Jira integrator initialized for URL: {self.base_url}")
    
    def test_connection(self) -> bool:
        """
        Test connection to Jira
        
        Returns:
            True if connection successful, False otherwise
        """
        self.logger.info("Testing Jira connection...")
        
        try:
            response = self.session.get(urljoin(self.api_base, 'myself'))
            
            if response.status_code == 200:
                user_info = response.json()
                self.logger.info(f"Successfully connected to Jira as user: {user_info.get('displayName', 'Unknown')}")
                return True
            else:
                self.logger.error(f"Failed to connect to Jira. Status code: {response.status_code}")
                self.logger.error(f"Response: {response.text}")
                return False
                
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Connection error: {str(e)}")
            return False
    
    def search_issues(self, jql: str, fields: Optional[List[str]] = None, max_results: int = 1000) -> List[Dict[str, Any]]:
        """
        Search for issues using JQL
        
        Args:
            jql: JQL query string
            fields: List of fields to return
            max_results: Maximum number of results to return
            
        Returns:
            List of issue dictionaries
        """
        self.logger.debug(f"Searching issues with JQL: {jql}")
        
        params = {
            'jql': jql,
            'maxResults': max_results,
            'startAt': 0
        }
        
        if fields:
            params['fields'] = ','.join(fields)
        
        try:
            all_issues = []
            start_at = 0
            
            while True:
                params['startAt'] = start_at
                response = self.session.get(self.search_endpoint, params=params)
                
                if response.status_code != 200:
                    self.logger.error(f"Failed to search issues. Status code: {response.status_code}")
                    self.logger.error(f"Response: {response.text}")
                    return []
                
                data = response.json()
                issues = data.get('issues', [])
                all_issues.extend(issues)
                
                self.logger.debug(f"Retrieved {len(issues)} issues (total so far: {len(all_issues)})")
                
                # Check if we have more results
                if len(issues) < max_results or start_at + len(issues) >= data.get('total', 0):
                    break
                
                start_at += len(issues)
            
            self.logger.info(f"Found {len(all_issues)} issues matching JQL query")
            return all_issues
            
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Error searching issues: {str(e)}")
            return []
    
    def get_project_issues(self, project_key: str, fields: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        """
        Get all issues for a specific project
        
        Args:
            project_key: Jira project key
            fields: List of fields to return
            
        Returns:
            List of issue dictionaries
        """
        self.logger.info(f"Getting all issues for project: {project_key}")
        
        jql = f"project = {project_key}"
        return self.search_issues(jql, fields)
    
    def create_issue(self, issue_data: Dict[str, Any]) -> Optional[str]:
        """
        Create a new Jira issue
        
        Args:
            issue_data: Dictionary containing issue data
            
        Returns:
            Issue key if successful, None otherwise
        """
        self.logger.info("Creating new Jira issue...")
        self.logger.debug(f"Issue data: {json.dumps(issue_data, indent=2)}")
        
        try:
            payload = {'fields': issue_data}
            response = self.session.post(self.issue_endpoint, json=payload)
            
            if response.status_code == 201:
                issue_info = response.json()
                issue_key = issue_info.get('key')
                self.logger.info(f"Successfully created issue: {issue_key}")
                return issue_key
            else:
                self.logger.error(f"Failed to create issue. Status code: {response.status_code}")
                self.logger.error(f"Response: {response.text}")
                
                # Try to parse error details
                try:
                    error_data = response.json()
                    if 'errors' in error_data:
                        for field, error_msg in error_data['errors'].items():
                            self.logger.error(f"Field '{field}': {error_msg}")
                    if 'errorMessages' in error_data:
                        for error_msg in error_data['errorMessages']:
                            self.logger.error(f"Error: {error_msg}")
                except:
                    pass
                
                return None
                
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Error creating issue: {str(e)}")
            return None
    
    def get_issue(self, issue_key: str) -> Optional[Dict[str, Any]]:
        """
        Get details of a specific issue
        
        Args:
            issue_key: Jira issue key
            
        Returns:
            Issue dictionary if found, None otherwise
        """
        self.logger.debug(f"Getting issue details for: {issue_key}")
        
        try:
            url = urljoin(self.issue_endpoint, issue_key)
            response = self.session.get(url)
            
            if response.status_code == 200:
                return response.json()
            elif response.status_code == 404:
                self.logger.debug(f"Issue not found: {issue_key}")
                return None
            else:
                self.logger.error(f"Failed to get issue {issue_key}. Status code: {response.status_code}")
                return None
                
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Error getting issue {issue_key}: {str(e)}")
            return None
    
    def update_issue(self, issue_key: str, update_data: Dict[str, Any]) -> bool:
        """
        Update an existing Jira issue
        
        Args:
            issue_key: Jira issue key
            update_data: Dictionary containing update data
            
        Returns:
            True if successful, False otherwise
        """
        self.logger.info(f"Updating issue: {issue_key}")
        self.logger.debug(f"Update data: {json.dumps(update_data, indent=2)}")
        
        try:
            url = urljoin(self.issue_endpoint, issue_key)
            response = self.session.put(url, json={'fields': update_data})
            
            if response.status_code == 204:
                self.logger.info(f"Successfully updated issue: {issue_key}")
                return True
            else:
                self.logger.error(f"Failed to update issue {issue_key}. Status code: {response.status_code}")
                self.logger.error(f"Response: {response.text}")
                return False
                
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Error updating issue {issue_key}: {str(e)}")
            return False
    
    def get_project_info(self, project_key: str) -> Optional[Dict[str, Any]]:
        """
        Get project information
        
        Args:
            project_key: Jira project key
            
        Returns:
            Project information dictionary if found, None otherwise
        """
        self.logger.debug(f"Getting project info for: {project_key}")
        
        try:
            url = urljoin(self.api_base, f'project/{project_key}')
            response = self.session.get(url)
            
            if response.status_code == 200:
                project_info = response.json()
                self.logger.debug(f"Project {project_key} found: {project_info.get('name', 'Unknown')}")
                return project_info
            elif response.status_code == 404:
                self.logger.error(f"Project not found: {project_key}")
                return None
            else:
                self.logger.error(f"Failed to get project {project_key}. Status code: {response.status_code}")
                return None
                
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Error getting project {project_key}: {str(e)}")
            return None
    
    def get_issue_types(self, project_key: str) -> List[Dict[str, Any]]:
        """
        Get available issue types for a project
        
        Args:
            project_key: Jira project key
            
        Returns:
            List of issue type dictionaries
        """
        self.logger.debug(f"Getting issue types for project: {project_key}")
        
        project_info = self.get_project_info(project_key)
        if not project_info:
            return []
        
        issue_types = project_info.get('issueTypes', [])
        self.logger.debug(f"Found {len(issue_types)} issue types")
        
        return issue_types
