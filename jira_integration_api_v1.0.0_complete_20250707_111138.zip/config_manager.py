import logging
import json
import os
from typing import Dict, Any
from jsonschema import validate, ValidationError

logger = logging.getLogger(__name__)

class ConfigManager:
    """Manager for configuration files"""
    
    def __init__(self, config_path: str):
        """Initialize config manager with path"""
        self.config_path = config_path
        self.config = None
        
        logger.info(f"Initialized config manager for: {config_path}")
    
    def load_config(self) -> Dict[str, Any]:
        """Load configuration from JSON file"""
        try:
            if not os.path.exists(self.config_path):
                raise FileNotFoundError(f"Configuration file not found: {self.config_path}")
            
            with open(self.config_path, 'r', encoding='utf-8') as file:
                self.config = json.load(file)
            
            logger.info("Configuration loaded successfully")
            
            # Validate configuration
            self.validate_config()
            
            return self.config
            
        except Exception as e:
            logger.error(f"Error loading configuration: {str(e)}")
            raise
    
    def validate_config(self) -> None:
        """Validate configuration against schema"""
        try:
            schema = self.get_config_schema()
            validate(instance=self.config, schema=schema)
            logger.info("Configuration validation successful")
            
        except ValidationError as e:
            logger.error(f"Configuration validation failed: {e.message}")
            raise Exception(f"Invalid configuration: {e.message}")
        except Exception as e:
            logger.error(f"Error validating configuration: {str(e)}")
            raise
    
    def get_config_schema(self) -> Dict[str, Any]:
        """Get JSON schema for configuration validation"""
        return {
            "type": "object",
            "properties": {
                "jira": {
                    "type": "object",
                    "properties": {
                        "url": {"type": "string"},
                        "username": {"type": "string"},
                        "password": {"type": "string"},
                        "project_key": {"type": "string"},
                        "epic_key": {"type": "string"},
                        "structure_board_id": {"type": "string"}
                    },
                    "required": ["url", "username", "password", "project_key"]
                },
                "constants": {
                    "type": "object",
                    "properties": {
                        "issue_type": {"type": "string"},
                        "assignee": {"type": "string"},
                        "reporter": {"type": "string"},
                        "priority": {"type": "string"},
                        "components": {
                            "type": "array",
                            "items": {"type": "string"}
                        },
                        "labels": {
                            "type": "array",
                            "items": {"type": "string"}
                        },
                        "custom_fields": {"type": "object"}
                    }
                }
            },
            "required": ["jira"]
        }
    
    def create_default_config(self, output_path: str) -> bool:
        """Create a default configuration file"""
        try:
            default_config = {
                "jira": {
                    "url": "https://jira.eal.corp.el.co.il",
                    "username": "user",
                    "password": "pass",
                    "project_key": "123",
                    "epic_key": "ASUVNG-1840",
                    "structure_board_id": "5062"
                },
                "constants": {
                    "issue_type": "Bug",
                    "assignee": "",
                    "reporter": "",
                    "priority": "Medium",
                    "components": [],
                    "labels": ["QC", "CSV_IMPORT"],
                    "custom_fields": {}
                },
                "processing": {
                    "batch_size": 10,
                    "retry_attempts": 3,
                    "retry_delay": 5
                }
            }
            
            with open(output_path, 'w', encoding='utf-8') as file:
                json.dump(default_config, file, indent=2)
            
            logger.info(f"Created default configuration file: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error creating default configuration: {str(e)}")
            return False
    
    def get_jira_config(self) -> Dict[str, Any]:
        """Get JIRA-specific configuration"""
        if not self.config:
            raise Exception("Configuration not loaded")
        
        return self.config.get('jira', {})
    
    def get_constants(self) -> Dict[str, Any]:
        """Get constant values for JIRA issues"""
        if not self.config:
            raise Exception("Configuration not loaded")
        
        return self.config.get('constants', {})
    
    def get_processing_config(self) -> Dict[str, Any]:
        """Get processing configuration"""
        if not self.config:
            raise Exception("Configuration not loaded")
        
        return self.config.get('processing', {
            'batch_size': 10,
            'retry_attempts': 3,
            'retry_delay': 5
        })
    
    def update_config(self, updates: Dict[str, Any]) -> bool:
        """Update configuration with new values"""
        try:
            if not self.config:
                raise Exception("Configuration not loaded")
            
            # Deep update
            self._deep_update(self.config, updates)
            
            # Validate updated config
            self.validate_config()
            
            # Save to file
            with open(self.config_path, 'w', encoding='utf-8') as file:
                json.dump(self.config, file, indent=2)
            
            logger.info("Configuration updated successfully")
            return True
            
        except Exception as e:
            logger.error(f"Error updating configuration: {str(e)}")
            return False
    
    def _deep_update(self, base_dict: Dict, update_dict: Dict) -> None:
        """Deep update dictionary"""
        for key, value in update_dict.items():
            if isinstance(value, dict) and key in base_dict and isinstance(base_dict[key], dict):
                self._deep_update(base_dict[key], value)
            else:
                base_dict[key] = value
    
    def export_config_template(self, output_path: str) -> bool:
        """Export configuration template with comments"""
        try:
            template = {
                "_comment": "JIRA Integration Configuration File",
                "_instructions": {
                    "jira": "JIRA connection settings",
                    "constants": "Default values for created issues",
                    "processing": "Processing behavior settings"
                },
                "jira": {
                    "url": "https://your-jira-instance.com",
                    "username": "your-username",
                    "password": "your-password",
                    "project_key": "PROJECT",
                    "epic_key": "EPIC-123",
                    "structure_board_id": "1234"
                },
                "constants": {
                    "issue_type": "Bug",
                    "assignee": "username",
                    "reporter": "username",
                    "priority": "Medium",
                    "components": ["Component1", "Component2"],
                    "labels": ["QC", "CSV_IMPORT"],
                    "custom_fields": {
                        "customfield_10001": "Custom Value"
                    }
                },
                "processing": {
                    "batch_size": 10,
                    "retry_attempts": 3,
                    "retry_delay": 5
                }
            }
            
            with open(output_path, 'w', encoding='utf-8') as file:
                json.dump(template, file, indent=2)
            
            logger.info(f"Exported configuration template: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error exporting template: {str(e)}")
            return False
