import logging
import pandas as pd
from typing import List, Dict
import os
import chardet

logger = logging.getLogger(__name__)

class CSVProcessor:
    """Service for processing CSV files containing defect data"""
    
    def __init__(self, csv_path: str):
        """Initialize CSV processor with file path"""
        self.csv_path = csv_path
        self.df = None
        
        logger.info(f"Initialized CSV processor for file: {csv_path}")
    
    def detect_encoding(self) -> str:
        """Detect file encoding"""
        try:
            with open(self.csv_path, 'rb') as file:
                raw_data = file.read()
                result = chardet.detect(raw_data)
                encoding = result['encoding']
                confidence = result['confidence']
                
                logger.info(f"Detected encoding: {encoding} (confidence: {confidence})")
                return encoding
                
        except Exception as e:
            logger.error(f"Error detecting encoding: {str(e)}")
            return 'utf-8'  # Default fallback
    
    def load_defects(self) -> List[Dict]:
        """Load defects from CSV file"""
        try:
            # Check if file exists
            if not os.path.exists(self.csv_path):
                raise FileNotFoundError(f"CSV file not found: {self.csv_path}")
            
            # Detect encoding
            encoding = self.detect_encoding()
            
            # Try to read as CSV first
            try:
                self.df = pd.read_csv(self.csv_path, encoding=encoding)
                logger.info("Successfully loaded CSV file")
            except Exception as csv_error:
                logger.warning(f"Failed to load as CSV: {csv_error}")
                
                # Try to read as Excel file
                try:
                    self.df = pd.read_excel(self.csv_path)
                    logger.info("Successfully loaded Excel file")
                except Exception as excel_error:
                    logger.error(f"Failed to load as Excel: {excel_error}")
                    raise Exception(f"Failed to load file as CSV or Excel: {csv_error}")
            
            # Validate DataFrame
            if self.df.empty:
                raise ValueError("CSV file is empty")
            
            logger.info(f"Loaded {len(self.df)} rows from CSV")
            logger.info(f"Columns: {list(self.df.columns)}")
            
            # Clean column names (remove spaces, convert to lowercase)
            self.df.columns = self.df.columns.str.strip().str.lower().str.replace(' ', '_')
            
            # Convert to list of dictionaries
            defects = []
            for index, row in self.df.iterrows():
                defect = {}
                for col in self.df.columns:
                    value = row[col]
                    # Handle NaN values
                    if pd.isna(value):
                        defect[col] = ''
                    else:
                        defect[col] = str(value).strip()
                
                # Ensure defect_id exists
                if 'defect_id' not in defect:
                    # Try common variations
                    for possible_id_col in ['id', 'defect_id', 'bug_id', 'issue_id', 'qc_id']:
                        if possible_id_col in defect:
                            defect['defect_id'] = defect[possible_id_col]
                            break
                    else:
                        # Use row index as fallback
                        defect['defect_id'] = str(index + 1)
                        logger.warning(f"No defect_id found for row {index + 1}, using row number")
                
                defects.append(defect)
            
            logger.info(f"Processed {len(defects)} defects")
            return defects
            
        except Exception as e:
            logger.error(f"Error loading defects from CSV: {str(e)}")
            raise
    
    def validate_defects(self, defects: List[Dict]) -> List[str]:
        """Validate defects and return list of validation errors"""
        errors = []
        
        try:
            for i, defect in enumerate(defects):
                row_num = i + 1
                
                # Check for required fields
                if not defect.get('defect_id'):
                    errors.append(f"Row {row_num}: Missing defect_id")
                
                # Check for empty summary
                if not defect.get('summary') and not defect.get('title'):
                    errors.append(f"Row {row_num}: Missing summary/title")
                
                # Validate defect_id format (should be alphanumeric)
                defect_id = defect.get('defect_id', '')
                if defect_id and not defect_id.replace('-', '').replace('_', '').isalnum():
                    errors.append(f"Row {row_num}: Invalid defect_id format: {defect_id}")
            
            logger.info(f"Validation completed. Found {len(errors)} errors")
            return errors
            
        except Exception as e:
            logger.error(f"Error validating defects: {str(e)}")
            return [f"Validation error: {str(e)}"]
    
    def get_column_mapping(self) -> Dict[str, str]:
        """Get mapping of CSV columns to standard field names"""
        if self.df is None:
            return {}
        
        column_mapping = {}
        columns = list(self.df.columns)
        
        # Common column mappings
        mappings = {
            'defect_id': ['id', 'defect_id', 'bug_id', 'issue_id', 'qc_id'],
            'summary': ['summary', 'title', 'subject', 'description'],
            'description': ['description', 'details', 'bug_description', 'issue_description'],
            'detected_by': ['detected_by', 'found_by', 'reporter', 'tester'],
            'assigned_to': ['assigned_to', 'assignee', 'owner'],
            'priority': ['priority', 'severity'],
            'status': ['status', 'state'],
            'component': ['component', 'module', 'area'],
            'version': ['version', 'build', 'release']
        }
        
        for standard_name, possible_names in mappings.items():
            for possible_name in possible_names:
                if possible_name in columns:
                    column_mapping[standard_name] = possible_name
                    break
        
        logger.info(f"Column mapping: {column_mapping}")
        return column_mapping
    
    def get_sample_data(self, num_rows: int = 5) -> List[Dict]:
        """Get sample data for preview"""
        if self.df is None:
            return []
        
        sample_df = self.df.head(num_rows)
        sample_data = []
        
        for index, row in sample_df.iterrows():
            sample_row = {}
            for col in self.df.columns:
                value = row[col]
                if pd.isna(value):
                    sample_row[col] = ''
                else:
                    sample_row[col] = str(value).strip()
            sample_data.append(sample_row)
        
        return sample_data
    
    def export_processed_data(self, output_path: str) -> bool:
        """Export processed data to CSV"""
        try:
            if self.df is None:
                logger.error("No data to export")
                return False
            
            self.df.to_csv(output_path, index=False)
            logger.info(f"Exported processed data to: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error exporting data: {str(e)}")
            return False
