// Main JavaScript for JIRA Integration API

document.addEventListener('DOMContentLoaded', function() {
    // Initialize Feather icons
    feather.replace();
    
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // File upload handling
    const uploadForm = document.getElementById('uploadForm');
    if (uploadForm) {
        setupFileUpload(uploadForm);
    }
    
    // Table sorting
    const sortableTables = document.querySelectorAll('.table-sortable');
    sortableTables.forEach(setupTableSorting);
    
    // Progress bar animations
    const progressBars = document.querySelectorAll('.progress-bar');
    progressBars.forEach(animateProgressBar);
    
    // Auto-refresh for processing results
    if (window.location.pathname.includes('/results/')) {
        setupAutoRefresh();
    }
});

function setupFileUpload(form) {
    const fileInputs = form.querySelectorAll('input[type="file"]');
    const submitButton = form.querySelector('button[type="submit"]');
    
    // File validation
    fileInputs.forEach(input => {
        input.addEventListener('change', function() {
            validateFile(this);
        });
    });
    
    // Form submission
    form.addEventListener('submit', function(e) {
        if (!validateForm(form)) {
            e.preventDefault();
            return;
        }
        
        // Show processing modal
        showProcessingModal();
        
        // Disable submit button
        submitButton.disabled = true;
        submitButton.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Processing...';
    });
}

function validateFile(input) {
    const file = input.files[0];
    if (!file) return;
    
    const maxSize = 16 * 1024 * 1024; // 16MB
    const allowedTypes = {
        'csv_file': ['.csv', '.xlsx', '.xls'],
        'config_file': ['.json']
    };
    
    // Check file size
    if (file.size > maxSize) {
        showAlert('File size must be less than 16MB', 'danger');
        input.value = '';
        return false;
    }
    
    // Check file type
    const allowedExtensions = allowedTypes[input.name] || [];
    const fileExtension = '.' + file.name.split('.').pop().toLowerCase();
    
    if (!allowedExtensions.includes(fileExtension)) {
        showAlert(`Invalid file type. Allowed types: ${allowedExtensions.join(', ')}`, 'danger');
        input.value = '';
        return false;
    }
    
    // Show file info
    showFileInfo(input, file);
    return true;
}

function showFileInfo(input, file) {
    const fileSize = (file.size / 1024 / 1024).toFixed(2);
    const infoElement = input.parentElement.querySelector('.file-info');
    
    if (infoElement) {
        infoElement.remove();
    }
    
    const info = document.createElement('div');
    info.className = 'file-info mt-2 text-muted small';
    info.innerHTML = `
        <i data-feather="file"></i>
        ${file.name} (${fileSize} MB)
    `;
    
    input.parentElement.appendChild(info);
    feather.replace();
}

function validateForm(form) {
    const requiredInputs = form.querySelectorAll('input[required]');
    let isValid = true;
    
    requiredInputs.forEach(input => {
        if (!input.value.trim()) {
            showAlert(`Please fill in the ${input.name.replace('_', ' ')} field`, 'danger');
            isValid = false;
        }
    });
    
    return isValid;
}

function showProcessingModal() {
    const modal = document.getElementById('processingModal');
    if (modal) {
        const bootstrapModal = new bootstrap.Modal(modal);
        bootstrapModal.show();
    }
}

function showAlert(message, type = 'info') {
    const alertContainer = document.createElement('div');
    alertContainer.className = `alert alert-${type} alert-dismissible fade show`;
    alertContainer.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    const container = document.querySelector('.container');
    container.insertBefore(alertContainer, container.firstChild);
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        alertContainer.remove();
    }, 5000);
}

function setupTableSorting(table) {
    const headers = table.querySelectorAll('th');
    
    headers.forEach((header, index) => {
        if (header.classList.contains('sortable')) {
            header.style.cursor = 'pointer';
            header.addEventListener('click', () => sortTable(table, index));
        }
    });
}

function sortTable(table, columnIndex) {
    const tbody = table.querySelector('tbody');
    const rows = Array.from(tbody.querySelectorAll('tr'));
    
    const isAscending = table.getAttribute('data-sort-direction') !== 'asc';
    
    rows.sort((a, b) => {
        const aValue = a.cells[columnIndex].textContent.trim();
        const bValue = b.cells[columnIndex].textContent.trim();
        
        if (isAscending) {
            return aValue.localeCompare(bValue);
        } else {
            return bValue.localeCompare(aValue);
        }
    });
    
    rows.forEach(row => tbody.appendChild(row));
    table.setAttribute('data-sort-direction', isAscending ? 'asc' : 'desc');
}

function animateProgressBar(progressBar) {
    const targetWidth = progressBar.style.width;
    const targetValue = parseInt(targetWidth);
    
    progressBar.style.width = '0%';
    
    setTimeout(() => {
        progressBar.style.transition = 'width 1s ease-in-out';
        progressBar.style.width = targetWidth;
        
        // Animate the text
        let currentValue = 0;
        const increment = targetValue / 50;
        
        const interval = setInterval(() => {
            currentValue += increment;
            if (currentValue >= targetValue) {
                currentValue = targetValue;
                clearInterval(interval);
            }
            progressBar.textContent = currentValue.toFixed(1) + '%';
        }, 20);
    }, 100);
}

function setupAutoRefresh() {
    // Check if processing is still ongoing
    const processingIndicator = document.querySelector('.processing-indicator');
    if (processingIndicator) {
        const refreshInterval = setInterval(() => {
            fetch(window.location.href)
                .then(response => response.text())
                .then(html => {
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(html, 'text/html');
                    const newProcessingIndicator = doc.querySelector('.processing-indicator');
                    
                    if (!newProcessingIndicator) {
                        // Processing complete, reload page
                        clearInterval(refreshInterval);
                        location.reload();
                    }
                })
                .catch(error => {
                    console.error('Error checking processing status:', error);
                    clearInterval(refreshInterval);
                });
        }, 5000); // Check every 5 seconds
    }
}

// Utility functions
function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
}

function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showAlert('Copied to clipboard!', 'success');
    }).catch(() => {
        showAlert('Failed to copy to clipboard', 'danger');
    });
}

// Export functions for use in other scripts
window.JiraIntegration = {
    showAlert,
    formatBytes,
    formatDate,
    copyToClipboard
};
