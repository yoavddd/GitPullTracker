#!/usr/bin/env python3
"""
Test script for JIRA connection using base64 authentication
"""

import logging
import sys
from jira_service import JiraService
from config_manager import ConfigManager

# Set up logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

def test_jira_connection():
    """Test JIRA connection and basic operations"""
    try:
        logger.info("Starting JIRA connection test...")
        
        # Load configuration
        config_manager = ConfigManager('config/jira_config.json')
        config = config_manager.load_config()
        
        jira_config = config['jira']
        logger.info(f"Testing connection to: {jira_config['url']}")
        logger.info(f"Project: {jira_config['project_key']}")
        logger.info(f"Epic: {jira_config['epic_key']}")
        
        # Initialize JIRA service
        jira_service = JiraService(
            url=jira_config['url'],
            username=jira_config['username'],
            password=jira_config['password']
        )
        
        # Test 1: Basic connection
        logger.info("=" * 50)
        logger.info("TEST 1: Testing basic connection...")
        if jira_service.test_connection():
            logger.info("✓ JIRA connection successful!")
        else:
            logger.error("✗ JIRA connection failed!")
            return False
        
        # Test 2: Project access
        logger.info("=" * 50)
        logger.info("TEST 2: Testing project access...")
        project_info = jira_service.get_project_info(jira_config['project_key'])
        if project_info:
            logger.info(f"✓ Project access successful! Project: {project_info.get('name', 'Unknown')}")
            logger.info(f"  - Key: {project_info.get('key')}")
            logger.info(f"  - Description: {project_info.get('description', 'No description')}")
        else:
            logger.warning(f"✗ Cannot access project: {jira_config['project_key']}")
        
        # Test 3: Issue types
        logger.info("=" * 50)
        logger.info("TEST 3: Testing issue types...")
        issue_types = jira_service.get_issue_types(jira_config['project_key'])
        if issue_types:
            logger.info(f"✓ Found {len(issue_types)} issue types:")
            for issue_type in issue_types[:5]:  # Show first 5
                logger.info(f"  - {issue_type.get('name')} (ID: {issue_type.get('id')})")
        else:
            logger.warning("✗ No issue types found")
        
        # Test 4: Search for existing issues
        logger.info("=" * 50)
        logger.info("TEST 4: Testing issue search...")
        
        # Search for existing QC ID patterns
        test_patterns = ["QC ID# 37465", "QC ID# 12345", "QC ID# 99999"]
        for pattern in test_patterns:
            logger.info(f"Searching for pattern: {pattern}")
            existing_issue = jira_service.search_issue_by_summary(pattern, jira_config['project_key'])
            if existing_issue:
                logger.info(f"  ✓ Found existing issue: {existing_issue}")
            else:
                logger.info(f"  - No existing issue found for pattern: {pattern}")
        
        # Test 5: Structure board search
        logger.info("=" * 50)
        logger.info("TEST 5: Testing structure board search...")
        issues = jira_service.search_issues_in_structure(
            jira_config['structure_board_id'], 
            jira_config['project_key']
        )
        logger.info(f"✓ Found {len(issues)} issues in structure board")
        if issues:
            logger.info("Sample issues:")
            for issue in issues[:3]:  # Show first 3
                logger.info(f"  - {issue['key']}: {issue['fields']['summary']}")
        
        logger.info("=" * 50)
        logger.info("🎉 All JIRA connection tests completed successfully!")
        return True
        
    except Exception as e:
        logger.error(f"❌ JIRA connection test failed: {str(e)}")
        return False

def test_csv_processing():
    """Test CSV processing with sample data"""
    try:
        logger.info("=" * 50)
        logger.info("TESTING CSV PROCESSING...")
        
        from csv_processor import CSVProcessor
        
        # Test with the sample CSV file
        csv_processor = CSVProcessor('sample_defects.csv')
        defects = csv_processor.load_defects()
        
        logger.info(f"✓ Loaded {len(defects)} defects from CSV")
        
        # Show sample defect
        if defects:
            sample_defect = defects[0]
            logger.info("Sample defect structure:")
            for key, value in sample_defect.items():
                logger.info(f"  {key}: {value}")
        
        # Validate defects
        errors = csv_processor.validate_defects(defects)
        if errors:
            logger.warning(f"Validation errors found: {len(errors)}")
            for error in errors:
                logger.warning(f"  - {error}")
        else:
            logger.info("✓ All defects passed validation")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ CSV processing test failed: {str(e)}")
        return False

if __name__ == "__main__":
    print("\n🚀 JIRA Integration API - Connection Test")
    print("=" * 60)
    
    # Test CSV processing first
    if not test_csv_processing():
        print("❌ CSV processing test failed")
        sys.exit(1)
    
    # Test JIRA connection
    if not test_jira_connection():
        print("❌ JIRA connection test failed")
        print("\n💡 Please check:")
        print("1. JIRA URL is correct")
        print("2. Username and password are valid")
        print("3. User has access to the specified project")
        print("4. Network connectivity to JIRA instance")
        sys.exit(1)
    
    print("\n🎉 All tests passed! The JIRA Integration API is ready to use.")
    print("\nNext steps:")
    print("1. Update config/jira_config.json with your actual JIRA credentials")
    print("2. Run the Flask application: python main.py")
    print("3. Access the web interface at http://localhost:5000")