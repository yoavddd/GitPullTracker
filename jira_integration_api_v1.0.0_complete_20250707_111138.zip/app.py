import os
import logging
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file
from werkzeug.utils import secure_filename
from werkzeug.middleware.proxy_fix import ProxyFix
import json
from datetime import datetime
import uuid

from jira_service import JiraService
from csv_processor import CSVProcessor
from config_manager import ConfigManager
from zip_generator import ZipGenerator

# Configure logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/app.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-change-in-production")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Configuration
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['OUTPUT_FOLDER'] = 'output'

# Allowed file extensions
ALLOWED_EXTENSIONS = {'csv', 'xlsx', 'xls'}

# Ensure directories exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['OUTPUT_FOLDER'], exist_ok=True)
os.makedirs('logs', exist_ok=True)

def allowed_file(filename):
    """Check if file extension is allowed"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Global variables to store processing results
processing_results = {}

@app.route('/')
def index():
    """Main page"""
    logger.info("Accessing main page")
    return render_template('index.html')

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    """Upload CSV file and configuration"""
    if request.method == 'GET':
        return render_template('upload.html')
    
    try:
        # Check if files were uploaded
        if 'csv_file' not in request.files or 'config_file' not in request.files:
            flash('Please upload both CSV and configuration files', 'error')
            return redirect(request.url)
        
        csv_file = request.files['csv_file']
        config_file = request.files['config_file']
        
        if csv_file.filename == '' or config_file.filename == '':
            flash('Please select both files', 'error')
            return redirect(request.url)
        
        if not (allowed_file(csv_file.filename) and config_file.filename.endswith('.json')):
            flash('Invalid file types. Please upload CSV and JSON files', 'error')
            return redirect(request.url)
        
        # Save files
        csv_filename = secure_filename(csv_file.filename)
        config_filename = secure_filename(config_file.filename)
        
        # Add timestamp to avoid conflicts
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        csv_filename = f"{timestamp}_{csv_filename}"
        config_filename = f"{timestamp}_{config_filename}"
        
        csv_path = os.path.join(app.config['UPLOAD_FOLDER'], csv_filename)
        config_path = os.path.join(app.config['UPLOAD_FOLDER'], config_filename)
        
        csv_file.save(csv_path)
        config_file.save(config_path)
        
        logger.info(f"Files uploaded: {csv_filename}, {config_filename}")
        
        # Process files
        session_id = str(uuid.uuid4())
        result = process_defects(csv_path, config_path, session_id)
        
        # Store results for display
        processing_results[session_id] = result
        
        return redirect(url_for('results', session_id=session_id))
        
    except Exception as e:
        logger.error(f"Error in upload: {str(e)}")
        flash(f'Error processing files: {str(e)}', 'error')
        return redirect(request.url)

@app.route('/results/<session_id>')
def results(session_id):
    """Display processing results"""
    if session_id not in processing_results:
        flash('Session not found', 'error')
        return redirect(url_for('index'))
    
    result = processing_results[session_id]
    return render_template('results.html', result=result, session_id=session_id)

@app.route('/download_zip/<session_id>')
def download_zip(session_id):
    """Download ZIP file with project files"""
    try:
        zip_generator = ZipGenerator()
        zip_path = zip_generator.create_project_zip()
        
        return send_file(zip_path, as_attachment=True, download_name='jira_integration_project.zip')
        
    except Exception as e:
        logger.error(f"Error generating ZIP: {str(e)}")
        flash(f'Error generating ZIP file: {str(e)}', 'error')
        return redirect(url_for('results', session_id=session_id))

@app.route('/download_logs/<session_id>')
def download_logs(session_id):
    """Download processing logs"""
    try:
        log_path = 'logs/app.log'
        if os.path.exists(log_path):
            return send_file(log_path, as_attachment=True, download_name='processing_logs.log')
        else:
            flash('Log file not found', 'error')
            return redirect(url_for('results', session_id=session_id))
            
    except Exception as e:
        logger.error(f"Error downloading logs: {str(e)}")
        flash(f'Error downloading logs: {str(e)}', 'error')
        return redirect(url_for('results', session_id=session_id))

def process_defects(csv_path, config_path, session_id):
    """Process defects from CSV file"""
    logger.info(f"Starting defect processing for session {session_id}")
    
    result = {
        'session_id': session_id,
        'total_defects': 0,
        'processed': 0,
        'created': 0,
        'skipped': 0,
        'errors': 0,
        'details': [],
        'error_messages': []
    }
    
    try:
        # Load configuration
        config_manager = ConfigManager(config_path)
        config = config_manager.load_config()
        
        # Initialize JIRA service
        jira_service = JiraService(
            url=config['jira']['url'],
            username=config['jira']['username'],
            password=config['jira']['password']
        )
        
        # Test JIRA connection
        if not jira_service.test_connection():
            raise Exception("Failed to connect to JIRA")
        
        # Initialize CSV processor
        csv_processor = CSVProcessor(csv_path)
        defects = csv_processor.load_defects()
        
        result['total_defects'] = len(defects)
        logger.info(f"Loaded {len(defects)} defects from CSV")
        
        # Process each defect
        for defect in defects:
            defect_id = defect.get('defect_id', '')
            logger.info(f"Processing defect ID: {defect_id}")
            
            try:
                # Check if defect already exists
                search_pattern = f"QC ID# {defect_id}"
                existing_issue = jira_service.search_issue_by_summary(
                    search_pattern, 
                    config['jira']['project_key']
                )
                
                if existing_issue:
                    logger.info(f"Defect {defect_id} already exists in JIRA: {existing_issue}")
                    result['skipped'] += 1
                    result['details'].append({
                        'defect_id': defect_id,
                        'status': 'skipped',
                        'message': f'Already exists: {existing_issue}'
                    })
                else:
                    # Create new JIRA issue
                    issue_key = jira_service.create_issue(defect, config)
                    logger.info(f"Created JIRA issue {issue_key} for defect {defect_id}")
                    result['created'] += 1
                    result['details'].append({
                        'defect_id': defect_id,
                        'status': 'created',
                        'message': f'Created issue: {issue_key}'
                    })
                
                result['processed'] += 1
                
            except Exception as e:
                logger.error(f"Error processing defect {defect_id}: {str(e)}")
                result['errors'] += 1
                result['error_messages'].append(f"Defect {defect_id}: {str(e)}")
                result['details'].append({
                    'defect_id': defect_id,
                    'status': 'error',
                    'message': str(e)
                })
        
        logger.info(f"Processing completed. Created: {result['created']}, Skipped: {result['skipped']}, Errors: {result['errors']}")
        
    except Exception as e:
        logger.error(f"Fatal error in process_defects: {str(e)}")
        result['error_messages'].append(f"Fatal error: {str(e)}")
    
    return result

@app.errorhandler(413)
def too_large(e):
    """Handle file too large error"""
    flash('File is too large. Maximum size is 16MB', 'error')
    return redirect(url_for('upload'))

@app.errorhandler(404)
def not_found(e):
    """Handle 404 errors"""
    return render_template('index.html'), 404

@app.errorhandler(500)
def internal_error(e):
    """Handle internal server errors"""
    logger.error(f"Internal server error: {str(e)}")
    flash('An internal error occurred. Please check the logs.', 'error')
    return redirect(url_for('index'))

if __name__ == '__main__':
    logger.info("Starting JIRA Integration API")
    app.run(host='0.0.0.0', port=5000, debug=True)
