# JIRA Integration API v1.0.0

A Flask-based API for processing CSV defect files and automatically creating JIRA issues while preventing duplicates.

## Features

- **CSV/Excel Processing**: Support for both CSV and Excel file formats with automatic encoding detection
- **JIRA Integration**: Full JIRA REST API v2 integration with base64 authentication
- **Duplicate Prevention**: Searches for existing issues using "QC ID# {defect_id}" pattern matching
- **Configurable Constants**: JSON-based configuration for default issue values (assignee, reporter, priority, etc.)
- **Comprehensive Logging**: Detailed logging for all operations and troubleshooting
- **Web Interface**: Bootstrap-based responsive UI with dark theme
- **Batch Processing**: Handles multiple defects efficiently with error handling
- **Project Export**: Built-in ZIP generator for complete project packaging

## System Requirements

- Python 3.11+
- Flask web framework
- Access to JIRA instance with issue creation permissions
- Network connectivity to JIRA server

## Quick Start

### 1. Installation

```bash
# Install Python dependencies
pip install -r requirements.txt
```

### 2. Configuration

Update `config/jira_config.json` with your JIRA settings:

```json
{
  "jira": {
    "url": "https://your-jira-instance.com",
    "username": "your-username",
    "password": "your-password",
    "project_key": "YOUR_PROJECT",
    "epic_key": "EPIC-123",
    "structure_board_id": "1234"
  },
  "constants": {
    "issue_type": "Bug",
    "assignee": "developer-username",
    "reporter": "qa-username",
    "priority": "Medium",
    "components": ["ComponentName"],
    "labels": ["QC", "CSV_IMPORT"]
  }
}
```

### 3. Environment Setup

```bash
export SESSION_SECRET="your-secret-key-for-flask-sessions"
```

### 4. Run Application

```bash
python main.py
```

Access the web interface at: http://localhost:5000

## How It Works

### Workflow Overview

1. **CSV Upload**: User uploads CSV file containing defect data
2. **Configuration**: User uploads JSON configuration file with JIRA settings
3. **Processing Pipeline**:
   - Load and validate CSV data
   - Connect to JIRA using base64 authentication
   - For each defect ID, search JIRA for existing issues with pattern "QC ID# {defect_id}"
   - Create new JIRA issues only for defects that don't already exist
   - Apply constant values from configuration (assignee, reporter, etc.)
   - Map all CSV columns to JIRA issue description
4. **Results**: Display processing results with statistics and issue details
5. **Export**: Download logs and project files

### CSV File Format

Your CSV file should contain these columns:

| Column | Description | Required |
|--------|-------------|----------|
| `Defect ID` | Unique identifier for the defect | Yes |
| `Summary` | Brief description of the issue | Recommended |
| `Description` | Detailed description | Recommended |
| `Detected By` | Name of person who found the defect | Optional |
| `Assigned To` | Name of person assigned to fix | Optional |
| `Priority` | Priority level (High/Medium/Low) | Optional |
| `Status` | Current status | Optional |
| `Detected in Block` | Development block/version | Optional |
| `Sys / Sub-Sys / Component / CSCI` | System component | Optional |
| `Defect Type` | Type of defect (Software/Hardware) | Optional |

**Note**: The system automatically maps column names and handles variations like "defect_id", "bug_id", etc.

### JIRA Integration Details

#### Authentication
- Uses HTTP Basic Authentication with base64 encoding
- Format: `Authorization: Basic base64(username:password)`

#### Issue Creation
- Creates issues in specified project with configured epic as parent
- Summary format: "QC ID# {defect_id} - {summary}"
- All CSV data mapped to issue description using JIRA markup
- Applies constant values from JSON configuration

#### Duplicate Detection
- Searches existing issues using JQL: `project = "PROJECT" AND summary ~ "QC ID# {defect_id}"`
- Skips creation if matching issue found
- Logs all duplicate detection results

## API Endpoints

- `GET /` - Main dashboard page
- `GET /upload` - File upload interface
- `POST /upload` - Process uploaded files
- `GET /results/<session_id>` - View processing results
- `GET /download_zip/<session_id>` - Download project ZIP
- `GET /download_logs/<session_id>` - Download processing logs

## Configuration Reference

### JIRA Settings

```json
{
  "jira": {
    "url": "https://jira.example.com",
    "username": "api-user",
    "password": "api-password",
    "project_key": "PROJ",
    "epic_key": "PROJ-123",
    "structure_board_id": "5678"
  }
}
```

### Issue Constants

```json
{
  "constants": {
    "issue_type": "Bug",
    "assignee": "developer1",
    "reporter": "qa-lead",
    "priority": "Medium",
    "components": ["Frontend", "Backend"],
    "labels": ["QC", "CSV_IMPORT", "Automated"],
    "custom_fields": {
      "customfield_10001": "Custom Value",
      "customfield_10002": {"value": "Option1"}
    }
  }
}
```

### Processing Settings

```json
{
  "processing": {
    "batch_size": 10,
    "retry_attempts": 3,
    "retry_delay": 5,
    "timeout": 30
  }
}
```

## Testing

### Connection Test

Run the built-in connection test:

```bash
python test_jira_connection.py
```

This will validate:
- JIRA connectivity and authentication
- Project access permissions
- Issue type availability
- Search functionality

### Sample Data

Use the included `sample_defects.csv` for testing:

```bash
# The sample file contains 3 test defects with realistic data
# covering different defect types and priorities
```

## Logging

The application provides comprehensive logging at multiple levels:

- **INFO**: General operation status and results
- **DEBUG**: Detailed request/response data and processing steps
- **ERROR**: Error conditions and exceptions
- **WARNING**: Non-fatal issues and validation problems

Logs are written to:
- Console output (real-time)
- `logs/app.log` (persistent file)

## Error Handling

### Common Issues

1. **JIRA Connection Failed**
   - Check URL, username, password in configuration
   - Verify network connectivity
   - Confirm user has project permissions

2. **CSV Processing Errors**
   - Ensure file encoding is UTF-8 or system detectable
   - Verify required columns are present
   - Check for empty or malformed data

3. **Issue Creation Failed**
   - Verify project key exists and is accessible
   - Check epic key is valid if specified
   - Ensure user has issue creation permissions

### Troubleshooting

Enable debug logging by setting log level in `app.py`:

```python
logging.basicConfig(level=logging.DEBUG)
```

Check the processing logs for detailed error information and API responses.

## File Structure

```
jira_integration_api/
├── app.py                 # Main Flask application
├── main.py               # Application entry point
├── jira_service.py       # JIRA API integration
├── csv_processor.py      # CSV/Excel file processing
├── config_manager.py     # Configuration management
├── zip_generator.py      # Project packaging
├── test_jira_connection.py # Connection testing utility
├── sample_defects.csv    # Sample data for testing
├── config/
│   └── jira_config.json  # JIRA configuration
├── templates/            # HTML templates
│   ├── index.html
│   ├── upload.html
│   └── results.html
├── static/              # CSS and JavaScript
│   ├── css/custom.css
│   └── js/main.js
├── uploads/             # Uploaded files directory
├── output/              # Generated files directory
├── logs/                # Application logs
└── README.md            # This file
```

## Development

### Adding Custom Fields

To add custom JIRA fields to issue creation:

1. Update the configuration JSON:
```json
{
  "constants": {
    "custom_fields": {
      "customfield_10001": "Value",
      "customfield_10002": {"value": "DropdownOption"}
    }
  }
}
```

2. Custom fields are automatically applied during issue creation

### Extending CSV Mappings

To add new CSV column mappings, update `csv_processor.py`:

```python
mappings = {
    'new_field': ['new_column', 'alternative_name'],
    # ... existing mappings
}
```

## Security Considerations

- Store JIRA credentials securely
- Use environment variables for sensitive configuration
- Validate all user input
- Implement proper session management
- Consider HTTPS for production deployment

## Support

For issues and questions:

1. Check the application logs for detailed error information
2. Run the connection test script to validate JIRA setup
3. Verify CSV file format matches expected structure
4. Ensure all required permissions are granted in JIRA

## Version History

- **v1.0.0** (2025-07-07): Initial release
  - Base64 JIRA authentication
  - CSV/Excel file processing
  - Duplicate detection
  - Web interface
  - Comprehensive logging
  - Project ZIP generation

## License

This project is developed for internal use with JIRA integration capabilities.