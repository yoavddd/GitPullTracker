# JIRA Integration API - Installation Guide

## Version: v1.0.0

This guide will help you set up and deploy the JIRA Integration API from the provided ZIP file.

## Prerequisites

- Python 3.11 or higher
- Access to a JIRA instance with API permissions
- Network connectivity to your JIRA server

## Installation Steps

### 1. Extract the Project

```bash
# Extract the ZIP file
unzip jira_integration_api_v1.0.0_*.zip
cd jira_integration_api_v1.0.0/

# Verify extraction
ls -la
```

### 2. Install Dependencies

```bash
# Install Python dependencies
pip install -r requirements.txt

# Or if using the lockfile
pip install -r uv.lock
```

Required packages:
- Flask==2.3.3
- requests==2.31.0
- pandas==2.1.1
- openpyxl==3.1.2
- xlrd==2.0.1
- chardet==5.2.0
- jsonschema==4.17.3
- gunicorn==21.2.0

### 3. Configure JIRA Settings

Edit `config/jira_config.json` with your actual JIRA credentials:

```json
{
  "jira": {
    "url": "https://jira.esl.corp.elbit.co.il",
    "username": "your-actual-username",
    "password": "your-actual-password",
    "project_key": "YOUR_PROJECT_KEY",
    "epic_key": "YOUR_EPIC_KEY",
    "structure_board_id": "YOUR_BOARD_ID"
  },
  "constants": {
    "issue_type": "Bug",
    "assignee": "developer-username",
    "reporter": "qa-username",
    "priority": "Medium",
    "components": ["YourComponent"],
    "labels": ["QC", "CSV_IMPORT"]
  }
}
```

### 4. Set Environment Variables

```bash
# Set session secret for Flask
export SESSION_SECRET="your-secure-random-secret-key"

# Optional: Set other environment variables
export FLASK_ENV=production
export FLASK_DEBUG=false
```

### 5. Test the Installation

Run the connection test to verify JIRA connectivity:

```bash
python test_jira_connection.py
```

This will test:
- JIRA authentication
- Project access
- Issue creation permissions
- CSV processing functionality

### 6. Start the Application

#### Development Mode
```bash
python main.py
```

#### Production Mode (using Gunicorn)
```bash
gunicorn --bind 0.0.0.0:5000 --reuse-port --reload main:app
```

### 7. Access the Application

Open your web browser and navigate to:
- Local: http://localhost:5000
- Network: http://your-server-ip:5000

## Usage Instructions

### 1. Prepare Your CSV File

Ensure your CSV file contains these columns:
- **Defect ID** (required)
- **Summary** (recommended)
- **Description** (recommended)
- Any additional columns will be mapped to the JIRA issue description

Example CSV format:
```csv
Defect ID,Summary,Description,Detected By,Assigned To,Priority
12345,Login issue,User cannot login,QA Tester,Developer1,High
12346,UI bug,Button not working,QA Tester,Developer2,Medium
```

### 2. Upload Files

1. Go to http://localhost:5000
2. Click "Start Upload"
3. Select your CSV file
4. Select your JSON configuration file
5. Click "Process Files"

### 3. Review Results

The system will:
- Process each defect from your CSV
- Search JIRA for existing issues with "QC ID# {defect_id}" pattern
- Create new issues only for defects that don't already exist
- Display detailed results with statistics

### 4. Download Results

- Download processing logs for detailed information
- Download complete project ZIP for backup

## Troubleshooting

### Common Issues

**JIRA Connection Failed**
```
Error: JIRA connection failed. Status: 401
```
Solution: Check username and password in config/jira_config.json

**Project Access Denied**
```
Error: Cannot access project PROJECT_KEY
```
Solution: Verify project key and user permissions in JIRA

**CSV Processing Error**
```
Error: CSV file is empty or malformed
```
Solution: Check CSV file format and encoding (should be UTF-8)

### Enable Debug Logging

Edit `app.py` and change logging level:
```python
logging.basicConfig(level=logging.DEBUG)
```

### Test Individual Components

Test JIRA connection:
```bash
python test_jira_connection.py
```

Test CSV processing:
```bash
python -c "
from csv_processor import CSVProcessor
processor = CSVProcessor('sample_defects.csv')
defects = processor.load_defects()
print(f'Loaded {len(defects)} defects')
"
```

## Security Considerations

1. **Credentials Protection**
   - Never commit config files with real credentials to version control
   - Use environment variables for sensitive data in production
   - Consider using JIRA API tokens instead of passwords

2. **Network Security**
   - Use HTTPS in production
   - Configure firewall rules appropriately
   - Consider VPN access for internal JIRA instances

3. **File Validation**
   - The system validates file types and sizes
   - CSV content is sanitized before processing
   - All user input is validated

## Production Deployment

### Using Docker (Optional)

Create a Dockerfile:
```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY . .
RUN pip install -r requirements.txt

EXPOSE 5000
CMD ["gunicorn", "--bind", "0.0.0.0:5000", "main:app"]
```

### Using Systemd Service

Create `/etc/systemd/system/jira-integration.service`:
```ini
[Unit]
Description=JIRA Integration API
After=network.target

[Service]
User=www-data
WorkingDirectory=/path/to/jira_integration_api
Environment=SESSION_SECRET=your-secret-key
ExecStart=/usr/bin/gunicorn --bind 0.0.0.0:5000 main:app
Restart=always

[Install]
WantedBy=multi-user.target
```

### Reverse Proxy with Nginx

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

## Support

For technical support:
1. Check application logs in `logs/app.log`
2. Run the test script to verify configuration
3. Review JIRA permissions and API access
4. Ensure network connectivity to JIRA instance

## File Structure

After extraction, you should see:
```
jira_integration_api_v1.0.0/
├── app.py                 # Main Flask application
├── main.py               # Application entry point
├── jira_service.py       # JIRA API integration
├── csv_processor.py      # CSV/Excel processing
├── config_manager.py     # Configuration management
├── zip_generator.py      # Project packaging
├── test_jira_connection.py # Testing utility
├── sample_defects.csv    # Sample data
├── README.md             # Project documentation
├── config/
│   └── jira_config.json  # JIRA configuration
├── templates/            # Web interface templates
├── static/              # CSS and JavaScript
├── uploads/             # File upload directory
├── output/              # Generated files
└── logs/                # Application logs
```

## Version Information

- **Version**: v1.0.0
- **Release Date**: July 7, 2025
- **Python Version**: 3.11+
- **Flask Version**: 2.3.3
- **JIRA API**: REST API v2 with base64 authentication