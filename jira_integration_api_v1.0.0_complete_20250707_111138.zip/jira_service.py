import logging
import requests
import base64
import json
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

class JiraService:
    """Service for interacting with JIRA API"""
    
    def __init__(self, url: str, username: str, password: str):
        """Initialize JIRA service with credentials"""
        self.url = url.rstrip('/')
        self.username = username
        self.password = password
        
        # Use base64 encoding for authentication as suggested
        user_pass = f"{username}:{password}"
        encoded = base64.b64encode(user_pass.encode()).decode()
        
        self.headers = {
            'Authorization': f'Basic {encoded}',
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        }
        
        logger.info(f"Initialized JIRA service for URL: {self.url}")
        logger.debug(f"Using base64 authentication for user: {username}")
    
    def test_connection(self) -> bool:
        """Test connection to JIRA"""
        try:
            logger.info("Testing JIRA connection...")
            response = requests.get(
                f"{self.url}/rest/api/2/myself",
                headers=self.headers,
                timeout=30
            )
            
            logger.debug(f"JIRA connection test - Status: {response.status_code}")
            
            if response.status_code == 200:
                user_info = response.json()
                logger.info(f"JIRA connection successful. User: {user_info.get('displayName', 'Unknown')}")
                return True
            else:
                logger.error(f"JIRA connection failed. Status: {response.status_code}, Response: {response.text}")
                return False
                
        except Exception as e:
            logger.error(f"Error testing JIRA connection: {str(e)}")
            return False
    
    def search_issue_by_summary(self, search_pattern: str, project_key: str) -> Optional[str]:
        """Search for existing issue by summary pattern"""
        try:
            # JQL query to search for issues with the pattern in summary
            jql = f'project = "{project_key}" AND summary ~ "{search_pattern}"'
            
            params = {
                'jql': jql,
                'maxResults': 1,
                'fields': 'key,summary'
            }
            
            logger.debug(f"Searching JIRA with JQL: {jql}")
            
            response = requests.get(
                f"{self.url}/rest/api/2/search",
                headers=self.headers,
                params=params,
                timeout=30
            )
            
            logger.debug(f"Search response status: {response.status_code}")
            
            if response.status_code == 200:
                result = response.json()
                issues = result.get('issues', [])
                
                if issues:
                    issue_key = issues[0]['key']
                    issue_summary = issues[0]['fields']['summary']
                    logger.info(f"Found existing issue with pattern '{search_pattern}': {issue_key} - {issue_summary}")
                    return issue_key
                else:
                    logger.info(f"No existing issue found with pattern '{search_pattern}'")
                    return None
            else:
                logger.error(f"Error searching JIRA issues. Status: {response.status_code}, Response: {response.text}")
                return None
                
        except Exception as e:
            logger.error(f"Error searching JIRA issue: {str(e)}")
            return None
    
    def create_issue(self, defect: Dict, config: Dict) -> str:
        """Create a new JIRA issue"""
        try:
            defect_id = defect.get('defect_id', '')
            logger.info(f"Creating JIRA issue for defect ID: {defect_id}")
            
            # Build issue description from CSV columns
            description_parts = []
            description_parts.append(f"*Defect ID:* {defect_id}")
            description_parts.append("")
            description_parts.append("*Details from CSV:*")
            description_parts.append("")
            
            # Add all CSV data to description
            for key, value in defect.items():
                if key != 'defect_id' and value:
                    clean_key = key.replace('_', ' ').title()
                    description_parts.append(f"*{clean_key}:* {value}")
            
            description = "\n".join(description_parts)
            
            # Get constant values from config
            constants = config.get('constants', {})
            jira_config = config.get('jira', {})
            
            # Build issue payload
            issue_data = {
                "fields": {
                    "project": {
                        "key": jira_config.get('project_key', '123')
                    },
                    "summary": f"QC ID# {defect_id} - {defect.get('summary', defect.get('title', 'Defect from CSV'))}",
                    "description": description,
                    "issuetype": {
                        "name": constants.get('issue_type', 'Bug')
                    }
                }
            }
            
            # Add optional fields if they exist in config
            if constants.get('assignee'):
                issue_data['fields']['assignee'] = {"name": constants['assignee']}
            
            if constants.get('reporter'):
                issue_data['fields']['reporter'] = {"name": constants['reporter']}
            
            if constants.get('priority'):
                issue_data['fields']['priority'] = {"name": constants['priority']}
            
            if constants.get('components'):
                issue_data['fields']['components'] = [{"name": comp} for comp in constants['components']]
            
            if constants.get('labels'):
                issue_data['fields']['labels'] = constants['labels']
            
            # Add custom fields if specified
            if constants.get('custom_fields'):
                for field_id, field_value in constants['custom_fields'].items():
                    if not field_id.startswith('_'):  # Skip comment fields
                        issue_data['fields'][field_id] = field_value
            
            # Set parent epic if specified
            if jira_config.get('epic_key'):
                issue_data['fields']['parent'] = {"key": jira_config['epic_key']}
            
            logger.debug(f"Creating JIRA issue with data: {json.dumps(issue_data, indent=2)}")
            
            response = requests.post(
                f"{self.url}/rest/api/2/issue",
                headers=self.headers,
                json=issue_data,
                timeout=30
            )
            
            logger.debug(f"Create issue response status: {response.status_code}")
            
            if response.status_code == 201:
                result = response.json()
                issue_key = result['key']
                logger.info(f"Successfully created JIRA issue: {issue_key} for defect {defect_id}")
                return issue_key
            else:
                error_msg = f"Failed to create JIRA issue for defect {defect_id}. Status: {response.status_code}, Response: {response.text}"
                logger.error(error_msg)
                raise Exception(error_msg)
                
        except Exception as e:
            logger.error(f"Error creating JIRA issue for defect {defect_id}: {str(e)}")
            raise
    
    def get_project_info(self, project_key: str) -> Dict:
        """Get project information"""
        try:
            logger.debug(f"Getting project info for: {project_key}")
            response = requests.get(
                f"{self.url}/rest/api/2/project/{project_key}",
                headers=self.headers,
                timeout=30
            )
            
            if response.status_code == 200:
                project_info = response.json()
                logger.info(f"Retrieved project info for {project_key}: {project_info.get('name', 'Unknown')}")
                return project_info
            else:
                logger.error(f"Failed to get project info for {project_key}. Status: {response.status_code}")
                return {}
                
        except Exception as e:
            logger.error(f"Error getting project info: {str(e)}")
            return {}
    
    def get_issue_types(self, project_key: str) -> List[Dict]:
        """Get available issue types for project"""
        try:
            logger.debug(f"Getting issue types for project: {project_key}")
            response = requests.get(
                f"{self.url}/rest/api/2/project/{project_key}",
                headers=self.headers,
                timeout=30
            )
            
            if response.status_code == 200:
                project_info = response.json()
                issue_types = project_info.get('issueTypes', [])
                logger.info(f"Retrieved {len(issue_types)} issue types for project {project_key}")
                return issue_types
            else:
                logger.error(f"Failed to get issue types for {project_key}. Status: {response.status_code}")
                return []
                
        except Exception as e:
            logger.error(f"Error getting issue types: {str(e)}")
            return []
    
    def search_issues_in_structure(self, structure_board_id: str, project_key: str) -> List[Dict]:
        """Search issues in JIRA Structure board"""
        try:
            logger.info(f"Searching issues in structure board {structure_board_id} for project {project_key}")
            
            # Enhanced JQL search for structure board
            jql = f'project = "{project_key}" ORDER BY created DESC'
            
            params = {
                'jql': jql,
                'maxResults': 1000,
                'fields': 'key,summary,status,assignee,created,updated'
            }
            
            response = requests.get(
                f"{self.url}/rest/api/2/search",
                headers=self.headers,
                params=params,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                issues = result.get('issues', [])
                logger.info(f"Found {len(issues)} issues in project {project_key}")
                return issues
            else:
                logger.error(f"Failed to search structure issues. Status: {response.status_code}, Response: {response.text}")
                return []
                
        except Exception as e:
            logger.error(f"Error searching structure issues: {str(e)}")
            return []
    
    def validate_credentials(self) -> bool:
        """Validate JIRA credentials and permissions"""
        try:
            logger.info("Validating JIRA credentials and permissions...")
            
            # Test basic authentication
            if not self.test_connection():
                return False
            
            # Test project access
            project_key = "123"  # Default project key from config
            project_info = self.get_project_info(project_key)
            
            if not project_info:
                logger.warning(f"Cannot access project {project_key} - checking permissions")
                return False
            
            logger.info("JIRA credentials and permissions validated successfully")
            return True
            
        except Exception as e:
            logger.error(f"Error validating JIRA credentials: {str(e)}")
            return False