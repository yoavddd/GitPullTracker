import logging
import zipfile
import os
from datetime import datetime
from typing import List

logger = logging.getLogger(__name__)

class ZipGenerator:
    """Generator for creating ZIP files with project files"""
    
    def __init__(self):
        """Initialize ZIP generator"""
        self.output_dir = 'output'
        os.makedirs(self.output_dir, exist_ok=True)
        
        logger.info("Initialized ZIP generator")
    
    def create_project_zip(self) -> str:
        """Create ZIP file containing all project files"""
        try:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            zip_filename = f"jira_integration_project_{timestamp}.zip"
            zip_path = os.path.join(self.output_dir, zip_filename)
            
            # Files to include in ZIP
            files_to_include = [
                'app.py',
                'main.py',
                'jira_service.py',
                'csv_processor.py',
                'config_manager.py',
                'zip_generator.py',
                'templates/index.html',
                'templates/upload.html',
                'templates/results.html',
                'static/css/custom.css',
                'static/js/main.js',
                'config/jira_config.json',
                'README.md'
            ]
            
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for file_path in files_to_include:
                    if os.path.exists(file_path):
                        zipf.write(file_path, file_path)
                        logger.debug(f"Added file to ZIP: {file_path}")
                    else:
                        logger.warning(f"File not found, skipping: {file_path}")
                
                # Add README
                self._add_readme_to_zip(zipf)
                
                # Add requirements.txt
                self._add_requirements_to_zip(zipf)
                
                # Add sample config
                self._add_sample_config_to_zip(zipf)
            
            logger.info(f"Created project ZIP file: {zip_path}")
            return zip_path
            
        except Exception as e:
            logger.error(f"Error creating project ZIP: {str(e)}")
            raise
    
    def _add_readme_to_zip(self, zipf: zipfile.ZipFile) -> None:
        """Add README.md to ZIP file"""
        readme_content = """# JIRA Integration API

A Flask-based API for processing CSV defect files and automatically creating JIRA issues while preventing duplicates.

## Features

- CSV file processing to extract defect information
- JIRA API integration for searching and creating issues
- Duplicate detection using QC ID pattern matching
- JSON configuration for constant bug details
- Comprehensive logging
- Web interface for file uploads
- Batch processing capabilities

## Setup

1. Install Python dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Set environment variables:
   ```bash
   export SESSION_SECRET="your-secret-key"
   ```

3. Configure JIRA settings in config/jira_config.json

4. Run the application:
   ```bash
   python main.py
   ```

## Usage

1. Access the web interface at http://localhost:5000
2. Upload your CSV file containing defect data
3. Upload your JSON configuration file
4. Review the processing results
5. Download logs and project files as needed

## Configuration

Create a JSON configuration file with the following structure:

```json
{
  "jira": {
    "url": "https://your-jira-instance.com",
    "username": "your-username",
    "password": "your-password",
    "project_key": "PROJECT",
    "epic_key": "EPIC-123",
    "structure_board_id": "1234"
  },
  "constants": {
    "issue_type": "Bug",
    "assignee": "username",
    "reporter": "username",
    "priority": "Medium",
    "components": ["Component1"],
    "labels": ["QC", "CSV_IMPORT"]
  }
}
```

## CSV File Format

Your CSV file should contain these columns:
- **defect_id** - Unique identifier (required)
- **summary** - Brief description
- **description** - Detailed description
- **detected_by** - Reporter name
- **assigned_to** - Assignee name
- **priority** - Priority level
- **status** - Current status
- **component** - Component/module

## How It Works

1. System scans all defect IDs from the CSV file
2. For each defect ID, searches JIRA for existing issues with "QC ID# {defect_id}" pattern
3. If no existing issue is found, creates a new JIRA issue in the specified epic
4. Uses constant values from JSON configuration for assignee, reporter, etc.
5. Maps all CSV columns to the JIRA issue description
6. Provides comprehensive logging of all operations

## Technical Details

- Built with Flask web framework
- Uses JIRA REST API v2
- Supports both CSV and Excel file formats
- Automatic encoding detection for CSV files
- JSON schema validation for configuration
- Bootstrap-based responsive UI
- Comprehensive error handling and logging
"""
        
        zipf.writestr('README.md', readme_content)
        logger.debug("Added README.md to ZIP")
    
    def _add_requirements_to_zip(self, zipf: zipfile.ZipFile) -> None:
        """Add requirements.txt to ZIP file"""
        requirements_content = """Flask==2.3.3
requests==2.31.0
pandas==2.1.1
openpyxl==3.1.2
xlrd==2.0.1
chardet==5.2.0
jsonschema==4.17.3
gunicorn==21.2.0
Werkzeug==2.3.7
email-validator==2.0.0
psycopg2-binary==2.9.7
"""
        
        zipf.writestr('requirements.txt', requirements_content)
        logger.debug("Added requirements.txt to ZIP")
    
    def _add_sample_config_to_zip(self, zipf: zipfile.ZipFile) -> None:
        """Add sample configuration to ZIP file"""
        sample_config = """{
  "_comment": "JIRA Integration Configuration File",
  "_instructions": {
    "jira": "JIRA connection settings - Update with your actual credentials",
    "constants": "Default values for created issues - Customize as needed",
    "processing": "Processing behavior settings - Adjust for your environment"
  },
  "jira": {
    "url": "https://your-jira-instance.com",
    "username": "your-username",
    "password": "your-password",
    "project_key": "YOUR_PROJECT",
    "epic_key": "EPIC-123",
    "structure_board_id": "1234"
  },
  "constants": {
    "issue_type": "Bug",
    "assignee": "username",
    "reporter": "username",
    "priority": "Medium",
    "components": ["Component1"],
    "labels": ["QC", "CSV_IMPORT"],
    "custom_fields": {
      "_comment": "Add custom field mappings here",
      "_example": "customfield_10001: 'Custom Value'"
    }
  },
  "processing": {
    "batch_size": 10,
    "retry_attempts": 3,
    "retry_delay": 5,
    "timeout": 30
  }
}"""
        
        zipf.writestr('config/sample_jira_config.json', sample_config)
        logger.debug("Added sample config to ZIP")