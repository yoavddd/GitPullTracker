import logging
import os
from datetime import datetime
from logging.handlers import RotatingFileHandler
import colorlog

def setup_logging(log_level="DEBUG", output_dir="./output"):
    """
    Set up comprehensive logging system with multiple handlers
    """
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    # Create logs directory
    log_dir = os.path.join(output_dir, "logs")
    os.makedirs(log_dir, exist_ok=True)
    
    # Set up main logger
    logger = logging.getLogger()
    logger.setLevel(getattr(logging, log_level.upper()))
    
    # Clear existing handlers
    logger.handlers.clear()
    
    # Create formatters
    detailed_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s'
    )
    
    simple_formatter = logging.Formatter(
        '%(asctime)s - %(levelname)s - %(message)s'
    )
    
    # Console handler with colors
    console_handler = colorlog.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_formatter = colorlog.ColoredFormatter(
        '%(log_color)s%(asctime)s - %(levelname)s - %(message)s',
        datefmt='%H:%M:%S',
        log_colors={
            'DEBUG': 'cyan',
            'INFO': 'green',
            'WARNING': 'yellow',
            'ERROR': 'red',
            'CRITICAL': 'red,bg_white',
        }
    )
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)
    
    # Main application log file
    main_log_file = os.path.join(log_dir, f"git_analyzer_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    main_file_handler = RotatingFileHandler(
        main_log_file, maxBytes=10*1024*1024, backupCount=5
    )
    main_file_handler.setLevel(logging.DEBUG)
    main_file_handler.setFormatter(detailed_formatter)
    logger.addHandler(main_file_handler)
    
    # Git diff analysis log
    diff_log_file = os.path.join(log_dir, f"git_diff_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    diff_logger = logging.getLogger('git_diff')
    diff_handler = RotatingFileHandler(
        diff_log_file, maxBytes=5*1024*1024, backupCount=3
    )
    diff_handler.setLevel(logging.DEBUG)
    diff_handler.setFormatter(detailed_formatter)
    diff_logger.addHandler(diff_handler)
    
    # Submodule processing log
    submodule_log_file = os.path.join(log_dir, f"submodule_processing_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    submodule_logger = logging.getLogger('submodule')
    submodule_handler = RotatingFileHandler(
        submodule_log_file, maxBytes=5*1024*1024, backupCount=3
    )
    submodule_handler.setLevel(logging.DEBUG)
    submodule_handler.setFormatter(detailed_formatter)
    submodule_logger.addHandler(submodule_handler)
    
    # TFS API log
    tfs_log_file = os.path.join(log_dir, f"tfs_api_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    tfs_logger = logging.getLogger('tfs_api')
    tfs_handler = RotatingFileHandler(
        tfs_log_file, maxBytes=5*1024*1024, backupCount=3
    )
    tfs_handler.setLevel(logging.DEBUG)
    tfs_handler.setFormatter(detailed_formatter)
    tfs_logger.addHandler(tfs_handler)
    
    # PR extraction log
    pr_log_file = os.path.join(log_dir, f"pr_extraction_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    pr_logger = logging.getLogger('pr_extraction')
    pr_handler = RotatingFileHandler(
        pr_log_file, maxBytes=5*1024*1024, backupCount=3
    )
    pr_handler.setLevel(logging.DEBUG)
    pr_handler.setFormatter(detailed_formatter)
    pr_logger.addHandler(pr_handler)
    
    logging.info(f"Logging initialized. Main log: {main_log_file}")
    logging.info(f"Git diff log: {diff_log_file}")
    logging.info(f"Submodule log: {submodule_log_file}")
    logging.info(f"TFS API log: {tfs_log_file}")
    logging.info(f"PR extraction log: {pr_log_file}")
    
    return logger
