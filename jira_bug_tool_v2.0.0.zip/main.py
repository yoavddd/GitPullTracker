#!/usr/bin/env python3
"""
JIRA Bug Creation Tool
A command-line tool to process CSV bug data and create JIRA issues with duplicate checking.
"""

import argparse
import sys
import os
import logging
import json
from typing import List, Dict, Any

from jira_client import JiraClient
from csv_processor import CSVProcessor
from config_manager import ConfigManager
from logger_config import setup_logging


def transform_assignee(csv_name: str) -> str:
    """Transform CSV name to JIRA assignee format.
    
    Example: "dolis yoav" -> "yoav.dolis@elbs.com"
    """
    if not csv_name or csv_name.strip() == "":
        return ""
    
    # Split name and reverse order
    name_parts = csv_name.strip().lower().split()
    if len(name_parts) >= 2:
        last_name = name_parts[0]
        first_name = name_parts[1]
        return f"{first_name}.{last_name}@elbs.com"
    elif len(name_parts) == 1:
        return f"{name_parts[0]}@elbs.com"
    else:
        return ""


def map_status_to_jira(csv_status: str) -> str:
    """Map CSV status to JIRA status.
    
    CSV -> JIRA mapping:
    - New/Open -> TO DO
    - Cancelled -> CANCELLED
    - Fixed -> READY FOR TESTING
    - Closed -> DONE
    """
    if not csv_status:
        return "TO DO"  # Default status
    
    status_mapping = {
        "new": "TO DO",
        "open": "TO DO",
        "cancelled": "CANCELLED",
        "fixed": "READY FOR TESTING",
        "closed": "DONE"
    }
    
    return status_mapping.get(csv_status.lower(), "TO DO")


def process_add_mode(bugs: List[Dict[str, Any]], jira_client: JiraClient, dry_run: bool, skip_connection_test: bool, logger: logging.Logger) -> tuple:
    """Process bugs in add mode - create new bugs with status and assignee logic."""
    created_count = 0
    skipped_count = 0
    error_count = 0
    dry_run_output = []
    
    for i, bug in enumerate(bugs, 1):
        logger.info(f"Processing bug {i}/{len(bugs)}: {bug.get('defect_id', 'Unknown ID')}")
        
        try:
            # Check if bug already exists (only if not skipping connection test)
            defect_id = bug.get('defect_id', '')
            if not defect_id:
                logger.warning(f"Bug {i} has no defect_id, skipping")
                skipped_count += 1
                continue
            
            if not skip_connection_test:
                search_pattern = f"QC ID {defect_id}"
                logger.debug(f"Searching for existing bug with pattern: {search_pattern}")
                
                existing_issue = jira_client.search_existing_issue(search_pattern)
                
                if existing_issue:
                    logger.info(f"Bug {defect_id} already exists in JIRA: {existing_issue['key']}")
                    skipped_count += 1
                    continue
            else:
                logger.debug(f"Skipping duplicate check for bug {defect_id} (connection test disabled)")
            
            # Apply status and assignee transformation
            original_status = bug.get('status', '')
            original_assignee = bug.get('detected_by', '')
            
            bug['jira_status'] = map_status_to_jira(original_status)
            bug['jira_assignee'] = transform_assignee(original_assignee)
            
            logger.debug(f"Transformed status: {original_status} -> {bug['jira_status']}")
            logger.debug(f"Transformed assignee: {original_assignee} -> {bug['jira_assignee']}")
            
            # Create new bug
            if dry_run:
                logger.info(f"[DRY RUN] Would create bug for defect_id: {defect_id}")
                # Generate the JSON that would be created
                issue_json = jira_client.get_issue_json_for_dry_run(bug)
                dry_run_output.append({
                    "defect_id": defect_id,
                    "jira_issue_json": issue_json,
                    "csv_data": bug
                })
                created_count += 1
            else:
                logger.info(f"Creating new bug for defect_id: {defect_id}")
                issue_key = jira_client.create_issue(bug)
                
                if issue_key:
                    logger.info(f"Successfully created bug: {issue_key}")
                    created_count += 1
                else:
                    logger.error(f"Failed to create bug for defect_id: {defect_id}")
                    error_count += 1
                    
        except Exception as e:
            logger.error(f"Error processing bug {defect_id}: {str(e)}")
            error_count += 1
            continue
    
    return created_count, skipped_count, error_count, dry_run_output


def process_update_mode(bugs: List[Dict[str, Any]], jira_client: JiraClient, dry_run: bool, logger: logging.Logger) -> tuple:
    """Process bugs in update mode - update existing bugs with new data."""
    updated_count = 0
    skipped_count = 0
    error_count = 0
    dry_run_output = []
    
    for i, bug in enumerate(bugs, 1):
        logger.info(f"Processing bug {i}/{len(bugs)}: {bug.get('defect_id', 'Unknown ID')}")
        
        try:
            # Get defect ID
            defect_id = bug.get('defect_id', '')
            if not defect_id:
                logger.warning(f"Bug {i} has no defect_id, skipping")
                skipped_count += 1
                continue
            
            # Find existing bug in JIRA
            search_pattern = f"QC ID# {defect_id}"
            logger.debug(f"Searching for existing bug with pattern: {search_pattern}")
            
            existing_issue = jira_client.search_existing_issue(search_pattern)
            
            if not existing_issue:
                logger.warning(f"Bug {defect_id} not found in JIRA, skipping update")
                skipped_count += 1
                continue
            
            # Apply status and assignee transformation
            original_status = bug.get('status', '')
            original_assignee = bug.get('detected_by', '')
            
            bug['jira_status'] = map_status_to_jira(original_status)
            bug['jira_assignee'] = transform_assignee(original_assignee)
            
            logger.debug(f"Transformed status: {original_status} -> {bug['jira_status']}")
            logger.debug(f"Transformed assignee: {original_assignee} -> {bug['jira_assignee']}")
            
            # Update existing bug
            if dry_run:
                logger.info(f"[DRY RUN] Would update bug {existing_issue['key']} for defect_id: {defect_id}")
                # Generate the JSON that would be sent for update
                update_json = jira_client.get_update_json_for_dry_run(bug, existing_issue)
                dry_run_output.append({
                    "defect_id": defect_id,
                    "existing_issue_key": existing_issue['key'],
                    "jira_update_json": update_json,
                    "csv_data": bug
                })
                updated_count += 1
            else:
                logger.info(f"Updating bug {existing_issue['key']} for defect_id: {defect_id}")
                success = jira_client.update_issue(existing_issue['key'], bug)
                
                if success:
                    logger.info(f"Successfully updated bug: {existing_issue['key']}")
                    updated_count += 1
                else:
                    logger.error(f"Failed to update bug for defect_id: {defect_id}")
                    error_count += 1
                    
        except Exception as e:
            logger.error(f"Error processing bug {defect_id}: {str(e)}")
            error_count += 1
            continue
    
    return updated_count, skipped_count, error_count, dry_run_output


def main():
    """Main entry point for the JIRA bug creation tool."""
    parser = argparse.ArgumentParser(
        description='Process CSV bug data and create JIRA issues with duplicate checking'
    )
    parser.add_argument(
        '--csv-file',
        required=True,
        help='Path to the CSV file containing bug data'
    )
    parser.add_argument(
        '--config-file',
        default='config.json',
        help='Path to the JSON configuration file (default: config.json)'
    )
    parser.add_argument(
        '--mode',
        choices=['add', 'update'],
        default='add',
        help='Operation mode: add (create new bugs) or update (update existing bugs)'
    )
    parser.add_argument(
        '--log-level',
        default='INFO',
        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
        help='Set the logging level (default: INFO)'
    )
    parser.add_argument(
        '--dry-run',
        action='store_true',
        help='Perform a dry run without creating actual JIRA issues'
    )
    parser.add_argument(
        '--skip-connection-test',
        action='store_true',
        help='Skip JIRA connection test (useful for offline CSV validation)'
    )
    
    args = parser.parse_args()
    
    # Setup logging
    setup_logging(args.log_level)
    logger = logging.getLogger(__name__)
    
    logger.info("Starting JIRA Bug Creation Tool")
    logger.info(f"CSV file: {args.csv_file}")
    logger.info(f"Config file: {args.config_file}")
    logger.info(f"Mode: {args.mode}")
    logger.info(f"Dry run: {args.dry_run}")
    logger.info(f"Skip connection test: {args.skip_connection_test}")
    
    try:
        # Validate input files
        if not os.path.exists(args.csv_file):
            logger.error(f"CSV file not found: {args.csv_file}")
            sys.exit(1)
            
        if not os.path.exists(args.config_file):
            logger.error(f"Config file not found: {args.config_file}")
            sys.exit(1)
        
        # Load configuration
        logger.info("Loading configuration...")
        config_manager = ConfigManager(args.config_file)
        config = config_manager.load_config()
        
        # Initialize JIRA client
        logger.info("Initializing JIRA client...")
        jira_client = JiraClient(config)
        
        # Test JIRA connection (unless skipped)
        if not args.skip_connection_test:
            logger.info("Testing JIRA connection...")
            if not jira_client.test_connection():
                logger.error("Failed to connect to JIRA. Please check your credentials and URL.")
                if not args.dry_run:
                    sys.exit(1)
                else:
                    logger.warning("Connection failed, but continuing with dry run mode...")
        else:
            logger.info("Skipping JIRA connection test as requested")
        
        # Process CSV file
        logger.info("Processing CSV file...")
        csv_processor = CSVProcessor(args.csv_file)
        bugs = csv_processor.process_csv()
        
        if not bugs:
            logger.warning("No bugs found in CSV file.")
            sys.exit(0)
        
        logger.info(f"Found {len(bugs)} bugs in CSV file")
        
        # Process each bug based on mode
        if args.mode == 'add':
            created_count, skipped_count, error_count, dry_run_output = process_add_mode(
                bugs, jira_client, args.dry_run, args.skip_connection_test, logger
            )
        else:  # update mode
            updated_count, skipped_count, error_count, dry_run_output = process_update_mode(
                bugs, jira_client, args.dry_run, logger
            )
            created_count = updated_count  # For consistent reporting
        
        # Summary
        logger.info("=" * 50)
        logger.info("PROCESSING SUMMARY")
        logger.info("=" * 50)
        logger.info(f"Total bugs processed: {len(bugs)}")
        logger.info(f"Bugs created: {created_count}")
        logger.info(f"Bugs skipped (already exist): {skipped_count}")
        logger.info(f"Errors: {error_count}")
        
        # Save dry-run output to file if in dry-run mode
        if args.dry_run and dry_run_output:
            output_file = "dry_run_jira_issues.json"
            try:
                with open(output_file, 'w', encoding='utf-8') as f:
                    json.dump(dry_run_output, f, indent=2, ensure_ascii=False)
                logger.info(f"Dry-run output saved to: {output_file}")
                logger.info(f"Generated {len(dry_run_output)} JIRA issue JSON objects with complete CSV data")
            except Exception as e:
                logger.error(f"Failed to save dry-run output: {str(e)}")
        
        if error_count > 0:
            logger.warning(f"Completed with {error_count} errors. Check logs for details.")
            sys.exit(1)
        else:
            logger.info("All bugs processed successfully!")
            
    except KeyboardInterrupt:
        logger.info("Process interrupted by user")
        sys.exit(130)
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        logger.debug("Full error details:", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
