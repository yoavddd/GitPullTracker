import requests
import logging
import base64
from typing import List, Dict, Optional
from datetime import datetime
import json

class TFSClient:
    """
    Client for interacting with TFS Azure DevOps API to retrieve pull requests
    """
    
    def __init__(self, tfs_url: str, token: str, demo_mode: bool = False):
        self.tfs_url = tfs_url.rstrip('/')
        self.token = token
        self.demo_mode = demo_mode
        self.logger = logging.getLogger('tfs_api')
        self.pr_logger = logging.getLogger('pr_extraction')
        
        # Parse TFS URL to extract components
        self._parse_tfs_url()
        
        # Set up authentication headers
        self.headers = {
            'Authorization': f'Basic {base64.b64encode(f":{token}".encode()).decode()}',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        
        self.logger.info(f"Initialized TFS client for: {self.tfs_url}")
        self.logger.debug(f"Organization: {self.organization}, Project: {self.project}, Repository: {self.repository}")
        if demo_mode:
            self.logger.warning("TFS Client running in DEMO MODE - will return mock data")
    
    def _parse_tfs_url(self):
        """
        Parse TFS URL to extract organization, project, and repository information
        """
        try:
            # Example URL: http://tfs1:8080/tfs/SilverArrowCollection/VMSC_App/_git/IAFHalcon
            url_parts = self.tfs_url.split('/')
            
            # Find the TFS collection and project
            tfs_index = -1
            for i, part in enumerate(url_parts):
                if part.lower() == 'tfs':
                    tfs_index = i
                    break
            
            if tfs_index == -1:
                raise ValueError("Could not find 'tfs' in URL")
            
            self.organization = url_parts[tfs_index + 1]  # SilverArrowCollection
            self.project = url_parts[tfs_index + 2]       # VMSC_App
            
            # Extract repository name
            if '_git' in url_parts:
                git_index = url_parts.index('_git')
                self.repository = url_parts[git_index + 1]  # IAFHalcon
            else:
                self.repository = self.project
            
            # Build base API URL
            self.base_url = f"{'/'.join(url_parts[:tfs_index + 1])}/{self.organization}/{self.project}/_apis"
            
            self.logger.debug(f"Parsed TFS URL - Organization: {self.organization}, Project: {self.project}, Repository: {self.repository}")
            self.logger.debug(f"Base API URL: {self.base_url}")
            
        except Exception as e:
            self.logger.error(f"Error parsing TFS URL '{self.tfs_url}': {str(e)}")
            raise
    
    def test_connection(self) -> bool:
        """
        Test connection to TFS API
        """
        try:
            self.logger.info("Testing TFS API connection...")
            
            # Try to get repository information
            url = f"{self.base_url}/git/repositories/{self.repository}"
            self.logger.debug(f"Testing connection with URL: {url}")
            
            response = requests.get(url, headers=self.headers, timeout=30)
            
            if response.status_code == 200:
                repo_info = response.json()
                self.logger.info(f"Successfully connected to TFS. Repository: {repo_info.get('name', 'Unknown')}")
                return True
            else:
                self.logger.error(f"TFS connection test failed. Status: {response.status_code}, Response: {response.text}")
                return False
                
        except Exception as e:
            self.logger.error(f"Error testing TFS connection: {str(e)}")
            return False
    
    def get_pull_requests_in_commit_range(self, from_commit: str, to_commit: str, repository_name: Optional[str] = None) -> List[Dict]:
        """
        Get pull requests that were merged between two commits
        """
        repo_name = repository_name or self.repository
        self.pr_logger.info(f"Retrieving pull requests for repository '{repo_name}' between commits: {from_commit} -> {to_commit}")
        
        # Return mock data in demo mode
        if self.demo_mode:
            self.pr_logger.warning(f"DEMO MODE: Returning mock pull request data for repository '{repo_name}'")
            return self._get_mock_pull_requests(repo_name, from_commit, to_commit)
        
        try:
            # Get all pull requests for the repository
            all_prs = self._get_all_pull_requests(repo_name)
            self.pr_logger.debug(f"Found {len(all_prs)} total pull requests in repository '{repo_name}'")
            
            # Filter PRs that were merged in the commit range
            merged_prs = []
            
            for pr in all_prs:
                if pr.get('status') == 'completed' and pr.get('mergeStatus') == 'succeeded':
                    merge_commit = pr.get('lastMergeCommit', {}).get('commitId')
                    if merge_commit:
                        if self._is_commit_in_range(merge_commit, from_commit, to_commit, repo_name):
                            merged_prs.append(self._format_pull_request(pr))
                            self.pr_logger.debug(f"PR #{pr['pullRequestId']} merged in range: {pr['title']}")
            
            self.pr_logger.info(f"Found {len(merged_prs)} pull requests merged in commit range")
            return merged_prs
            
        except Exception as e:
            self.pr_logger.error(f"Error retrieving pull requests for repository '{repo_name}': {str(e)}")
            if self.demo_mode:
                self.pr_logger.warning("Falling back to mock data due to connection error")
                return self._get_mock_pull_requests(repo_name, from_commit, to_commit)
            return []
    
    def _get_all_pull_requests(self, repository_name: str) -> List[Dict]:
        """
        Get all pull requests for a repository
        """
        try:
            url = f"{self.base_url}/git/repositories/{repository_name}/pullrequests"
            params = {
                'api-version': '6.0',
                'searchCriteria.status': 'all',
                '$top': 1000  # Adjust as needed
            }
            
            self.logger.debug(f"Fetching pull requests from: {url}")
            
            response = requests.get(url, headers=self.headers, params=params, timeout=60)
            
            if response.status_code == 200:
                data = response.json()
                prs = data.get('value', [])
                self.logger.debug(f"Retrieved {len(prs)} pull requests from API")
                return prs
            else:
                self.logger.error(f"Failed to get pull requests. Status: {response.status_code}, Response: {response.text}")
                return []
                
        except Exception as e:
            self.logger.error(f"Error fetching pull requests: {str(e)}")
            return []
    
    def _is_commit_in_range(self, commit_hash: str, from_commit: str, to_commit: str, repository_name: str) -> bool:
        """
        Check if a commit is in the specified range
        """
        try:
            # Get commit details to check if it's in range
            url = f"{self.base_url}/git/repositories/{repository_name}/commits/{commit_hash}"
            params = {'api-version': '6.0'}
            
            response = requests.get(url, headers=self.headers, params=params, timeout=30)
            
            if response.status_code == 200:
                commit_data = response.json()
                commit_date = datetime.fromisoformat(commit_data['committer']['date'].replace('Z', '+00:00'))
                
                # Get from and to commit dates
                from_date = self._get_commit_date(from_commit, repository_name)
                to_date = self._get_commit_date(to_commit, repository_name)
                
                if from_date and to_date:
                    return from_date <= commit_date <= to_date
                else:
                    # Fallback: check if commit hash is literally in the range
                    return self._check_commit_ancestry(commit_hash, from_commit, to_commit, repository_name)
            
            return False
            
        except Exception as e:
            self.logger.debug(f"Error checking if commit {commit_hash} is in range: {str(e)}")
            return False
    
    def _get_commit_date(self, commit_hash: str, repository_name: str) -> Optional[datetime]:
        """
        Get the date of a specific commit
        """
        try:
            url = f"{self.base_url}/git/repositories/{repository_name}/commits/{commit_hash}"
            params = {'api-version': '6.0'}
            
            response = requests.get(url, headers=self.headers, params=params, timeout=30)
            
            if response.status_code == 200:
                commit_data = response.json()
                return datetime.fromisoformat(commit_data['committer']['date'].replace('Z', '+00:00'))
            
            return None
            
        except Exception as e:
            self.logger.debug(f"Error getting commit date for {commit_hash}: {str(e)}")
            return None
    
    def _check_commit_ancestry(self, commit_hash: str, from_commit: str, to_commit: str, repository_name: str) -> bool:
        """
        Check commit ancestry using TFS API (simplified approach)
        """
        try:
            # Get commits between from_commit and to_commit
            url = f"{self.base_url}/git/repositories/{repository_name}/commits"
            params = {
                'api-version': '6.0',
                'searchCriteria.fromCommitId': from_commit,
                'searchCriteria.toCommitId': to_commit,
                '$top': 1000
            }
            
            response = requests.get(url, headers=self.headers, params=params, timeout=60)
            
            if response.status_code == 200:
                data = response.json()
                commits = data.get('value', [])
                
                # Check if our commit is in the list
                for commit in commits:
                    if commit.get('commitId') == commit_hash:
                        return True
            
            return False
            
        except Exception as e:
            self.logger.debug(f"Error checking commit ancestry: {str(e)}")
            return False
    
    def _format_pull_request(self, pr_data: Dict) -> Dict:
        """
        Format pull request data for output
        """
        return {
            'id': pr_data.get('pullRequestId'),
            'title': pr_data.get('title', ''),
            'description': pr_data.get('description', ''),
            'created_by': pr_data.get('createdBy', {}).get('displayName', ''),
            'created_date': pr_data.get('creationDate', ''),
            'completed_date': pr_data.get('closedDate', ''),
            'source_branch': pr_data.get('sourceRefName', '').replace('refs/heads/', ''),
            'target_branch': pr_data.get('targetRefName', '').replace('refs/heads/', ''),
            'merge_commit': pr_data.get('lastMergeCommit', {}).get('commitId', ''),
            'status': pr_data.get('status', ''),
            'url': pr_data.get('webUrl', ''),
            'repository': pr_data.get('repository', {}).get('name', self.repository)
        }
    
    def _get_mock_pull_requests(self, repository_name: str, from_commit: str, to_commit: str) -> List[Dict]:
        """
        Generate mock pull request data for demo purposes
        """
        self.pr_logger.debug(f"Generating mock pull request data for repository '{repository_name}'")
        
        import random
        from datetime import datetime, timedelta
        
        # Generate 1-3 mock PRs per repository
        num_prs = random.randint(1, 3)
        mock_prs = []
        
        base_date = datetime.now() - timedelta(days=30)
        
        for i in range(num_prs):
            pr_id = 1000 + i + hash(repository_name) % 1000
            mock_pr = {
                'id': pr_id,
                'title': f'Feature implementation for {repository_name} #{i+1}',
                'description': f'This is a mock pull request for demonstration purposes in repository {repository_name}',
                'created_by': f'Developer{i+1}',
                'created_date': (base_date + timedelta(days=i*5)).isoformat(),
                'completed_date': (base_date + timedelta(days=i*5+2)).isoformat(),
                'source_branch': f'feature/mock-feature-{i+1}',
                'target_branch': 'main',
                'merge_commit': f'abc{i}def{random.randint(100,999)}',
                'status': 'completed',
                'url': f'{self.tfs_url}/pullrequest/{pr_id}',
                'repository': repository_name
            }
            mock_prs.append(mock_pr)
            self.pr_logger.debug(f"Generated mock PR #{pr_id}: {mock_pr['title']}")
        
        return mock_prs

    def get_submodule_repository_name(self, submodule_url: str) -> Optional[str]:
        """
        Extract repository name from submodule URL
        """
        try:
            if '_git' in submodule_url:
                # Extract repository name from URL like: http://tfs1:8080/tfs/SilverArrowCollection/VMSC_App/_git/SubmoduleRepo
                parts = submodule_url.split('/')
                if '_git' in parts:
                    git_index = parts.index('_git')
                    if git_index + 1 < len(parts):
                        repo_name = parts[git_index + 1]
                        self.logger.debug(f"Extracted repository name '{repo_name}' from URL: {submodule_url}")
                        return repo_name
            
            # Fallback: try to extract from the end of URL
            repo_name = submodule_url.rstrip('/').split('/')[-1]
            if repo_name and repo_name != '_git':
                self.logger.debug(f"Fallback extracted repository name '{repo_name}' from URL: {submodule_url}")
                return repo_name
            
            self.logger.warning(f"Could not extract repository name from URL: {submodule_url}")
            return None
            
        except Exception as e:
            self.logger.error(f"Error extracting repository name from URL '{submodule_url}': {str(e)}")
            return None
