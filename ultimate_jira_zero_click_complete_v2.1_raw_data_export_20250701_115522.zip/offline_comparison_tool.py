#!/usr/bin/env python3
"""
Offline Comparison Tool with Raw Data Export
Processes CSV and exports all raw data for analysis and troubleshooting
"""

import pandas as pd
import json
import os
import re
from datetime import datetime
from typing import Dict, Any, List, Tuple

class OfflineComparisonTool:
    """Offline tool that exports all raw data for analysis"""
    
    def __init__(self):
        self.input_data = []
        self.processed_data = []
        self.qc_patterns = []
        self.column_mappings = {}
        self.processing_log = []
    
    def process_csv_with_analysis(self, csv_path: str) -> Dict[str, Any]:
        """Process CSV and export detailed analysis data"""
        print(f"Processing CSV: {csv_path}")
        
        try:
            # Load CSV
            df = pd.read_csv(csv_path)
            self.input_data = df.to_dict('records')
            
            # Analyze columns
            self.column_mappings = self._analyze_columns(df)
            
            # Process each row
            for idx, row in enumerate(self.input_data):
                processed_row = self._process_row(row, idx)
                self.processed_data.append(processed_row)
            
            # Generate analysis results
            results = {
                'input_summary': {
                    'total_rows': len(self.input_data),
                    'columns': list(df.columns),
                    'column_mappings': self.column_mappings,
                    'sample_data': self.input_data[:3]
                },
                'processed_data': self.processed_data,
                'qc_patterns_found': self.qc_patterns,
                'processing_log': self.processing_log,
                'analysis_timestamp': datetime.now().isoformat()
            }
            
            return results
            
        except Exception as e:
            print(f"Error processing CSV: {e}")
            return {}
    
    def _analyze_columns(self, df: pd.DataFrame) -> Dict[str, str]:
        """Analyze and map CSV columns"""
        columns = df.columns.tolist()
        mappings = {}
        
        # Common column patterns
        patterns = {
            'qc_number': ['qc_number', 'bug_number', 'qc_id', 'id', 'number', 'qc', 'ticket'],
            'summary': ['summary', 'description', 'title', 'bug_summary', 'issue_summary'],
            'priority': ['priority', 'severity', 'level', 'criticality'],
            'status': ['status', 'state', 'condition'],
            'assignee': ['assignee', 'assigned_to', 'owner', 'developer'],
            'component': ['component', 'module', 'area', 'subsystem'],
            'type': ['type', 'category', 'kind', 'classification']
        }
        
        for standard_name, possible_names in patterns.items():
            for col in columns:
                if any(pattern.lower() in col.lower() for pattern in possible_names):
                    mappings[standard_name] = col
                    break
        
        self.processing_log.append(f"Column mappings identified: {mappings}")
        return mappings
    
    def _process_row(self, row: Dict[str, Any], index: int) -> Dict[str, Any]:
        """Process individual row and extract QC patterns"""
        processed = {
            'original_index': index,
            'original_data': row,
            'extracted_qc_number': None,
            'qc_patterns_found': [],
            'processing_notes': []
        }
        
        # Extract QC number using multiple methods
        qc_candidates = []
        
        # Method 1: Check mapped QC columns
        if 'qc_number' in self.column_mappings:
            col_name = self.column_mappings['qc_number']
            if col_name in row and row[col_name]:
                qc_candidates.append(('column_mapping', str(row[col_name])))
        
        # Method 2: Check all columns for QC patterns
        for col_name, value in row.items():
            if value and isinstance(value, (str, int, float)):
                value_str = str(value)
                qc_patterns = self._extract_qc_patterns(value_str)
                for pattern in qc_patterns:
                    qc_candidates.append(('pattern_match', pattern, col_name))
        
        # Method 3: Check for numeric values that could be QC numbers
        for col_name, value in row.items():
            if isinstance(value, (int, float)) and 1 <= value <= 999999:
                qc_candidates.append(('numeric_value', str(int(value)), col_name))
        
        processed['qc_candidates'] = qc_candidates
        
        # Select best QC number
        if qc_candidates:
            # Prefer column mapping first, then pattern matches
            for method, qc_num, *extra in qc_candidates:
                if method == 'column_mapping':
                    processed['extracted_qc_number'] = qc_num
                    processed['qc_extraction_method'] = 'column_mapping'
                    break
            
            if not processed['extracted_qc_number']:
                # Use first pattern match
                for method, qc_num, *extra in qc_candidates:
                    if method == 'pattern_match':
                        processed['extracted_qc_number'] = qc_num
                        processed['qc_extraction_method'] = 'pattern_match'
                        break
            
            if not processed['extracted_qc_number']:
                # Use numeric value as last resort
                method, qc_num, col_name = qc_candidates[0]
                processed['extracted_qc_number'] = qc_num
                processed['qc_extraction_method'] = 'numeric_fallback'
        
        # Extract other fields
        processed['extracted_summary'] = self._extract_field(row, 'summary')
        processed['extracted_priority'] = self._extract_field(row, 'priority')
        processed['extracted_status'] = self._extract_field(row, 'status')
        
        return processed
    
    def _extract_qc_patterns(self, text: str) -> List[str]:
        """Extract QC patterns from text"""
        patterns = [
            r'QC\s*ID#?\s*(\d+)',
            r'QC\s*#?\s*(\d+)',
            r'ID\s*#?\s*(\d+)',
            r'#(\d+)',
            r'(\d{4,6})',  # 4-6 digit numbers
        ]
        
        found_patterns = []
        for pattern in patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            found_patterns.extend(matches)
        
        return list(set(found_patterns))  # Remove duplicates
    
    def _extract_field(self, row: Dict[str, Any], field_type: str) -> str:
        """Extract field using column mapping or fallback"""
        if field_type in self.column_mappings:
            col_name = self.column_mappings[field_type]
            if col_name in row and row[col_name]:
                return str(row[col_name])
        
        # Fallback to searching all columns
        for col_name, value in row.items():
            if field_type.lower() in col_name.lower() and value:
                return str(value)
        
        return ""
    
    def create_simulated_jira_data(self, count: int = 50) -> List[Dict[str, Any]]:
        """Create simulated Jira data for testing comparison logic"""
        simulated_bugs = []
        
        # Create some bugs that would be duplicates
        sample_qc_numbers = ['12345', '67890', '11111', '22222', '33333']
        
        for i, qc_num in enumerate(sample_qc_numbers):
            bug = {
                'key': f'ASUVNG-{1000 + i}',
                'qc_number': qc_num,
                'summary': f'QC ID #{qc_num} - Sample existing bug {i+1}',
                'status': 'Open',
                'assignee': 'John Doe',
                'priority': 'Medium',
                'created': '2024-01-01T10:00:00.000Z',
                'jira_url': f'https://jira.esl.corp.elbit.co.il/browse/ASUVNG-{1000 + i}',
                'data_source': 'simulated_for_testing'
            }
            simulated_bugs.append(bug)
        
        # Add some additional bugs
        for i in range(5, count):
            bug = {
                'key': f'ASUVNG-{1000 + i}',
                'qc_number': str(10000 + i),
                'summary': f'QC ID #{10000 + i} - Another existing bug',
                'status': 'In Progress',
                'assignee': 'Jane Smith',
                'priority': 'High',
                'created': '2024-01-01T10:00:00.000Z',
                'jira_url': f'https://jira.esl.corp.elbit.co.il/browse/ASUVNG-{1000 + i}',
                'data_source': 'simulated_for_testing'
            }
            simulated_bugs.append(bug)
        
        return simulated_bugs
    
    def compare_data(self, csv_results: Dict[str, Any], jira_data: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Compare processed CSV data with Jira data"""
        print("Comparing CSV data with Jira data...")
        
        # Extract QC numbers from both sources
        csv_qc_numbers = set()
        jira_qc_numbers = set()
        
        for item in csv_results['processed_data']:
            if item['extracted_qc_number']:
                csv_qc_numbers.add(item['extracted_qc_number'])
        
        for bug in jira_data:
            if bug.get('qc_number'):
                jira_qc_numbers.add(str(bug['qc_number']))
        
        # Find overlaps and differences
        duplicates = csv_qc_numbers.intersection(jira_qc_numbers)
        new_bugs = csv_qc_numbers - jira_qc_numbers
        
        # Create detailed comparison
        comparison_result = {
            'csv_qc_numbers': sorted(list(csv_qc_numbers)),
            'jira_qc_numbers': sorted(list(jira_qc_numbers)),
            'duplicates': sorted(list(duplicates)),
            'new_bugs': sorted(list(new_bugs)),
            'duplicate_count': len(duplicates),
            'new_count': len(new_bugs),
            'total_csv_bugs': len(csv_qc_numbers),
            'total_jira_bugs': len(jira_qc_numbers),
            'comparison_timestamp': datetime.now().isoformat()
        }
        
        # Add detailed records
        comparison_result['duplicate_details'] = []
        comparison_result['new_bug_details'] = []
        
        for item in csv_results['processed_data']:
            qc_num = item['extracted_qc_number']
            if qc_num in duplicates:
                comparison_result['duplicate_details'].append({
                    'qc_number': qc_num,
                    'csv_data': item,
                    'jira_match': next((bug for bug in jira_data if str(bug.get('qc_number', '')) == qc_num), None)
                })
            elif qc_num in new_bugs:
                comparison_result['new_bug_details'].append({
                    'qc_number': qc_num,
                    'csv_data': item
                })
        
        return comparison_result
    
    def export_all_data(self, csv_results: Dict[str, Any], jira_data: List[Dict[str, Any]], comparison_result: Dict[str, Any]) -> List[str]:
        """Export all data for analysis"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        exported_files = []
        
        # 1. Raw CSV input data
        csv_input_file = f'raw_csv_input_data_{timestamp}.json'
        with open(csv_input_file, 'w') as f:
            json.dump(csv_results, f, indent=2)
        exported_files.append(csv_input_file)
        print(f"Exported raw CSV data: {csv_input_file}")
        
        # 2. Raw Jira data
        jira_data_file = f'raw_jira_data_{timestamp}.json'
        with open(jira_data_file, 'w') as f:
            json.dump(jira_data, f, indent=2)
        exported_files.append(jira_data_file)
        print(f"Exported raw Jira data: {jira_data_file}")
        
        # 3. Detailed comparison results
        comparison_file = f'detailed_comparison_results_{timestamp}.json'
        with open(comparison_file, 'w') as f:
            json.dump(comparison_result, f, indent=2)
        exported_files.append(comparison_file)
        print(f"Exported comparison results: {comparison_file}")
        
        # 4. Processing log
        log_file = f'processing_log_{timestamp}.txt'
        with open(log_file, 'w') as f:
            f.write("PROCESSING LOG\n")
            f.write("=" * 50 + "\n")
            f.write(f"Timestamp: {datetime.now()}\n\n")
            
            f.write("CSV Analysis:\n")
            f.write(f"- Total rows: {len(csv_results.get('processed_data', []))}\n")
            f.write(f"- Columns found: {csv_results.get('input_summary', {}).get('columns', [])}\n")
            f.write(f"- Column mappings: {csv_results.get('input_summary', {}).get('column_mappings', {})}\n\n")
            
            f.write("QC Number Extraction:\n")
            qc_extraction_methods = {}
            for item in csv_results.get('processed_data', []):
                method = item.get('qc_extraction_method', 'unknown')
                qc_extraction_methods[method] = qc_extraction_methods.get(method, 0) + 1
            
            for method, count in qc_extraction_methods.items():
                f.write(f"- {method}: {count} bugs\n")
            
            f.write(f"\nComparison Results:\n")
            f.write(f"- CSV QC numbers: {len(comparison_result.get('csv_qc_numbers', []))}\n")
            f.write(f"- Jira QC numbers: {len(comparison_result.get('jira_qc_numbers', []))}\n")
            f.write(f"- Duplicates found: {len(comparison_result.get('duplicates', []))}\n")
            f.write(f"- New bugs to create: {len(comparison_result.get('new_bugs', []))}\n")
            
            f.write(f"\nProcessing Log:\n")
            for log_entry in self.processing_log:
                f.write(f"- {log_entry}\n")
        
        exported_files.append(log_file)
        print(f"Exported processing log: {log_file}")
        
        # 5. Human-readable summary
        summary_file = f'analysis_summary_{timestamp}.txt'
        with open(summary_file, 'w') as f:
            f.write("ANALYSIS SUMMARY\n")
            f.write("=" * 50 + "\n")
            f.write(f"Generated: {datetime.now()}\n\n")
            
            f.write("INPUT DATA:\n")
            f.write(f"- CSV file processed with {len(csv_results.get('processed_data', []))} rows\n")
            f.write(f"- Jira data contains {len(jira_data)} existing bugs\n\n")
            
            f.write("QC NUMBERS FOUND:\n")
            f.write(f"- In CSV: {comparison_result.get('csv_qc_numbers', [])}\n")
            f.write(f"- In Jira: {comparison_result.get('jira_qc_numbers', [])}\n\n")
            
            f.write("COMPARISON RESULTS:\n")
            f.write(f"- Duplicates (skip these): {comparison_result.get('duplicates', [])}\n")
            f.write(f"- New bugs (create these): {comparison_result.get('new_bugs', [])}\n\n")
            
            f.write("DETAILED BREAKDOWN:\n")
            for detail in comparison_result.get('duplicate_details', []):
                f.write(f"DUPLICATE: QC {detail['qc_number']}\n")
                f.write(f"  CSV: {detail['csv_data']['original_data']}\n")
                f.write(f"  Jira: {detail['jira_match']['summary'] if detail['jira_match'] else 'Not found'}\n\n")
            
            for detail in comparison_result.get('new_bug_details', []):
                f.write(f"NEW: QC {detail['qc_number']}\n")
                f.write(f"  CSV: {detail['csv_data']['original_data']}\n\n")
        
        exported_files.append(summary_file)
        print(f"Exported analysis summary: {summary_file}")
        
        return exported_files


def run_offline_analysis(csv_file: str = 'sample_data/bugs_input.csv') -> Dict[str, Any]:
    """Run complete offline analysis with raw data export"""
    print("Starting offline analysis with raw data export...")
    
    tool = OfflineComparisonTool()
    
    # Process CSV
    csv_results = tool.process_csv_with_analysis(csv_file)
    if not csv_results:
        print("Failed to process CSV file")
        return {}
    
    # Create simulated Jira data (since we can't connect to real Jira)
    jira_data = tool.create_simulated_jira_data(50)
    print(f"Created {len(jira_data)} simulated Jira bugs for comparison")
    
    # Compare data
    comparison_result = tool.compare_data(csv_results, jira_data)
    
    # Export all data
    exported_files = tool.export_all_data(csv_results, jira_data, comparison_result)
    
    print(f"\nANALYSIS COMPLETE!")
    print(f"Exported {len(exported_files)} files for analysis:")
    for file in exported_files:
        print(f"  - {file}")
    
    return {
        'csv_results': csv_results,
        'jira_data': jira_data,
        'comparison_result': comparison_result,
        'exported_files': exported_files
    }


if __name__ == "__main__":
    # Run offline analysis
    results = run_offline_analysis()
    
    if results:
        print("\n" + "="*60)
        print("OFFLINE ANALYSIS RESULTS")
        print("="*60)
        print(f"CSV bugs processed: {len(results['csv_results'].get('processed_data', []))}")
        print(f"Jira bugs (simulated): {len(results['jira_data'])}")
        print(f"Duplicates found: {results['comparison_result'].get('duplicate_count', 0)}")
        print(f"New bugs to create: {results['comparison_result'].get('new_count', 0)}")
        print(f"Files exported: {len(results['exported_files'])}")
        print("\nCheck the exported JSON and TXT files for detailed analysis.")
    else:
        print("Analysis failed. Check the error messages above.")