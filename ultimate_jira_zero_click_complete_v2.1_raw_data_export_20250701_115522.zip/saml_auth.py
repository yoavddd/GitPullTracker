"""
SAML Authentication Module for Corporate Jira
Handles SAML-based authentication for corporate environments
"""

import requests
import re
import logging
from typing import Dict, Any, Optional, Tuple
from urllib.parse import urljoin, urlparse, parse_qs
from requests.sessions import Session


class SAMLAuthenticator:
    """Handles SAML authentication for corporate Jira instances"""
    
    def __init__(self, jira_url: str, verify_ssl: bool = True):
        """
        Initialize SAML authenticator
        
        Args:
            jira_url: Base Jira URL
            verify_ssl: Whether to verify SSL certificates
        """
        self.logger = logging.getLogger(__name__)
        self.jira_url = jira_url.rstrip('/')
        self.verify_ssl = verify_ssl
        
        # Create session with SSL settings
        self.session = requests.Session()
        self.session.verify = verify_ssl
        
        if not verify_ssl:
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            self.logger.warning("SSL verification disabled for SAML authentication")
    
    def authenticate_with_credentials(self, username: str, password: str) -> Tuple[bool, Optional[Session]]:
        """
        Authenticate using username/password through SAML flow
        
        Args:
            username: Corporate username
            password: Corporate password
            
        Returns:
            Tuple of (success, authenticated_session)
        """
        try:
            self.logger.info("Starting SAML authentication flow...")
            
            # Step 1: Get the initial login page to discover SAML endpoint
            login_url = f"{self.jira_url}/login.jsp"
            self.logger.info(f"Accessing login page: {login_url}")
            
            response = self.session.get(login_url)
            if response.status_code != 200:
                self.logger.error(f"Failed to access login page: {response.status_code}")
                return False, None
            
            # Step 2: Look for SAML redirect or SSO links
            saml_url = self._find_saml_endpoint(response.text, response.url)
            if not saml_url:
                # Try direct credential authentication if no SAML found
                return self._try_direct_auth(username, password)
            
            # Step 3: Follow SAML authentication flow
            self.logger.info(f"Following SAML authentication: {saml_url}")
            return self._complete_saml_flow(saml_url, username, password)
            
        except Exception as e:
            self.logger.error(f"SAML authentication failed: {e}")
            return False, None
    
    def _find_saml_endpoint(self, html_content: str, current_url: str) -> Optional[str]:
        """
        Find SAML/SSO endpoint in the HTML content
        
        Args:
            html_content: HTML content from login page
            current_url: Current page URL
            
        Returns:
            SAML endpoint URL if found, None otherwise
        """
        # Common patterns for SAML/SSO links
        patterns = [
            r'href=["\']([^"\']*sso[^"\']*)["\']',
            r'href=["\']([^"\']*saml[^"\']*)["\']',
            r'action=["\']([^"\']*auth[^"\']*)["\']',
            r'href=["\']([^"\']*login[^"\']*)["\']'
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, html_content, re.IGNORECASE)
            for match in matches:
                if 'sso' in match.lower() or 'saml' in match.lower():
                    # Convert relative URLs to absolute
                    if match.startswith('/'):
                        return urljoin(self.jira_url, match)
                    elif match.startswith('http'):
                        return match
        
        # Check for meta refresh or JavaScript redirects
        meta_pattern = r'<meta[^>]*url=([^"\'>\s]+)'
        meta_matches = re.findall(meta_pattern, html_content, re.IGNORECASE)
        for match in meta_matches:
            if 'auth' in match.lower() or 'sso' in match.lower():
                return urljoin(self.jira_url, match)
        
        return None
    
    def _try_direct_auth(self, username: str, password: str) -> Tuple[bool, Optional[Session]]:
        """
        Try direct authentication if SAML not detected
        
        Args:
            username: Username
            password: Password
            
        Returns:
            Tuple of (success, session)
        """
        self.logger.info("Attempting direct authentication...")
        
        # Try standard Jira login
        login_data = {
            'username': username,
            'password': password,
            'rememberMe': 'false'
        }
        
        login_url = f"{self.jira_url}/rest/auth/1/session"
        
        try:
            response = self.session.post(
                login_url,
                json=login_data,
                headers={'Content-Type': 'application/json'}
            )
            
            if response.status_code == 200:
                self.logger.info("Direct authentication successful")
                return True, self.session
            else:
                self.logger.error(f"Direct authentication failed: {response.status_code}")
                return False, None
                
        except Exception as e:
            self.logger.error(f"Direct authentication error: {e}")
            return False, None
    
    def _complete_saml_flow(self, saml_url: str, username: str, password: str) -> Tuple[bool, Optional[Session]]:
        """
        Complete the SAML authentication flow
        
        Args:
            saml_url: SAML endpoint URL
            username: Username
            password: Password
            
        Returns:
            Tuple of (success, session)
        """
        try:
            # Step 1: Access SAML endpoint
            response = self.session.get(saml_url)
            
            # Step 2: Look for authentication form
            form_data = self._extract_form_data(response.text)
            if not form_data:
                self.logger.error("Could not find authentication form")
                return False, None
            
            # Step 3: Submit credentials
            auth_url = form_data.get('action') or saml_url
            if not auth_url.startswith('http'):
                auth_url = urljoin(saml_url, auth_url)
            
            # Prepare authentication data
            auth_data = form_data.get('data', {})
            auth_data.update({
                'username': username,
                'password': password,
                'user': username,
                'j_username': username,
                'j_password': password
            })
            
            self.logger.info(f"Submitting credentials to: {auth_url}")
            auth_response = self.session.post(auth_url, data=auth_data)
            
            # Step 4: Follow any redirects back to Jira
            if auth_response.status_code in [200, 302, 303]:
                # Check if we're back at Jira and authenticated
                test_response = self.session.get(f"{self.jira_url}/rest/api/2/myself")
                if test_response.status_code == 200:
                    self.logger.info("SAML authentication successful")
                    return True, self.session
            
            self.logger.error("SAML authentication flow failed")
            return False, None
            
        except Exception as e:
            self.logger.error(f"SAML flow error: {e}")
            return False, None
    
    def _extract_form_data(self, html_content: str) -> Optional[Dict[str, Any]]:
        """
        Extract form data from HTML content
        
        Args:
            html_content: HTML content
            
        Returns:
            Dictionary with form action and data
        """
        # Find form element
        form_pattern = r'<form[^>]*action=["\']([^"\']*)["\'][^>]*>(.*?)</form>'
        form_match = re.search(form_pattern, html_content, re.DOTALL | re.IGNORECASE)
        
        if not form_match:
            return None
        
        action = form_match.group(1)
        form_content = form_match.group(2)
        
        # Extract hidden inputs
        input_pattern = r'<input[^>]*name=["\']([^"\']*)["\'][^>]*value=["\']([^"\']*)["\'][^>]*>'
        inputs = re.findall(input_pattern, form_content, re.IGNORECASE)
        
        form_data = {}
        for name, value in inputs:
            form_data[name] = value
        
        return {
            'action': action,
            'data': form_data
        }


def authenticate_jira_saml(jira_url: str, username: str, password: str, verify_ssl: bool = True) -> Optional[Session]:
    """
    Convenience function to authenticate with Jira using SAML
    
    Args:
        jira_url: Jira base URL
        username: Corporate username
        password: Corporate password
        verify_ssl: Whether to verify SSL certificates
        
    Returns:
        Authenticated session if successful, None otherwise
    """
    authenticator = SAMLAuthenticator(jira_url, verify_ssl)
    success, session = authenticator.authenticate_with_credentials(username, password)
    
    if success:
        return session
    else:
        return None


# Example usage
if __name__ == "__main__":
    # Test SAML authentication
    jira_url = "https://jira.esl.corp.elbit.co.il"
    username = "your-username"
    password = "your-password"
    
    session = authenticate_jira_saml(jira_url, username, password, verify_ssl=False)
    
    if session:
        print("SAML authentication successful!")
        # Test API call
        response = session.get(f"{jira_url}/rest/api/2/myself")
        if response.status_code == 200:
            user_info = response.json()
            print(f"Logged in as: {user_info.get('displayName')}")
        else:
            print(f"API test failed: {response.status_code}")
    else:
        print("SAML authentication failed")