import zipfile
import os

# Create final ZIP file with complete SAML support
with zipfile.ZipFile('jira_integration_system_final.zip', 'w', zipfile.ZIP_DEFLATED) as zipf:
    # Add all Python files including SAML support
    for file in ['main.py', 'api_interface.py', 'jira_integration.py', 'csv_processor.py', 
                 'config_manager.py', 'duplicate_checker.py', 'wbs_structure_manager.py', 
                 'logger_setup.py', 'demo.py', 'test_credentials.py', 'saml_auth.py', 'test_saml_auth.py']:
        if os.path.exists(file):
            zipf.write(file)
    
    # Add config directory with all configuration files
    for root, dirs, files in os.walk('config'):
        for file in files:
            file_path = os.path.join(root, file)
            zipf.write(file_path)
    
    # Add sample_data directory
    for root, dirs, files in os.walk('sample_data'):
        for file in files:
            file_path = os.path.join(root, file)
            zipf.write(file_path)
    
    # Add tests directory
    for root, dirs, files in os.walk('tests'):
        for file in files:
            file_path = os.path.join(root, file)
            zipf.write(file_path)
    
    # Add all documentation files
    for file in ['README.md', 'replit.md', '.env.example', 'CORPORATE_SETUP.md']:
        if os.path.exists(file):
            zipf.write(file)

print('Final ZIP file created: jira_integration_system_final.zip')