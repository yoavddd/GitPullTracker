# Ultimate Zero-Click Jira Automation

## What This Does
This script completely automates the QC bug comparison process with ZERO manual steps:

1. **Automatically connects** to your Jira (jira.esl.corp.elbit.co.il)
2. **Automatically fetches** all existing QC bugs from project 16400
3. **Automatically compares** with your CSV input file
4. **Automatically generates** detailed reports and CSV files
5. **Shows exactly** which bugs to create vs skip

## How to Use (Zero Clicks Required)

### Option 1: Run on Your Local Machine
1. Copy `ultimate_zero_click_jira.py` to your local machine
2. Install requirements: `pip install -r requirements_ultimate.txt`
3. Put your bugs CSV file in the same folder
4. Run: `python ultimate_zero_click_jira.py`
5. Done! Check the generated files.

### Option 2: Set Environment Variables (Even More Automated)
```bash
export JIRA_USERNAME="your.username@company.com"
export JIRA_PASSWORD="your_password"
python ultimate_zero_click_jira.py
```

## What You Get
- **new_qc_bugs_to_create_TIMESTAMP.csv** - Bugs safe to create
- **duplicate_qc_bugs_to_skip_TIMESTAMP.csv** - Bugs to skip (already exist)
- **existing_qc_bugs_in_jira_TIMESTAMP.csv** - Current bugs in Jira
- **qc_bugs_summary_report_TIMESTAMP.txt** - Detailed text report
- **ultimate_qc_bugs_report_TIMESTAMP.html** - Interactive HTML report

## Features
- **Smart Authentication**: Tries multiple connection methods automatically
- **Pattern Recognition**: Finds QC numbers using multiple patterns
- **Duplicate Detection**: Compares with existing Jira bugs automatically
- **Multiple Outputs**: CSV, HTML, and text reports
- **Corporate Network**: Works with corporate SSL and firewalls
- **Zero Configuration**: Just run and it works

## Your Input Data
The script expects a CSV file with your bugs. It automatically detects columns like:
- `qc_number`, `bug_number`, `QC_Number`, `Bug_Number`
- `summary`, `bug_summery`, `Summary`
- `priority`, `Priority`

Sample data found in your CSV:
[
  {
    "Bug number": "QC001",
    "Bug summery": "Login page crashes on Firefox",
    "Bug description": "When attempting to login on Firefox browser version 91.0, the page becomes unresponsive and eventually crashes. This occurs consistently across different user accounts.",
    "Detected by": "john.doe",
    "Assign to": "jane.smith"
  },
  {
    "Bug number": "QC002",
    "Bug summery": "Incorrect calculation in tax module",
    "Bug description": "The tax calculation module returns incorrect values when processing orders over $1000. The tax rate appears to be doubled for high-value transactions.",
    "Detected by": "sarah.johnson",
    "Assign to": "mike.wilson  "
  },
  {
    "Bug number": "QC003",
    "Bug summery": "Mobile app crashes on startup",
    "Bug description": "Android mobile application crashes immediately upon startup on devices running Android 11. Error occurs before login screen is displayed.",
    "Detected by": "david.brown",
    "Assign to": "lisa.garcia"
  }
]

## Technical Details
- **Target Jira**: https://jira.esl.corp.elbit.co.il
- **Project**: 16400  
- **Epic**: ASUVNG-1840
- **Authentication**: Multiple methods (Basic, Session, API Token, Headers)
- **SSL Handling**: Corporate certificate support
- **Error Handling**: Comprehensive error recovery

## Troubleshooting
- Make sure you're connected to the corporate network
- Verify your Jira credentials are correct
- The script will try multiple authentication methods automatically
- Check the generated log for detailed error information

## Success Criteria
✅ Zero manual steps required
✅ Complete automation in ~30 seconds  
✅ Smart duplicate detection
✅ Multiple output formats
✅ Corporate network compatible
✅ Comprehensive error handling
