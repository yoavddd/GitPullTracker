"""
Browser Session Authentication Module
Handles complex authentication scenarios using requests sessions that mimic browser behavior
"""

import logging
import time
import json
import requests
from typing import Dict, Any, Optional, List
from urllib.parse import urljoin, urlparse
import re

class BrowserSessionAuth:
    """Browser-like session authentication handler for Jira"""
    
    def __init__(self, jira_config: Dict[str, Any]):
        """
        Initialize browser session authentication
        
        Args:
            jira_config: Jira configuration dictionary
        """
        self.jira_config = jira_config
        self.jira_url = jira_config.get('url', '').rstrip('/')
        self.username = jira_config.get('username', '')
        self.password = jira_config.get('password', '')
        self.session = requests.Session()
        self.logger = logging.getLogger(__name__)
        
        # Setup session with browser-like headers
        self._setup_session()
    
    def _setup_session(self):
        """Setup session with browser-like configuration"""
        # Browser-like headers
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Cache-Control': 'max-age=0'
        })
        
        # Handle SSL verification
        self.session.verify = self.jira_config.get('verify_ssl', True)
        
        # Enable cookie persistence
        self.session.cookies.clear()
    
    def authenticate(self) -> bool:
        """
        Perform authentication using browser-like session
        
        Returns:
            True if authentication successful, False otherwise
        """
        try:
            self.logger.info("Starting browser session-based Jira authentication")
            
            # Step 1: Get the login page to establish session
            login_url = f"{self.jira_url}/login.jsp"
            self.logger.info(f"Accessing login page: {login_url}")
            
            response = self.session.get(login_url, timeout=30)
            
            if response.status_code != 200:
                self.logger.error(f"Failed to access login page. Status: {response.status_code}")
                return False
            
            # Check if we're redirected to SAML/SSO
            final_url = response.url
            self.logger.info(f"Final URL after redirect: {final_url}")
            
            if "saml" in final_url.lower() or "sso" in final_url.lower():
                return self._handle_saml_flow(response)
            elif "atlassian" in final_url:
                return self._handle_atlassian_flow(response)
            else:
                return self._handle_standard_flow(response)
                
        except Exception as e:
            self.logger.error(f"Authentication failed: {e}")
            return False
    
    def _handle_saml_flow(self, initial_response: requests.Response) -> bool:
        """Handle SAML/SSO authentication flow"""
        self.logger.info("Detected SAML/SSO authentication flow")
        
        try:
            # Parse the SAML login form
            form_data = self._extract_form_data(initial_response.text)
            
            if not form_data:
                self.logger.error("Could not find login form in SAML page")
                return False
            
            # Update form data with credentials
            form_data['username'] = self.username
            form_data['user'] = self.username
            form_data['email'] = self.username
            form_data['password'] = self.password
            
            # Submit the form
            action_url = self._get_form_action(initial_response.text, initial_response.url)
            
            self.logger.info(f"Submitting SAML login form to: {action_url}")
            
            # Set form headers
            self.session.headers.update({
                'Content-Type': 'application/x-www-form-urlencoded',
                'Referer': initial_response.url
            })
            
            response = self.session.post(action_url, data=form_data, timeout=30, allow_redirects=True)
            
            # Check if authentication was successful
            return self._check_authentication_success(response)
            
        except Exception as e:
            self.logger.error(f"SAML authentication error: {e}")
            return False
    
    def _handle_atlassian_flow(self, initial_response: requests.Response) -> bool:
        """Handle Atlassian Cloud authentication flow"""
        self.logger.info("Detected Atlassian Cloud authentication")
        
        try:
            # Extract CSRF token and form data
            form_data = self._extract_form_data(initial_response.text)
            
            # First, submit username
            form_data['username'] = self.username
            
            action_url = self._get_form_action(initial_response.text, initial_response.url)
            
            self.session.headers.update({
                'Content-Type': 'application/x-www-form-urlencoded',
                'Referer': initial_response.url
            })
            
            response = self.session.post(action_url, data=form_data, timeout=30, allow_redirects=True)
            
            # Now handle password page
            if "password" in response.text.lower():
                password_form_data = self._extract_form_data(response.text)
                password_form_data['password'] = self.password
                
                password_action_url = self._get_form_action(response.text, response.url)
                
                response = self.session.post(password_action_url, data=password_form_data, timeout=30, allow_redirects=True)
            
            return self._check_authentication_success(response)
            
        except Exception as e:
            self.logger.error(f"Atlassian authentication error: {e}")
            return False
    
    def _handle_standard_flow(self, initial_response: requests.Response) -> bool:
        """Handle standard Jira authentication"""
        self.logger.info("Attempting standard Jira authentication")
        
        try:
            # Extract form data
            form_data = self._extract_form_data(initial_response.text)
            
            # Set credentials
            form_data['os_username'] = self.username
            form_data['os_password'] = self.password
            form_data['login'] = 'Log In'
            
            action_url = self._get_form_action(initial_response.text, initial_response.url)
            
            self.session.headers.update({
                'Content-Type': 'application/x-www-form-urlencoded',
                'Referer': initial_response.url
            })
            
            response = self.session.post(action_url, data=form_data, timeout=30, allow_redirects=True)
            
            return self._check_authentication_success(response)
            
        except Exception as e:
            self.logger.error(f"Standard authentication error: {e}")
            return False
    
    def _extract_form_data(self, html_content: str) -> Dict[str, str]:
        """Extract hidden form fields and CSRF tokens"""
        form_data = {}
        
        # Find all input fields
        input_pattern = r'<input[^>]*name=["\']([^"\']*)["\'][^>]*value=["\']([^"\']*)["\'][^>]*>'
        inputs = re.findall(input_pattern, html_content)
        
        for name, value in inputs:
            if name and not name.lower() in ['username', 'password', 'user', 'email']:
                form_data[name] = value
        
        # Look for CSRF tokens specifically
        csrf_patterns = [
            r'name=["\']_token["\'][^>]*value=["\']([^"\']*)["\']',
            r'name=["\']csrf_token["\'][^>]*value=["\']([^"\']*)["\']',
            r'name=["\']authenticity_token["\'][^>]*value=["\']([^"\']*)["\']',
            r'name=["\']atl_token["\'][^>]*value=["\']([^"\']*)["\']'
        ]
        
        for pattern in csrf_patterns:
            matches = re.findall(pattern, html_content)
            if matches:
                # Extract the field name and value
                token_pattern = r'name=["\']([^"\']*token[^"\']*)["\'][^>]*value=["\']([^"\']*)["\']'
                token_matches = re.findall(token_pattern, html_content, re.IGNORECASE)
                for token_name, token_value in token_matches:
                    form_data[token_name] = token_value
        
        return form_data
    
    def _get_form_action(self, html_content: str, current_url: str) -> str:
        """Extract form action URL"""
        # Look for form action
        action_pattern = r'<form[^>]*action=["\']([^"\']*)["\']'
        matches = re.findall(action_pattern, html_content)
        
        if matches:
            action = matches[0]
            # Handle relative URLs
            if action.startswith('/'):
                parsed_url = urlparse(current_url)
                return f"{parsed_url.scheme}://{parsed_url.netloc}{action}"
            elif action.startswith('http'):
                return action
            else:
                return urljoin(current_url, action)
        
        # Default to current URL if no action found
        return current_url
    
    def _check_authentication_success(self, response: requests.Response) -> bool:
        """Check if authentication was successful"""
        # Check for common success indicators
        success_indicators = [
            'dashboard',
            'secure/',
            'browse/',
            self.jira_url
        ]
        
        current_url = response.url.lower()
        
        for indicator in success_indicators:
            if indicator in current_url:
                self.logger.info(f"Authentication successful. Final URL: {response.url}")
                return True
        
        # Check for error indicators
        error_indicators = [
            'login failed',
            'invalid username',
            'invalid password',
            'authentication failed',
            'login.jsp'
        ]
        
        response_text = response.text.lower()
        
        for error in error_indicators:
            if error in response_text:
                self.logger.error(f"Authentication failed. Error indicator found: {error}")
                return False
        
        # If we have cookies, likely authenticated
        if len(self.session.cookies) > 2:
            self.logger.info("Authentication appears successful based on cookies")
            return True
        
        self.logger.warning(f"Authentication status unclear. Final URL: {response.url}")
        return False
    
    def test_api_access(self) -> bool:
        """Test API access using authenticated session"""
        try:
            # Update headers for API calls
            self.session.headers.update({
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            })
            
            # Test with /rest/api/2/myself endpoint
            api_url = f"{self.jira_url}/rest/api/2/myself"
            response = self.session.get(api_url, timeout=30)
            
            if response.status_code == 200:
                try:
                    user_info = response.json()
                    self.logger.info(f"API access successful. User: {user_info.get('displayName', 'Unknown')}")
                    return True
                except json.JSONDecodeError:
                    self.logger.warning("API returned 200 but not JSON. May be HTML redirect.")
                    return False
            else:
                self.logger.error(f"API access failed. Status: {response.status_code}")
                self.logger.debug(f"Response content: {response.text[:500]}")
                return False
                
        except Exception as e:
            self.logger.error(f"API test failed: {e}")
            return False


class BrowserSessionJiraIntegrator:
    """Jira integrator using browser session authentication"""
    
    def __init__(self, jira_config: Dict[str, Any]):
        """Initialize browser session-based Jira integrator"""
        self.jira_config = jira_config
        self.jira_url = jira_config.get('url', '').rstrip('/')
        self.auth_handler = BrowserSessionAuth(jira_config)
        self.session = None
        self.logger = logging.getLogger(__name__)
        
    def authenticate(self) -> bool:
        """Authenticate and setup session"""
        if self.auth_handler.authenticate():
            self.session = self.auth_handler.session
            return self.auth_handler.test_api_access()
        return False
    
    def create_issue(self, issue_data: Dict[str, Any]) -> Optional[str]:
        """Create a Jira issue"""
        if not self.session:
            self.logger.error("Not authenticated. Call authenticate() first.")
            return None
            
        try:
            url = f"{self.jira_url}/rest/api/2/issue"
            response = self.session.post(url, json=issue_data, timeout=30)
            
            if response.status_code == 201:
                result = response.json()
                issue_key = result.get('key')
                self.logger.info(f"Issue created successfully: {issue_key}")
                return issue_key
            else:
                self.logger.error(f"Failed to create issue. Status: {response.status_code}")
                self.logger.error(f"Response: {response.text}")
                return None
                
        except Exception as e:
            self.logger.error(f"Error creating issue: {e}")
            return None
    
    def search_issues(self, jql: str, fields: Optional[List[str]] = None, max_results: int = 1000) -> List[Dict[str, Any]]:
        """Search for issues using JQL"""
        if not self.session:
            self.logger.error("Not authenticated. Call authenticate() first.")
            return []
            
        try:
            url = f"{self.jira_url}/rest/api/2/search"
            params = {
                'jql': jql,
                'maxResults': max_results
            }
            
            if fields:
                params['fields'] = ','.join(fields)
            
            response = self.session.get(url, params=params, timeout=30)
            
            if response.status_code == 200:
                result = response.json()
                return result.get('issues', [])
            else:
                self.logger.error(f"Search failed. Status: {response.status_code}")
                return []
                
        except Exception as e:
            self.logger.error(f"Error searching issues: {e}")
            return []
    
    def get_project_info(self, project_key: str) -> Optional[Dict[str, Any]]:
        """Get project information"""
        if not self.session:
            self.logger.error("Not authenticated. Call authenticate() first.")
            return None
            
        try:
            url = f"{self.jira_url}/rest/api/2/project/{project_key}"
            response = self.session.get(url, timeout=30)
            
            if response.status_code == 200:
                return response.json()
            else:
                self.logger.error(f"Failed to get project info. Status: {response.status_code}")
                return None
                
        except Exception as e:
            self.logger.error(f"Error getting project info: {e}")
            return None
    
    def test_connection(self) -> bool:
        """Test connection - alias for authenticate for compatibility"""
        return self.authenticate()