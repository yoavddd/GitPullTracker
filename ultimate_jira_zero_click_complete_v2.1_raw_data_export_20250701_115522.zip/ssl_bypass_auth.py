"""
SSL Certificate Bypass Authentication
Handles Jira authentication with SSL certificate trust issues
"""

import logging
import requests
import urllib3
from typing import Dict, Any, Optional, List
import ssl
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# Disable SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class SSLBypassJiraIntegrator:
    """Jira integrator that bypasses SSL certificate validation"""
    
    def __init__(self, jira_config: Dict[str, Any]):
        """Initialize SSL bypass integrator"""
        self.jira_config = jira_config
        self.jira_url = jira_config.get('url', '').rstrip('/')
        self.username = jira_config.get('username', '')
        self.password = jira_config.get('password', '')
        self.api_token = jira_config.get('api_token', '')
        self.session = requests.Session()
        self.logger = logging.getLogger(__name__)
        
        # Setup session with SSL bypass
        self._setup_ssl_bypass_session()
    
    def _setup_ssl_bypass_session(self):
        """Setup session that bypasses SSL certificate validation"""
        
        # Disable SSL verification completely
        self.session.verify = False
        
        # Setup retry strategy
        retry_strategy = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
        )
        
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)
        
        # Set headers that bypass certificate checks
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'X-Atlassian-Token': 'no-check'
        })
        
        # Setup authentication
        if self.api_token:
            self.session.auth = (self.username, self.api_token)
        else:
            self.session.auth = (self.username, self.password)
        
        self.logger.info("SSL bypass session configured")
    
    def test_connection(self) -> bool:
        """Test connection with SSL bypass"""
        try:
            # Test with myself endpoint
            url = f"{self.jira_url}/rest/api/2/myself"
            
            self.logger.info(f"Testing SSL bypass connection to: {url}")
            
            response = self.session.get(url, timeout=30)
            
            if response.status_code == 200:
                user_info = response.json()
                self.logger.info(f"SSL bypass connection successful. User: {user_info.get('displayName', 'Unknown')}")
                return True
            else:
                self.logger.error(f"Connection failed. Status: {response.status_code}")
                self.logger.error(f"Response: {response.text}")
                return False
                
        except Exception as e:
            self.logger.error(f"SSL bypass connection test failed: {e}")
            return False
    
    def create_issue(self, issue_data: Dict[str, Any]) -> Optional[str]:
        """Create a Jira issue with SSL bypass"""
        try:
            url = f"{self.jira_url}/rest/api/2/issue"
            
            response = self.session.post(url, json=issue_data, timeout=30)
            
            if response.status_code == 201:
                result = response.json()
                issue_key = result.get('key')
                self.logger.info(f"Issue created successfully: {issue_key}")
                return issue_key
            else:
                self.logger.error(f"Failed to create issue. Status: {response.status_code}")
                self.logger.error(f"Response: {response.text}")
                return None
                
        except Exception as e:
            self.logger.error(f"Error creating issue: {e}")
            return None
    
    def search_issues(self, jql: str, fields: Optional[List[str]] = None, max_results: int = 1000) -> List[Dict[str, Any]]:
        """Search for issues using JQL with SSL bypass"""
        try:
            url = f"{self.jira_url}/rest/api/2/search"
            params = {
                'jql': jql,
                'maxResults': max_results
            }
            
            if fields:
                params['fields'] = ','.join(fields)
            
            response = self.session.get(url, params=params, timeout=30)
            
            if response.status_code == 200:
                result = response.json()
                return result.get('issues', [])
            else:
                self.logger.error(f"Search failed. Status: {response.status_code}")
                return []
                
        except Exception as e:
            self.logger.error(f"Error searching issues: {e}")
            return []
    
    def get_project_info(self, project_key: str) -> Optional[Dict[str, Any]]:
        """Get project information with SSL bypass"""
        try:
            url = f"{self.jira_url}/rest/api/2/project/{project_key}"
            response = self.session.get(url, timeout=30)
            
            if response.status_code == 200:
                return response.json()
            else:
                self.logger.error(f"Failed to get project info. Status: {response.status_code}")
                return None
                
        except Exception as e:
            self.logger.error(f"Error getting project info: {e}")
            return None