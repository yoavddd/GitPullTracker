"""
Configuration Management Module
Handles loading and validation of JSON configuration files
"""

import json
import os
from typing import Dict, Any, Optional
from pathlib import Path
import jsonschema
from jsonschema import validate

from logger_setup import setup_logger


class ConfigManager:
    """Manages configuration loading and validation"""
    
    def __init__(self, config_file_path: str):
        """
        Initialize configuration manager
        
        Args:
            config_file_path: Path to the JSON configuration file
        """
        self.logger = setup_logger()
        self.config_file_path = config_file_path
        self.config = None
        
        # Define configuration schema for validation
        self.config_schema = {
            "type": "object",
            "properties": {
                "jira": {
                    "type": "object",
                    "properties": {
                        "url": {"type": "string"},
                        "username": {"type": "string"},
                        "password": {"type": "string"},
                        "api_token": {"type": "string"},
                        "project_key": {"type": "string"}
                    },
                    "required": ["project_key"],
                    "additionalProperties": True
                },
                "bug_template": {
                    "type": "object",
                    "properties": {
                        "issue_type": {"type": "string"},
                        "priority": {"type": "string"},
                        "product": {"type": "string"},
                        "environment": {"type": "string"},
                        "reproducible": {"type": "boolean"},
                        "default_assignee": {"type": "string"},
                        "default_reporter": {"type": "string"},
                        "components": {
                            "type": "array",
                            "items": {"type": "string"}
                        },
                        "labels": {
                            "type": "array", 
                            "items": {"type": "string"}
                        },
                        "custom_fields": {"type": "object"},
                        "additional_notes": {"type": "string"}
                    },
                    "additionalProperties": True
                }
            },
            "required": ["jira", "bug_template"],
            "additionalProperties": True
        }
        
        self.logger.info(f"Configuration manager initialized for: {config_file_path}")
    
    def load_config(self) -> Dict[str, Any]:
        """
        Load and validate configuration from JSON file
        
        Returns:
            Configuration dictionary
            
        Raises:
            FileNotFoundError: If config file doesn't exist
            ValueError: If config is invalid
        """
        self.logger.info(f"Loading configuration from: {self.config_file_path}")
        
        # Check if file exists
        if not Path(self.config_file_path).exists():
            self.logger.error(f"Configuration file not found: {self.config_file_path}")
            raise FileNotFoundError(f"Configuration file not found: {self.config_file_path}")
        
        try:
            # Load JSON configuration
            with open(self.config_file_path, 'r', encoding='utf-8') as f:
                self.config = json.load(f)
            
            self.logger.debug(f"Raw configuration loaded: {json.dumps(self.config, indent=2)}")
            
            # Validate configuration against schema
            self._validate_config()
            
            # Process environment variable overrides
            self._process_environment_overrides()
            
            # Set default values
            self._set_default_values()
            
            self.logger.info("Configuration loaded and validated successfully")
            
            return self.config
            
        except json.JSONDecodeError as e:
            self.logger.error(f"Invalid JSON in configuration file: {str(e)}")
            raise ValueError(f"Invalid JSON in configuration file: {str(e)}")
        except Exception as e:
            self.logger.error(f"Error loading configuration: {str(e)}")
            raise
    
    def _validate_config(self) -> None:
        """
        Validate configuration against schema
        
        Raises:
            ValueError: If configuration is invalid
        """
        self.logger.debug("Validating configuration against schema...")
        
        try:
            validate(instance=self.config, schema=self.config_schema)
            self.logger.debug("Configuration schema validation passed")
        except jsonschema.exceptions.ValidationError as e:
            self.logger.error(f"Configuration validation failed: {str(e)}")
            raise ValueError(f"Configuration validation failed: {str(e)}")
    
    def _process_environment_overrides(self) -> None:
        """Process environment variable overrides for sensitive data"""
        self.logger.debug("Processing environment variable overrides...")
        
        # Override Jira configuration with environment variables
        jira_config = self.config.get('jira', {})
        
        env_overrides = {
            'url': 'JIRA_URL',
            'username': 'JIRA_USERNAME', 
            'password': 'JIRA_PASSWORD',
            'api_token': 'JIRA_API_TOKEN',
            'project_key': 'JIRA_PROJECT_KEY'
        }
        
        for config_key, env_var in env_overrides.items():
            env_value = os.getenv(env_var)
            if env_value:
                jira_config[config_key] = env_value
                self.logger.debug(f"Override {config_key} from environment variable {env_var}")
        
        self.config['jira'] = jira_config
    
    def _set_default_values(self) -> None:
        """Set default values for optional configuration items"""
        self.logger.debug("Setting default configuration values...")
        
        # Set default bug template values
        bug_template = self.config.get('bug_template', {})
        
        defaults = {
            'issue_type': 'Bug',
            'priority': 'Medium',
            'reproducible': True,
            'labels': [],
            'components': [],
            'custom_fields': {}
        }
        
        for key, default_value in defaults.items():
            if key not in bug_template:
                bug_template[key] = default_value
                self.logger.debug(f"Set default value for {key}: {default_value}")
        
        self.config['bug_template'] = bug_template
    
    def get_jira_config(self) -> Dict[str, Any]:
        """
        Get Jira-specific configuration
        
        Returns:
            Jira configuration dictionary
        """
        if not self.config:
            raise ValueError("Configuration not loaded. Call load_config() first.")
        
        return self.config.get('jira', {})
    
    def get_bug_template(self) -> Dict[str, Any]:
        """
        Get bug template configuration
        
        Returns:
            Bug template configuration dictionary
        """
        if not self.config:
            raise ValueError("Configuration not loaded. Call load_config() first.")
        
        return self.config.get('bug_template', {})
    
    def validate_jira_credentials(self) -> Dict[str, bool]:
        """
        Validate that required Jira credentials are available
        
        Returns:
            Dictionary indicating what credentials are available
        """
        if not self.config:
            raise ValueError("Configuration not loaded. Call load_config() first.")
        
        jira_config = self.get_jira_config()
        
        validation = {
            'has_url': bool(jira_config.get('url')),
            'has_username': bool(jira_config.get('username')),
            'has_password': bool(jira_config.get('password')),
            'has_api_token': bool(jira_config.get('api_token')),
            'has_project_key': bool(jira_config.get('project_key'))
        }
        
        validation['has_auth'] = validation['has_password'] or validation['has_api_token']
        validation['is_complete'] = (
            validation['has_url'] and 
            validation['has_username'] and 
            validation['has_auth'] and 
            validation['has_project_key']
        )
        
        self.logger.debug(f"Credential validation: {validation}")
        
        return validation
    
    def save_config(self, output_path: Optional[str] = None) -> None:
        """
        Save current configuration to file
        
        Args:
            output_path: Output file path (defaults to original config file)
        """
        if not self.config:
            raise ValueError("No configuration to save. Load configuration first.")
        
        output_file = output_path or self.config_file_path
        
        self.logger.info(f"Saving configuration to: {output_file}")
        
        try:
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=2, ensure_ascii=False)
            
            self.logger.info("Configuration saved successfully")
            
        except Exception as e:
            self.logger.error(f"Error saving configuration: {str(e)}")
            raise
    
    def get_config_summary(self) -> Dict[str, Any]:
        """
        Get a summary of the current configuration
        
        Returns:
            Configuration summary dictionary
        """
        if not self.config:
            return {"status": "not_loaded"}
        
        jira_config = self.get_jira_config()
        bug_template = self.get_bug_template()
        credentials = self.validate_jira_credentials()
        
        summary = {
            "status": "loaded",
            "jira": {
                "url": jira_config.get('url', 'Not set'),
                "username": jira_config.get('username', 'Not set'),
                "project_key": jira_config.get('project_key', 'Not set'),
                "has_credentials": credentials['is_complete']
            },
            "bug_template": {
                "issue_type": bug_template.get('issue_type'),
                "priority": bug_template.get('priority'),
                "product": bug_template.get('product', 'Not specified'),
                "components_count": len(bug_template.get('components', [])),
                "labels_count": len(bug_template.get('labels', [])),
                "custom_fields_count": len(bug_template.get('custom_fields', {}))
            }
        }
        
        return summary
