"""
Selenium-based Jira Authentication Module
Handles complex authentication scenarios including SAML, SSO, and corporate login
"""

import logging
import time
import json
import requests
from typing import Dict, Any, Optional, List
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from selenium.webdriver.common.keys import Keys
from webdriver_manager.chrome import ChromeDriverManager

class SeleniumJiraAuth:
    """Selenium-based Jira authentication handler"""
    
    def __init__(self, jira_config: Dict[str, Any], headless: bool = True):
        """
        Initialize Selenium Jira authentication
        
        Args:
            jira_config: Jira configuration dictionary
            headless: Run browser in headless mode
        """
        self.jira_config = jira_config
        self.jira_url = jira_config.get('url', '').rstrip('/')
        self.username = jira_config.get('username', '')
        self.password = jira_config.get('password', '')
        self.headless = headless
        self.driver = None
        self.session_cookies = None
        self.logger = logging.getLogger(__name__)
        
    def setup_driver(self) -> webdriver.Chrome:
        """Setup Chrome WebDriver with appropriate options"""
        chrome_options = Options()
        
        if self.headless:
            chrome_options.add_argument('--headless')
        
        # Add options for corporate environments
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        chrome_options.add_argument('--disable-blink-features=AutomationControlled')
        chrome_options.add_argument('--disable-extensions')
        chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument('--remote-debugging-port=9222')
        chrome_options.add_argument('--disable-web-security')
        chrome_options.add_argument('--allow-running-insecure-content')
        chrome_options.add_argument('--ignore-certificate-errors')
        chrome_options.add_argument('--ignore-ssl-errors')
        chrome_options.add_argument('--ignore-certificate-errors-spki-list')
        
        # Set user agent to avoid detection
        chrome_options.add_argument('--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
        
        # Create driver with automatic driver management
        try:
            service = Service(ChromeDriverManager().install())
            self.driver = webdriver.Chrome(service=service, options=chrome_options)
            self.driver.set_page_load_timeout(30)
            return self.driver
        except Exception as e:
            self.logger.error(f"Failed to setup Chrome driver: {e}")
            raise
    
    def authenticate(self) -> bool:
        """
        Perform authentication using Selenium
        
        Returns:
            True if authentication successful, False otherwise
        """
        try:
            self.logger.info("Starting Selenium-based Jira authentication")
            
            # Setup driver
            self.setup_driver()
            
            # Navigate to Jira
            login_url = f"{self.jira_url}/login.jsp"
            self.logger.info(f"Navigating to: {login_url}")
            self.driver.get(login_url)
            
            # Wait for page to load
            time.sleep(3)
            
            # Check if we're redirected to SAML/SSO
            current_url = self.driver.current_url
            self.logger.info(f"Current URL after navigation: {current_url}")
            
            if "saml" in current_url.lower() or "sso" in current_url.lower():
                return self._handle_saml_login()
            elif "atlassian" in current_url:
                return self._handle_atlassian_login()
            else:
                return self._handle_standard_login()
                
        except Exception as e:
            self.logger.error(f"Authentication failed: {e}")
            return False
        finally:
            if self.driver:
                # Extract cookies before closing
                self._extract_session_cookies()
    
    def _handle_saml_login(self) -> bool:
        """Handle SAML/SSO authentication flow"""
        self.logger.info("Detected SAML/SSO authentication flow")
        
        try:
            # Wait for login form
            wait = WebDriverWait(self.driver, 15)
            
            # Try different common username field selectors
            username_selectors = [
                'input[name="username"]',
                'input[name="email"]',
                'input[name="UserName"]',
                'input[name="user"]',
                'input[type="email"]',
                'input[id*="username"]',
                'input[id*="email"]',
                'input[id*="user"]'
            ]
            
            username_field = None
            for selector in username_selectors:
                try:
                    username_field = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, selector)))
                    break
                except TimeoutException:
                    continue
            
            if not username_field:
                self.logger.error("Could not find username field")
                return False
            
            # Enter username
            username_field.clear()
            username_field.send_keys(self.username)
            self.logger.info("Username entered")
            
            # Try to find password field
            password_selectors = [
                'input[name="password"]',
                'input[name="Password"]',
                'input[type="password"]',
                'input[id*="password"]',
                'input[id*="pass"]'
            ]
            
            password_field = None
            for selector in password_selectors:
                try:
                    password_field = self.driver.find_element(By.CSS_SELECTOR, selector)
                    break
                except NoSuchElementException:
                    continue
            
            if password_field:
                password_field.clear()
                password_field.send_keys(self.password)
                self.logger.info("Password entered")
            
            # Find and click submit button
            submit_selectors = [
                'input[type="submit"]',
                'button[type="submit"]',
                'input[value*="Sign"]',
                'input[value*="Login"]',
                'button[name="submit"]',
                'button:contains("Sign")',
                'button:contains("Login")',
                '.btn-primary',
                '.login-button'
            ]
            
            submit_button = None
            for selector in submit_selectors:
                try:
                    if ':contains(' in selector:
                        # Use XPath for text-based selection
                        text_part = selector.split('(')[1].split(')')[0].strip('"')
                        xpath = f"//button[contains(text(), '{text_part}')]"
                        submit_button = self.driver.find_element(By.XPATH, xpath)
                    else:
                        submit_button = self.driver.find_element(By.CSS_SELECTOR, selector)
                    break
                except NoSuchElementException:
                    continue
            
            if submit_button:
                submit_button.click()
                self.logger.info("Submit button clicked")
            else:
                # Try pressing Enter on password field
                if password_field:
                    password_field.send_keys(Keys.RETURN)
                else:
                    username_field.send_keys(Keys.RETURN)
                self.logger.info("Submitted via Enter key")
            
            # Wait for redirect or dashboard
            time.sleep(5)
            
            # Check if we're now authenticated
            current_url = self.driver.current_url
            if "dashboard" in current_url or "secure" in current_url or self.jira_url in current_url:
                self.logger.info("SAML authentication successful")
                return True
            else:
                self.logger.warning(f"Authentication may have failed. Current URL: {current_url}")
                return False
                
        except Exception as e:
            self.logger.error(f"SAML authentication error: {e}")
            return False
    
    def _handle_atlassian_login(self) -> bool:
        """Handle Atlassian Cloud login"""
        self.logger.info("Detected Atlassian Cloud login")
        
        try:
            wait = WebDriverWait(self.driver, 10)
            
            # Enter username
            username_field = wait.until(EC.presence_of_element_located((By.ID, "username")))
            username_field.clear()
            username_field.send_keys(self.username)
            
            # Click continue
            continue_button = wait.until(EC.element_to_be_clickable((By.ID, "login-submit")))
            continue_button.click()
            
            # Enter password
            password_field = wait.until(EC.presence_of_element_located((By.ID, "password")))
            password_field.clear()
            password_field.send_keys(self.password)
            
            # Click login
            login_button = wait.until(EC.element_to_be_clickable((By.ID, "login-submit")))
            login_button.click()
            
            # Wait for redirect
            time.sleep(5)
            
            current_url = self.driver.current_url
            if self.jira_url in current_url:
                self.logger.info("Atlassian authentication successful")
                return True
            else:
                self.logger.warning(f"Authentication may have failed. Current URL: {current_url}")
                return False
                
        except Exception as e:
            self.logger.error(f"Atlassian authentication error: {e}")
            return False
    
    def _handle_standard_login(self) -> bool:
        """Handle standard Jira login"""
        self.logger.info("Attempting standard Jira login")
        
        try:
            wait = WebDriverWait(self.driver, 10)
            
            # Find and fill username
            username_field = wait.until(EC.presence_of_element_located((By.ID, "login-form-username")))
            username_field.clear()
            username_field.send_keys(self.username)
            
            # Find and fill password
            password_field = wait.until(EC.presence_of_element_located((By.ID, "login-form-password")))
            password_field.clear()
            password_field.send_keys(self.password)
            
            # Submit form
            login_button = wait.until(EC.element_to_be_clickable((By.ID, "login-form-submit")))
            login_button.click()
            
            # Wait for redirect
            time.sleep(5)
            
            current_url = self.driver.current_url
            if "dashboard" in current_url or self.jira_url in current_url:
                self.logger.info("Standard authentication successful")
                return True
            else:
                self.logger.warning(f"Authentication may have failed. Current URL: {current_url}")
                return False
                
        except Exception as e:
            self.logger.error(f"Standard authentication error: {e}")
            return False
    
    def _extract_session_cookies(self):
        """Extract session cookies for API calls"""
        if self.driver:
            try:
                cookies = self.driver.get_cookies()
                self.session_cookies = {cookie['name']: cookie['value'] for cookie in cookies}
                self.logger.info(f"Extracted {len(self.session_cookies)} cookies")
            except Exception as e:
                self.logger.error(f"Failed to extract cookies: {e}")
    
    def get_authenticated_session(self) -> requests.Session:
        """
        Get a requests session with authentication cookies
        
        Returns:
            Authenticated requests session
        """
        session = requests.Session()
        
        if self.session_cookies:
            for name, value in self.session_cookies.items():
                session.cookies.set(name, value)
        
        # Set headers
        session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        })
        
        # Handle SSL verification
        session.verify = self.jira_config.get('verify_ssl', True)
        
        return session
    
    def test_api_access(self) -> bool:
        """
        Test API access using authenticated session
        
        Returns:
            True if API access successful, False otherwise
        """
        try:
            session = self.get_authenticated_session()
            
            # Test with /rest/api/2/myself endpoint
            api_url = f"{self.jira_url}/rest/api/2/myself"
            response = session.get(api_url)
            
            if response.status_code == 200:
                user_info = response.json()
                self.logger.info(f"API access successful. User: {user_info.get('displayName', 'Unknown')}")
                return True
            else:
                self.logger.error(f"API access failed. Status: {response.status_code}")
                return False
                
        except Exception as e:
            self.logger.error(f"API test failed: {e}")
            return False
    
    def cleanup(self):
        """Clean up resources"""
        if self.driver:
            try:
                self.driver.quit()
            except Exception as e:
                self.logger.error(f"Error closing driver: {e}")


class SeleniumJiraIntegrator:
    """Jira integrator using Selenium authentication"""
    
    def __init__(self, jira_config: Dict[str, Any]):
        """Initialize Selenium-based Jira integrator"""
        self.jira_config = jira_config
        self.jira_url = jira_config.get('url', '').rstrip('/')
        self.auth_handler = SeleniumJiraAuth(jira_config)
        self.session = None
        self.logger = logging.getLogger(__name__)
        
    def authenticate(self) -> bool:
        """Authenticate and setup session"""
        try:
            if self.auth_handler.authenticate():
                self.session = self.auth_handler.get_authenticated_session()
                return self.auth_handler.test_api_access()
            return False
        finally:
            self.auth_handler.cleanup()
    
    def create_issue(self, issue_data: Dict[str, Any]) -> Optional[str]:
        """Create a Jira issue"""
        if not self.session:
            self.logger.error("Not authenticated. Call authenticate() first.")
            return None
            
        try:
            url = f"{self.jira_url}/rest/api/2/issue"
            response = self.session.post(url, json=issue_data)
            
            if response.status_code == 201:
                result = response.json()
                issue_key = result.get('key')
                self.logger.info(f"Issue created successfully: {issue_key}")
                return issue_key
            else:
                self.logger.error(f"Failed to create issue. Status: {response.status_code}")
                self.logger.error(f"Response: {response.text}")
                return None
                
        except Exception as e:
            self.logger.error(f"Error creating issue: {e}")
            return None
    
    def search_issues(self, jql: str, fields: Optional[List[str]] = None, max_results: int = 1000) -> List[Dict[str, Any]]:
        """Search for issues using JQL"""
        if not self.session:
            self.logger.error("Not authenticated. Call authenticate() first.")
            return []
            
        try:
            url = f"{self.jira_url}/rest/api/2/search"
            params = {
                'jql': jql,
                'maxResults': max_results
            }
            
            if fields:
                params['fields'] = ','.join(fields)
            
            response = self.session.get(url, params=params)
            
            if response.status_code == 200:
                result = response.json()
                return result.get('issues', [])
            else:
                self.logger.error(f"Search failed. Status: {response.status_code}")
                return []
                
        except Exception as e:
            self.logger.error(f"Error searching issues: {e}")
            return []
    
    def get_project_info(self, project_key: str) -> Optional[Dict[str, Any]]:
        """Get project information"""
        if not self.session:
            self.logger.error("Not authenticated. Call authenticate() first.")
            return None
            
        try:
            url = f"{self.jira_url}/rest/api/2/project/{project_key}"
            response = self.session.get(url)
            
            if response.status_code == 200:
                return response.json()
            else:
                self.logger.error(f"Failed to get project info. Status: {response.status_code}")
                return None
                
        except Exception as e:
            self.logger.error(f"Error getting project info: {e}")
            return None