"""
Automated Jira Export and Comparison System
Automatically fetches existing QC bugs from Jira and compares with input CSV
"""

import json
import csv
import logging
import requests
import pandas as pd
from typing import Dict, Any, List, Set, Optional
from datetime import datetime
import urllib3
from requests.auth import HTTPBasicAuth
import base64

# Disable SSL warnings for corporate environments
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class AutomatedJiraExporter:
    """Automatically fetches and compares QC bugs from Jira"""
    
    def __init__(self, jira_config: Dict[str, Any]):
        """Initialize with Jira configuration"""
        self.jira_config = jira_config
        self.jira_url = jira_config.get('url', '').rstrip('/')
        self.project_key = jira_config.get('project_key', '16400')
        self.username = jira_config.get('username', '')
        self.password = jira_config.get('password', '')
        self.api_token = jira_config.get('api_token', '')
        
        self.logger = logging.getLogger(__name__)
        
        # Setup session with authentication
        self.session = requests.Session()
        self._setup_authentication()
        
        # Your corporate Jira API endpoint
        self.api_url = f"{self.jira_url}/rest/api/2/search"
        self.jql_query = f'project={self.project_key} AND issuetype=Bug AND summary ~ "QC ID#"'
        
    def _setup_authentication(self):
        """Setup authentication for Jira API"""
        self.session.verify = False  # For corporate SSL certificates
        
        # Try different authentication methods
        if self.api_token:
            # API Token authentication (recommended)
            self.session.auth = HTTPBasicAuth(self.username, self.api_token)
            self.logger.info("Using API token authentication")
        elif self.username and self.password:
            # Basic authentication
            self.session.auth = HTTPBasicAuth(self.username, self.password)
            self.logger.info("Using basic authentication")
        else:
            self.logger.warning("No authentication credentials provided")
    
    def fetch_existing_qc_bugs(self) -> List[Dict[str, Any]]:
        """Automatically fetch existing QC bugs from Jira"""
        existing_bugs = []
        
        try:
            # Parameters for Jira API
            params = {
                'jql': self.jql_query,
                'fields': 'key,summary,status,assignee,created,description,priority',
                'maxResults': 1000,
                'startAt': 0
            }
            
            self.logger.info(f"Fetching QC bugs from: {self.api_url}")
            self.logger.info(f"JQL Query: {self.jql_query}")
            
            # Make API request
            response = self.session.get(self.api_url, params=params, timeout=30)
            
            if response.status_code == 200:
                data = response.json()
                issues = data.get('issues', [])
                
                self.logger.info(f"Found {len(issues)} QC bugs in Jira")
                
                for issue in issues:
                    try:
                        fields = issue.get('fields', {})
                        summary = fields.get('summary', '')
                        
                        # Extract QC number from summary
                        import re
                        qc_match = re.search(r'QC\s*ID#?\s*(\d+)', summary, re.IGNORECASE)
                        qc_number = qc_match.group(1) if qc_match else ''
                        
                        # Get status
                        status = fields.get('status', {})
                        status_name = status.get('name', 'Unknown') if status else 'Unknown'
                        
                        # Get assignee
                        assignee = fields.get('assignee', {})
                        assignee_name = assignee.get('displayName', 'Unassigned') if assignee else 'Unassigned'
                        
                        # Get priority
                        priority = fields.get('priority', {})
                        priority_name = priority.get('name', 'Unknown') if priority else 'Unknown'
                        
                        bug_info = {
                            'key': issue.get('key', ''),
                            'qc_number': qc_number,
                            'summary': summary,
                            'status': status_name,
                            'assignee': assignee_name,
                            'priority': priority_name,
                            'created': fields.get('created', ''),
                            'description': fields.get('description', '')
                        }
                        
                        existing_bugs.append(bug_info)
                        
                    except Exception as e:
                        self.logger.warning(f"Error processing issue {issue.get('key', 'unknown')}: {e}")
                        
            else:
                self.logger.error(f"Failed to fetch bugs from Jira. Status: {response.status_code}")
                self.logger.error(f"Response: {response.text}")
                
                # Try alternative authentication if first attempt fails
                if response.status_code == 401:
                    self.logger.info("Trying alternative authentication methods...")
                    return self._try_alternative_auth()
                
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Network error connecting to Jira: {e}")
        except Exception as e:
            self.logger.error(f"Unexpected error fetching QC bugs: {e}")
            
        return existing_bugs
    
    def _try_alternative_auth(self) -> List[Dict[str, Any]]:
        """Try alternative authentication methods"""
        existing_bugs = []
        
        # Try with different headers and session setup
        alternative_session = requests.Session()
        alternative_session.verify = False
        
        # Add common headers for corporate Jira
        alternative_session.headers.update({
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'User-Agent': 'Python Jira Integration Tool',
            'X-Atlassian-Token': 'no-check'
        })
        
        # Try different authentication approaches
        auth_methods = []
        
        if self.username and self.password:
            # Method 1: Basic Auth
            auth_methods.append(('Basic Auth', HTTPBasicAuth(self.username, self.password)))
            
            # Method 2: Manual Basic Auth header
            credentials = base64.b64encode(f"{self.username}:{self.password}".encode()).decode()
            auth_methods.append(('Manual Basic', None, {'Authorization': f'Basic {credentials}'}))
        
        for method_name, auth, extra_headers in auth_methods:
            try:
                self.logger.info(f"Trying {method_name} authentication...")
                
                session = requests.Session()
                session.verify = False
                session.headers.update(alternative_session.headers)
                
                if auth:
                    session.auth = auth
                if extra_headers:
                    session.headers.update(extra_headers)
                
                params = {
                    'jql': self.jql_query,
                    'fields': 'key,summary,status,assignee,created',
                    'maxResults': 10,  # Smaller request for testing
                    'startAt': 0
                }
                
                response = session.get(self.api_url, params=params, timeout=15)
                
                if response.status_code == 200:
                    self.logger.info(f"{method_name} authentication successful!")
                    # Now fetch full data with this method
                    self.session = session
                    return self.fetch_existing_qc_bugs()
                else:
                    self.logger.warning(f"{method_name} failed: {response.status_code}")
                    
            except Exception as e:
                self.logger.warning(f"{method_name} error: {e}")
                continue
        
        return existing_bugs
    
    def compare_with_input_csv(self, csv_path: str, existing_bugs: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Compare input CSV with existing QC bugs"""
        
        # Load input CSV
        input_bugs = []
        try:
            df = pd.read_csv(csv_path)
            input_bugs = df.to_dict('records')
            self.logger.info(f"Loaded {len(input_bugs)} bugs from input CSV")
        except Exception as e:
            self.logger.error(f"Error loading input CSV: {e}")
            return {}
        
        # Extract existing QC numbers
        existing_qc_numbers = set()
        for bug in existing_bugs:
            qc_num = str(bug.get('qc_number', '')).strip()
            if qc_num:
                existing_qc_numbers.add(qc_num)
        
        # Compare with input
        new_bugs = []
        duplicate_bugs = []
        
        for input_bug in input_bugs:
            # Try different column names for QC number
            qc_number = (input_bug.get('qc_number') or 
                        input_bug.get('bug_number') or 
                        input_bug.get('QC_Number') or 
                        input_bug.get('Bug_Number') or '')
            
            # Clean QC number (remove non-digits)
            clean_qc = str(qc_number).replace('QC', '').replace('-', '').strip()
            
            if clean_qc in existing_qc_numbers:
                duplicate_bugs.append(input_bug)
            else:
                new_bugs.append(input_bug)
        
        comparison_result = {
            'existing_bugs': existing_bugs,
            'new_bugs': new_bugs,
            'duplicate_bugs': duplicate_bugs,
            'existing_count': len(existing_bugs),
            'new_count': len(new_bugs),
            'duplicate_count': len(duplicate_bugs),
            'input_total': len(input_bugs)
        }
        
        self.logger.info(f"Comparison complete: {len(existing_bugs)} existing, {len(new_bugs)} new, {len(duplicate_bugs)} duplicates")
        
        return comparison_result
    
    def create_automated_report(self, comparison_result: Dict[str, Any], output_file: str = 'automated_jira_comparison.html') -> str:
        """Create automated HTML report with comparison results"""
        
        existing_bugs = comparison_result.get('existing_bugs', [])
        new_bugs = comparison_result.get('new_bugs', [])
        duplicate_bugs = comparison_result.get('duplicate_bugs', [])
        
        html_content = f"""
<!DOCTYPE html>
<html>
<head>
    <title>Automated Jira QC Bug Comparison</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; background-color: #f5f5f5; }}
        .header {{ background-color: #0052cc; color: white; padding: 20px; border-radius: 5px; margin-bottom: 20px; }}
        .stats {{ display: flex; gap: 20px; margin: 20px 0; }}
        .stat-card {{ background: white; padding: 20px; border-radius: 5px; flex: 1; text-align: center; border: 1px solid #ddd; }}
        .stat-number {{ font-size: 2em; font-weight: bold; color: #0052cc; }}
        .section {{ background-color: white; padding: 20px; margin: 20px 0; border-radius: 5px; border: 1px solid #ddd; }}
        .table {{ width: 100%; border-collapse: collapse; margin: 10px 0; }}
        .table th, .table td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
        .table th {{ background-color: #f8f9fa; }}
        .new {{ background-color: #d4edda; }}
        .duplicate {{ background-color: #f8d7da; }}
        .existing {{ background-color: #e2e3e5; }}
        .tab-container {{ margin: 20px 0; }}
        .tab {{ display: inline-block; padding: 10px 20px; margin: 0 5px 0 0; background: #f8f9fa; border: 1px solid #ddd; cursor: pointer; border-radius: 5px 5px 0 0; }}
        .tab.active {{ background: #0052cc; color: white; }}
        .tab-content {{ display: none; padding: 20px; background: white; border: 1px solid #ddd; border-radius: 0 5px 5px 5px; }}
        .tab-content.active {{ display: block; }}
        .timestamp {{ color: #666; font-size: 0.9em; }}
    </style>
    <script>
        function showTab(tabName) {{
            // Hide all tab contents
            var contents = document.getElementsByClassName('tab-content');
            for (var i = 0; i < contents.length; i++) {{
                contents[i].classList.remove('active');
            }}
            
            // Remove active class from all tabs
            var tabs = document.getElementsByClassName('tab');
            for (var i = 0; i < tabs.length; i++) {{
                tabs[i].classList.remove('active');
            }}
            
            // Show selected tab content and mark tab as active
            document.getElementById(tabName + '-content').classList.add('active');
            document.getElementById(tabName + '-tab').classList.add('active');
        }}
    </script>
</head>
<body>
    <div class="header">
        <h1>🤖 Automated Jira QC Bug Comparison</h1>
        <p>Project: {self.project_key} | Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
        <p class="timestamp">✅ Data automatically fetched from Jira</p>
    </div>
    
    <div class="stats">
        <div class="stat-card existing">
            <div class="stat-number">{len(existing_bugs)}</div>
            <div>Existing QC Bugs</div>
        </div>
        <div class="stat-card new">
            <div class="stat-number">{len(new_bugs)}</div>
            <div>New Bugs to Create</div>
        </div>
        <div class="stat-card duplicate">
            <div class="stat-number">{len(duplicate_bugs)}</div>
            <div>Duplicates to Skip</div>
        </div>
    </div>
    
    <div class="tab-container">
        <div class="tab active" id="existing-tab" onclick="showTab('existing')">
            📋 Existing QC Bugs ({len(existing_bugs)})
        </div>
        <div class="tab" id="new-tab" onclick="showTab('new')">
            ✅ New Bugs ({len(new_bugs)})
        </div>
        <div class="tab" id="duplicates-tab" onclick="showTab('duplicates')">
            ⚠️ Duplicates ({len(duplicate_bugs)})
        </div>
    </div>
    
    <div id="existing-content" class="tab-content active">
        <h3>Existing QC Bugs in Jira</h3>
        <table class="table">
            <thead>
                <tr>
                    <th>QC#</th>
                    <th>Jira Key</th>
                    <th>Summary</th>
                    <th>Status</th>
                    <th>Assignee</th>
                    <th>Priority</th>
                </tr>
            </thead>
            <tbody>
"""

        # Add existing bugs to table
        for bug in existing_bugs:
            html_content += f"""
                <tr>
                    <td><strong>{bug.get('qc_number', '')}</strong></td>
                    <td><a href="{self.jira_url}/browse/{bug.get('key', '')}" target="_blank">{bug.get('key', '')}</a></td>
                    <td>{bug.get('summary', '')}</td>
                    <td>{bug.get('status', '')}</td>
                    <td>{bug.get('assignee', '')}</td>
                    <td>{bug.get('priority', '')}</td>
                </tr>
"""

        html_content += """
            </tbody>
        </table>
    </div>
    
    <div id="new-content" class="tab-content">
        <h3>New QC Bugs to Create</h3>
        <p class="new">✅ These bugs don't exist in Jira yet - safe to create</p>
        <table class="table">
            <thead>
                <tr>
                    <th>QC#</th>
                    <th>Summary</th>
                    <th>Details</th>
                </tr>
            </thead>
            <tbody>
"""

        # Add new bugs to table
        for bug in new_bugs:
            qc_num = (bug.get('qc_number') or bug.get('bug_number') or bug.get('QC_Number') or bug.get('Bug_Number') or '')
            summary = (bug.get('summary') or bug.get('bug_summery') or bug.get('Summary') or '')
            
            # Show other details
            other_details = []
            for key, value in bug.items():
                if key.lower() not in ['qc_number', 'bug_number', 'summary', 'bug_summery'] and value:
                    other_details.append(f"{key}: {value}")
            
            html_content += f"""
                <tr class="new">
                    <td><strong>{qc_num}</strong></td>
                    <td>{summary}</td>
                    <td>{' | '.join(other_details[:3])}...</td>
                </tr>
"""

        html_content += """
            </tbody>
        </table>
    </div>
    
    <div id="duplicates-content" class="tab-content">
        <h3>Duplicate QC Bugs (Skip These)</h3>
        <p class="duplicate">⚠️ These bugs already exist in Jira - do not create</p>
        <table class="table">
            <thead>
                <tr>
                    <th>QC#</th>
                    <th>Summary</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
"""

        # Add duplicate bugs to table
        for bug in duplicate_bugs:
            qc_num = (bug.get('qc_number') or bug.get('bug_number') or bug.get('QC_Number') or bug.get('Bug_Number') or '')
            summary = (bug.get('summary') or bug.get('bug_summery') or bug.get('Summary') or '')
            
            html_content += f"""
                <tr class="duplicate">
                    <td><strong>{qc_num}</strong></td>
                    <td>{summary}</td>
                    <td>Already exists in Jira</td>
                </tr>
"""

        html_content += f"""
            </tbody>
        </table>
    </div>
    
    <div class="section">
        <h3>Summary</h3>
        <ul>
            <li><strong>Total input bugs:</strong> {comparison_result.get('input_total', 0)}</li>
            <li><strong>Existing in Jira:</strong> {len(existing_bugs)}</li>
            <li><strong>New bugs to create:</strong> {len(new_bugs)}</li>
            <li><strong>Duplicates to skip:</strong> {len(duplicate_bugs)}</li>
        </ul>
        <p><strong>Jira URL:</strong> <a href="{self.jira_url}" target="_blank">{self.jira_url}</a></p>
        <p><strong>JQL Query:</strong> <code>{self.jql_query}</code></p>
    </div>
</body>
</html>
"""

        # Write to file
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        self.logger.info(f"Automated report created: {output_file}")
        return output_file


def run_automated_export(csv_file: str, config_file: str) -> Dict[str, Any]:
    """Run fully automated export and comparison"""
    
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s | %(levelname)s | %(message)s',
        handlers=[
            logging.FileHandler('automated_jira_export.log'),
            logging.StreamHandler()
        ]
    )
    logger = logging.getLogger(__name__)
    
    logger.info("🚀 Starting automated Jira export and comparison...")
    
    try:
        # Load configuration
        with open(config_file, 'r') as f:
            config = json.load(f)
        
        # Create exporter
        exporter = AutomatedJiraExporter(config['jira'])
        
        # Step 1: Fetch existing QC bugs from Jira
        logger.info("📡 Fetching existing QC bugs from Jira...")
        existing_bugs = exporter.fetch_existing_qc_bugs()
        
        if not existing_bugs:
            logger.warning("⚠️ No existing QC bugs found or unable to connect to Jira")
            return {'success': False, 'error': 'No bugs found or connection failed'}
        
        # Step 2: Compare with input CSV
        logger.info("🔍 Comparing with input CSV...")
        comparison_result = exporter.compare_with_input_csv(csv_file, existing_bugs)
        
        # Step 3: Create automated report
        logger.info("📊 Creating automated report...")
        report_file = exporter.create_automated_report(comparison_result)
        
        logger.info("✅ Automated export and comparison completed successfully!")
        
        return {
            'success': True,
            'report_file': report_file,
            'existing_count': len(existing_bugs),
            'new_count': len(comparison_result.get('new_bugs', [])),
            'duplicate_count': len(comparison_result.get('duplicate_bugs', [])),
            'comparison_result': comparison_result
        }
        
    except Exception as e:
        logger.error(f"❌ Error in automated export: {e}")
        return {'success': False, 'error': str(e)}


if __name__ == "__main__":
    # Run automated export
    result = run_automated_export(
        'sample_data/bugs_input.csv',
        'config/your_corporate_jira_config.json'
    )
    
    if result['success']:
        print(f"✅ SUCCESS! Report created: {result['report_file']}")
        print(f"📊 Results: {result['existing_count']} existing, {result['new_count']} new, {result['duplicate_count']} duplicates")
    else:
        print(f"❌ FAILED: {result['error']}")