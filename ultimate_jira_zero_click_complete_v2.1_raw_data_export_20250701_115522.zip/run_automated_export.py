#!/usr/bin/env python3
"""
Run Automated Jira Export with Environment Variables
"""

import os
import json
from automated_jira_export import run_automated_export

def main():
    # Load configuration and update with environment variables
    config_file = 'config/your_corporate_jira_config.json'
    
    with open(config_file, 'r') as f:
        config = json.load(f)
    
    # Update with environment variables
    config['jira']['username'] = os.environ.get('JIRA_USERNAME', '')
    config['jira']['password'] = os.environ.get('JIRA_PASSWORD', '')
    
    # Save updated config temporarily
    temp_config_file = 'config/temp_jira_config.json'
    with open(temp_config_file, 'w') as f:
        json.dump(config, f, indent=2)
    
    print("🚀 Starting automated Jira export with your credentials...")
    print(f"📡 Connecting to: {config['jira']['url']}")
    print(f"👤 Username: {config['jira']['username']}")
    print(f"🗂️  Project: {config['jira']['project_key']}")
    
    # Run automated export
    result = run_automated_export(
        'sample_data/bugs_input.csv',
        temp_config_file
    )
    
    # Clean up temp file
    os.remove(temp_config_file)
    
    if result['success']:
        print(f"\n✅ SUCCESS!")
        print(f"📊 Results:")
        print(f"   - Existing QC bugs in Jira: {result['existing_count']}")
        print(f"   - New bugs to create: {result['new_count']}")
        print(f"   - Duplicates to skip: {result['duplicate_count']}")
        print(f"📄 Report created: {result['report_file']}")
        print(f"\n🎯 Open '{result['report_file']}' to see the full comparison!")
    else:
        print(f"\n❌ FAILED: {result['error']}")
        print("Check the log file 'automated_jira_export.log' for details")

if __name__ == "__main__":
    main()