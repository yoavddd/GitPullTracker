"""
Logging Setup Module
Configures comprehensive logging for the Jira integration system
"""

import logging
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional


def setup_logger(log_level: str = 'INFO', log_file: Optional[str] = None, logger_name: str = 'jira_integration') -> logging.Logger:
    """
    Setup comprehensive logging configuration
    
    Args:
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR)
        log_file: Optional log file path
        logger_name: Name for the logger
        
    Returns:
        Configured logger instance
    """
    # Create logger
    logger = logging.getLogger(logger_name)
    
    # Avoid duplicate handlers if logger already exists
    if logger.handlers:
        return logger
    
    # Set logging level
    numeric_level = getattr(logging, log_level.upper(), logging.INFO)
    logger.setLevel(numeric_level)
    
    # Create formatters
    detailed_formatter = logging.Formatter(
        fmt='%(asctime)s | %(levelname)-8s | %(name)s:%(lineno)d | %(funcName)s() | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    simple_formatter = logging.Formatter(
        fmt='%(asctime)s | %(levelname)-8s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(numeric_level)
    
    # Use simple format for INFO and above, detailed for DEBUG
    if numeric_level <= logging.DEBUG:
        console_handler.setFormatter(detailed_formatter)
    else:
        console_handler.setFormatter(simple_formatter)
    
    logger.addHandler(console_handler)
    
    # File handler if log file specified
    if log_file:
        try:
            # Ensure log directory exists
            log_path = Path(log_file)
            log_path.parent.mkdir(parents=True, exist_ok=True)
            
            file_handler = logging.FileHandler(log_file, encoding='utf-8')
            file_handler.setLevel(logging.DEBUG)  # Always log debug to file
            file_handler.setFormatter(detailed_formatter)
            
            logger.addHandler(file_handler)
            
            # Log initial message to file
            logger.info(f"Logging initialized - File: {log_file}, Level: {log_level}")
            
        except Exception as e:
            logger.error(f"Failed to setup file logging: {str(e)}")
    
    # Add a null handler to prevent logging errors if no handlers are configured
    if not logger.handlers:
        logger.addHandler(logging.NullHandler())
    
    return logger


class LoggerMixin:
    """Mixin class to add logging capabilities to any class"""
    
    @property
    def logger(self) -> logging.Logger:
        """Get logger for the current class"""
        if not hasattr(self, '_logger'):
            self._logger = setup_logger(logger_name=f"{self.__class__.__module__}.{self.__class__.__name__}")
        return self._logger


def log_function_call(func):
    """
    Decorator to log function calls with parameters and return values
    
    Args:
        func: Function to decorate
        
    Returns:
        Decorated function
    """
    def wrapper(*args, **kwargs):
        logger = setup_logger()
        
        # Log function entry
        logger.debug(f"Calling {func.__name__} with args: {args}, kwargs: {kwargs}")
        
        try:
            # Call function
            result = func(*args, **kwargs)
            
            # Log successful completion
            logger.debug(f"{func.__name__} completed successfully")
            
            return result
            
        except Exception as e:
            # Log exception
            logger.error(f"{func.__name__} failed with error: {str(e)}")
            raise
    
    return wrapper


def log_performance(func):
    """
    Decorator to log function performance metrics
    
    Args:
        func: Function to decorate
        
    Returns:
        Decorated function
    """
    def wrapper(*args, **kwargs):
        logger = setup_logger()
        
        # Record start time
        start_time = datetime.now()
        logger.debug(f"Starting {func.__name__}")
        
        try:
            # Call function
            result = func(*args, **kwargs)
            
            # Calculate execution time
            end_time = datetime.now()
            execution_time = (end_time - start_time).total_seconds()
            
            # Log performance
            logger.info(f"{func.__name__} completed in {execution_time:.2f} seconds")
            
            return result
            
        except Exception as e:
            # Calculate execution time even for failures
            end_time = datetime.now()
            execution_time = (end_time - start_time).total_seconds()
            
            # Log failure with timing
            logger.error(f"{func.__name__} failed after {execution_time:.2f} seconds: {str(e)}")
            raise
    
    return wrapper


class StructuredLogger:
    """Structured logging helper for consistent log formatting"""
    
    def __init__(self, logger_name: str = 'structured'):
        self.logger = setup_logger(logger_name=logger_name)
    
    def log_operation_start(self, operation: str, details: dict = None):
        """Log the start of an operation"""
        message = f"OPERATION START: {operation}"
        if details:
            message += f" | Details: {details}"
        self.logger.info(message)
    
    def log_operation_success(self, operation: str, result: dict = None):
        """Log successful completion of an operation"""
        message = f"OPERATION SUCCESS: {operation}"
        if result:
            message += f" | Result: {result}"
        self.logger.info(message)
    
    def log_operation_failure(self, operation: str, error: str, details: dict = None):
        """Log failure of an operation"""
        message = f"OPERATION FAILED: {operation} | Error: {error}"
        if details:
            message += f" | Details: {details}"
        self.logger.error(message)
    
    def log_data_processing(self, action: str, count: int, details: dict = None):
        """Log data processing activities"""
        message = f"DATA PROCESSING: {action} | Count: {count}"
        if details:
            message += f" | Details: {details}"
        self.logger.info(message)
    
    def log_api_call(self, method: str, url: str, status_code: int = None, response_time: float = None):
        """Log API calls"""
        message = f"API CALL: {method} {url}"
        if status_code:
            message += f" | Status: {status_code}"
        if response_time:
            message += f" | Time: {response_time:.2f}s"
        self.logger.info(message)
    
    def log_validation_result(self, item: str, is_valid: bool, errors: list = None):
        """Log validation results"""
        status = "VALID" if is_valid else "INVALID"
        message = f"VALIDATION: {item} | Status: {status}"
        if errors:
            message += f" | Errors: {errors}"
        
        if is_valid:
            self.logger.info(message)
        else:
            self.logger.warning(message)
