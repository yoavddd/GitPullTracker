# Corporate Jira Setup Guide

This guide helps you set up the Jira Bug Integration System with corporate Jira instances that use self-signed SSL certificates.

## SSL Certificate Issues

Corporate Jira servers often use self-signed certificates, which cause SSL verification errors like:
```
SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: self signed certificate in certificate chain
```

## Solution

The system now supports disabling SSL verification for corporate environments.

### Configuration

1. **Use the corporate config file**: `config/corporate_jira_config.json`
2. **Set verify_ssl to false**:
   ```json
   {
     "jira": {
       "url": "https://jira.esl.corp.elbit.co.il",
       "username": "your-username",
       "api_token": "your-token",
       "project_key": "YOUR_PROJECT",
       "verify_ssl": false
     }
   }
   ```

### For Elbit Corporate Environment

Your Jira URL is: `https://jira.esl.corp.elbit.co.il`

1. **Get your credentials from your IT department**:
   - Username (might be your employee ID or email)
   - API token or password
   - Project key where you want to create bugs

2. **Update the corporate config file**:
   ```json
   {
     "jira": {
       "url": "https://jira.esl.corp.elbit.co.il",
       "username": "your-actual-username",
       "api_token": "your-actual-token",
       "project_key": "YOUR_ACTUAL_PROJECT",
       "verify_ssl": false
     }
   }
   ```

3. **Test your connection**:
   ```bash
   # Edit test_credentials.py with your details first
   python test_credentials.py
   ```

4. **Run the system**:
   ```bash
   python main.py --csv sample_data/bugs_input.csv --config config/corporate_jira_config.json --dry-run --test-mode
   ```

### Security Note

Setting `verify_ssl: false` disables SSL certificate verification. This is acceptable for internal corporate networks but should not be used for external or public Jira instances.

### Getting Corporate Jira Credentials

1. **Username**: Usually your employee ID, email, or Windows username
2. **API Token**: 
   - Ask your IT department for Jira API access
   - Or check if you can generate one at: `https://jira.esl.corp.elbit.co.il/secure/ViewProfile.jspa?selectedTab=com.atlassian.pats.pats-plugin:jira-user-personal-access-tokens`
3. **Project Key**: Ask your project manager or check existing Jira projects

### Troubleshooting

- **Authentication Error**: Check username/token with IT
- **Project Access Error**: Make sure you have permission to create bugs in the project
- **Network Error**: Verify VPN connection if working remotely
- **SSL Error**: Ensure `verify_ssl` is set to `false` in config

## SAML Authentication (Recommended for Corporate)

If your corporate Jira uses SAML/SSO authentication, use the SAML configuration:

### SAML Setup Steps

1. **Use SAML config**: `config/saml_jira_config.json`
2. **Configure SAML authentication**:
   ```json
   {
     "jira": {
       "url": "https://jira.esl.corp.elbit.co.il",
       "username": "your-corporate-username",
       "password": "your-corporate-password",
       "project_key": "YOUR_PROJECT",
       "verify_ssl": false,
       "use_saml": true
     }
   }
   ```

3. **Test SAML authentication**:
   ```bash
   # Edit test_saml_auth.py with your credentials first
   python test_saml_auth.py
   ```

4. **Run with SAML**:
   ```bash
   python main.py --csv sample_data/bugs_input.csv --config config/saml_jira_config.json --dry-run
   ```

### Testing Order

**For SAML Authentication (Recommended):**
1. Test SAML authentication: `python test_saml_auth.py`
2. Test in dry-run mode: `python main.py --csv sample_data/bugs_input.csv --config config/saml_jira_config.json --dry-run`
3. Create actual bugs: `python main.py --csv sample_data/bugs_input.csv --config config/saml_jira_config.json`

**For API Token Authentication:**
1. Test basic authentication: `python test_credentials.py`
2. Test in dry-run mode: `python main.py --csv sample_data/bugs_input.csv --config config/corporate_jira_config.json --dry-run`
3. Create actual bugs: `python main.py --csv sample_data/bugs_input.csv --config config/corporate_jira_config.json`