"""
Duplicate Detection Module
Handles checking for existing bugs in Jira to prevent duplicates
"""

from typing import List, Dict, Any, Set
import re

from jira_integration import JiraIntegrator
from logger_setup import setup_logger


class DuplicateChecker:
    """Handles duplicate detection for bug issues in Jira"""
    
    def __init__(self, jira_integrator: JiraIntegrator, test_mode: bool = False):
        """
        Initialize duplicate checker
        
        Args:
            jira_integrator: JiraIntegrator instance for API calls
            test_mode: If True, simulate responses without actual API calls
        """
        self.logger = setup_logger()
        self.jira = jira_integrator
        self.test_mode = test_mode
        self._existing_issues_cache = {}
        self._cache_populated = False
        
        if test_mode:
            self.logger.info("Duplicate checker initialized in TEST MODE")
            # Pre-populate cache with some test data for demonstration
            self._existing_issues_cache = {
                'PROJ-001': 'qc id qc001 - sample existing bug',
                'PROJ-002': 'qc id qc005 - another existing bug',
                'PROJ-003': 'some other bug without qc id'
            }
            self._cache_populated = True
        else:
            self.logger.info("Duplicate checker initialized")
    
    def is_duplicate(self, bug_number: str, project_key: str) -> bool:
        """
        Check if a bug already exists in Jira
        
        Args:
            bug_number: The bug number to check for
            project_key: Jira project key to search in
            
        Returns:
            True if duplicate exists, False otherwise
        """
        self.logger.debug(f"Checking for duplicate of bug number: {bug_number}")
        
        # Ensure cache is populated
        if not self._cache_populated:
            self._populate_cache(project_key)
        
        # Create search pattern for QC ID
        qc_pattern = f"QC ID {bug_number}"
        
        # Check in cache first
        if self._check_cache_for_duplicate(qc_pattern):
            self.logger.info(f"Duplicate found in cache for bug: {bug_number}")
            return True
        
        # If not found in cache, perform direct search as fallback
        return self._search_for_duplicate(qc_pattern, project_key)
    
    def _populate_cache(self, project_key: str) -> None:
        """
        Populate the cache with existing issues from the project
        
        Args:
            project_key: Jira project key
        """
        if self.test_mode:
            self.logger.info(f"TEST MODE: Simulating cache population for project: {project_key}")
            return
        
        self.logger.info(f"Populating duplicate check cache for project: {project_key}")
        
        try:
            # Get all issues from the project with only summary field
            issues = self.jira.get_project_issues(project_key, fields=['summary', 'key'])
            
            # Store summaries in cache
            for issue in issues:
                issue_key = issue.get('key', '')
                summary = issue.get('fields', {}).get('summary', '')
                
                if summary:
                    self._existing_issues_cache[issue_key] = summary.lower()
            
            self._cache_populated = True
            self.logger.info(f"Cache populated with {len(self._existing_issues_cache)} issues")
            
        except Exception as e:
            self.logger.error(f"Error populating cache: {str(e)}")
            # Continue without cache
            self._cache_populated = False
    
    def _check_cache_for_duplicate(self, qc_pattern: str) -> bool:
        """
        Check cache for duplicate pattern
        
        Args:
            qc_pattern: Pattern to search for (e.g., "QC ID 12345")
            
        Returns:
            True if duplicate found in cache, False otherwise
        """
        search_pattern = qc_pattern.lower()
        
        for issue_key, summary in self._existing_issues_cache.items():
            if search_pattern in summary:
                self.logger.debug(f"Found duplicate in cache - Issue: {issue_key}, Summary: {summary}")
                return True
        
        return False
    
    def _search_for_duplicate(self, qc_pattern: str, project_key: str) -> bool:
        """
        Search directly in Jira for duplicate pattern
        
        Args:
            qc_pattern: Pattern to search for
            project_key: Jira project key
            
        Returns:
            True if duplicate found, False otherwise
        """
        if self.test_mode:
            self.logger.debug(f"TEST MODE: Simulating search for pattern: {qc_pattern}")
            # Simulate finding no additional duplicates beyond cache
            return False
        
        self.logger.debug(f"Performing direct search for pattern: {qc_pattern}")
        
        try:
            # Escape special characters for JQL
            escaped_pattern = qc_pattern.replace('"', '\\"')
            
            # Create JQL query to search for the pattern in summary
            jql = f'project = "{project_key}" AND summary ~ "{escaped_pattern}"'
            
            # Search for issues
            issues = self.jira.search_issues(jql, fields=['summary', 'key'], max_results=10)
            
            if issues:
                self.logger.info(f"Found {len(issues)} potential duplicates")
                
                # Check each issue for exact pattern match
                for issue in issues:
                    summary = issue.get('fields', {}).get('summary', '')
                    issue_key = issue.get('key', '')
                    
                    if qc_pattern.lower() in summary.lower():
                        self.logger.info(f"Confirmed duplicate found - Issue: {issue_key}, Summary: {summary}")
                        return True
                
                self.logger.debug("No exact duplicates found in search results")
                return False
            else:
                self.logger.debug("No issues found matching search pattern")
                return False
                
        except Exception as e:
            self.logger.error(f"Error searching for duplicates: {str(e)}")
            # In case of error, assume not duplicate to be safe
            return False
    
    def find_similar_bugs(self, bug_number: str, project_key: str, threshold: int = 3) -> List[Dict[str, Any]]:
        """
        Find similar bugs that might be related
        
        Args:
            bug_number: Bug number to find similar bugs for
            project_key: Jira project key
            threshold: Maximum number of similar bugs to return
            
        Returns:
            List of similar bug dictionaries
        """
        self.logger.debug(f"Finding similar bugs to: {bug_number}")
        
        similar_bugs = []
        
        try:
            # Extract numeric part of bug number for pattern matching
            numeric_part = re.search(r'\d+', str(bug_number))
            if not numeric_part:
                return similar_bugs
            
            base_number = numeric_part.group()
            
            # Search for bugs with similar numbering
            jql = f'project = "{project_key}" AND summary ~ "QC ID" AND summary ~ "{base_number[:-1]}*"'
            
            issues = self.jira.search_issues(jql, fields=['summary', 'key', 'status'], max_results=threshold * 2)
            
            for issue in issues:
                summary = issue.get('fields', {}).get('summary', '')
                issue_key = issue.get('key', '')
                status = issue.get('fields', {}).get('status', {}).get('name', 'Unknown')
                
                # Extract QC ID from summary
                qc_match = re.search(r'QC ID\s+(\S+)', summary, re.IGNORECASE)
                if qc_match:
                    found_qc_id = qc_match.group(1)
                    
                    # Skip exact match
                    if found_qc_id == bug_number:
                        continue
                    
                    similar_bugs.append({
                        'issue_key': issue_key,
                        'qc_id': found_qc_id,
                        'summary': summary,
                        'status': status
                    })
                    
                    if len(similar_bugs) >= threshold:
                        break
            
            self.logger.info(f"Found {len(similar_bugs)} similar bugs")
            
        except Exception as e:
            self.logger.error(f"Error finding similar bugs: {str(e)}")
        
        return similar_bugs
    
    def get_duplicate_statistics(self, project_key: str) -> Dict[str, Any]:
        """
        Get statistics about QC ID patterns in the project
        
        Args:
            project_key: Jira project key
            
        Returns:
            Dictionary containing duplicate statistics
        """
        self.logger.info(f"Generating duplicate statistics for project: {project_key}")
        
        stats = {
            'total_issues': 0,
            'qc_id_issues': 0,
            'qc_id_patterns': set(),
            'potential_duplicates': []
        }
        
        try:
            # Get all issues with QC ID pattern
            jql = f'project = "{project_key}" AND summary ~ "QC ID"'
            issues = self.jira.search_issues(jql, fields=['summary', 'key'])
            
            stats['total_issues'] = len(issues)
            
            qc_id_count = {}
            
            for issue in issues:
                summary = issue.get('fields', {}).get('summary', '')
                issue_key = issue.get('key', '')
                
                # Extract QC ID from summary
                qc_match = re.search(r'QC ID\s+(\S+)', summary, re.IGNORECASE)
                if qc_match:
                    qc_id = qc_match.group(1)
                    stats['qc_id_patterns'].add(qc_id)
                    
                    # Track count for duplicate detection
                    if qc_id not in qc_id_count:
                        qc_id_count[qc_id] = []
                    qc_id_count[qc_id].append({
                        'issue_key': issue_key,
                        'summary': summary
                    })
            
            stats['qc_id_issues'] = len(stats['qc_id_patterns'])
            stats['qc_id_patterns'] = list(stats['qc_id_patterns'])  # Convert set to list for JSON serialization
            
            # Find potential duplicates (same QC ID appearing multiple times)
            for qc_id, issues_list in qc_id_count.items():
                if len(issues_list) > 1:
                    stats['potential_duplicates'].append({
                        'qc_id': qc_id,
                        'count': len(issues_list),
                        'issues': issues_list
                    })
            
            self.logger.info(f"Statistics generated: {len(stats['potential_duplicates'])} potential duplicate groups found")
            
        except Exception as e:
            self.logger.error(f"Error generating statistics: {str(e)}")
        
        return stats
    
    def refresh_cache(self, project_key: str) -> None:
        """
        Refresh the duplicate check cache
        
        Args:
            project_key: Jira project key
        """
        self.logger.info("Refreshing duplicate check cache...")
        
        self._existing_issues_cache.clear()
        self._cache_populated = False
        self._populate_cache(project_key)
    
    def clear_cache(self) -> None:
        """Clear the duplicate check cache"""
        self.logger.info("Clearing duplicate check cache...")
        
        self._existing_issues_cache.clear()
        self._cache_populated = False
