"""
Test suite for Jira Integration System
"""

import pytest
import json
import tempfile
import os
from unittest.mock import Mock, patch, MagicMock
from pathlib import Path

# Import modules to test
from jira_integration import JiraIntegrator
from csv_processor import CSVProcessor
from config_manager import ConfigManager
from duplicate_checker import DuplicateChecker
from logger_setup import setup_logger

class TestJiraIntegrator:
    """Test cases for JiraIntegrator class"""
    
    def setup_method(self):
        """Setup test fixtures"""
        self.jira_config = {
            'url': 'https://test.atlassian.net',
            'username': 'test@example.com',
            'password': 'test_password',
            'project_key': 'TEST'
        }
    
    def test_init_with_valid_config(self):
        """Test JiraIntegrator initialization with valid config"""
        integrator = JiraIntegrator(self.jira_config)
        
        assert integrator.base_url == 'https://test.atlassian.net'
        assert integrator.username == 'test@example.com'
        assert integrator.password == 'test_password'
    
    def test_init_missing_url(self):
        """Test JiraIntegrator initialization with missing URL"""
        config = self.jira_config.copy()
        del config['url']
        
        with pytest.raises(ValueError, match="Jira URL must be provided"):
            JiraIntegrator(config)
    
    def test_init_missing_username(self):
        """Test JiraIntegrator initialization with missing username"""
        config = self.jira_config.copy()
        del config['username']
        
        with pytest.raises(ValueError, match="Jira username must be provided"):
            JiraIntegrator(config)
    
    def test_init_missing_auth(self):
        """Test JiraIntegrator initialization with missing authentication"""
        config = self.jira_config.copy()
        del config['password']
        
        with pytest.raises(ValueError, match="Either JIRA_PASSWORD or JIRA_API_TOKEN must be provided"):
            JiraIntegrator(config)
    
    @patch('jira_integration.requests.Session')
    def test_test_connection_success(self, mock_session):
        """Test successful connection test"""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {'displayName': 'Test User'}
        
        mock_session_instance = Mock()
        mock_session_instance.get.return_value = mock_response
        mock_session.return_value = mock_session_instance
        
        integrator = JiraIntegrator(self.jira_config)
        integrator.session = mock_session_instance
        
        result = integrator.test_connection()
        
        assert result is True
        mock_session_instance.get.assert_called_once()
    
    @patch('jira_integration.requests.Session')
    def test_test_connection_failure(self, mock_session):
        """Test failed connection test"""
        mock_response = Mock()
        mock_response.status_code = 401
        mock_response.text = 'Unauthorized'
        
        mock_session_instance = Mock()
        mock_session_instance.get.return_value = mock_response
        mock_session.return_value = mock_session_instance
        
        integrator = JiraIntegrator(self.jira_config)
        integrator.session = mock_session_instance
        
        result = integrator.test_connection()
        
        assert result is False
    
    @patch('jira_integration.requests.Session')
    def test_create_issue_success(self, mock_session):
        """Test successful issue creation"""
        mock_response = Mock()
        mock_response.status_code = 201
        mock_response.json.return_value = {'key': 'TEST-123'}
        
        mock_session_instance = Mock()
        mock_session_instance.post.return_value = mock_response
        mock_session.return_value = mock_session_instance
        
        integrator = JiraIntegrator(self.jira_config)
        integrator.session = mock_session_instance
        
        issue_data = {
            'project': {'key': 'TEST'},
            'issuetype': {'name': 'Bug'},
            'summary': 'Test issue'
        }
        
        result = integrator.create_issue(issue_data)
        
        assert result == 'TEST-123'
        mock_session_instance.post.assert_called_once()
    
    @patch('jira_integration.requests.Session')
    def test_search_issues(self, mock_session):
        """Test issue search functionality"""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            'issues': [
                {'key': 'TEST-1', 'fields': {'summary': 'Test issue 1'}},
                {'key': 'TEST-2', 'fields': {'summary': 'Test issue 2'}}
            ],
            'total': 2
        }
        
        mock_session_instance = Mock()
        mock_session_instance.get.return_value = mock_response
        mock_session.return_value = mock_session_instance
        
        integrator = JiraIntegrator(self.jira_config)
        integrator.session = mock_session_instance
        
        result = integrator.search_issues('project = TEST')
        
        assert len(result) == 2
        assert result[0]['key'] == 'TEST-1'
        assert result[1]['key'] == 'TEST-2'


class TestCSVProcessor:
    """Test cases for CSVProcessor class"""
    
    def setup_method(self):
        """Setup test fixtures"""
        self.processor = CSVProcessor()
    
    def test_process_valid_csv(self):
        """Test processing a valid CSV file"""
        csv_content = """Bug number,Bug summery,Bug description,Detected by,Assign to
QC001,Test bug,Test description,tester1,dev1
QC002,Another bug,Another description,tester2,dev2"""
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            temp_file = f.name
        
        try:
            result = self.processor.process_csv(temp_file)
            
            assert len(result) == 2
            assert result[0]['bug_number'] == 'QC001'
            assert result[0]['summary'] == 'Test bug'
            assert result[1]['bug_number'] == 'QC002'
            assert result[1]['summary'] == 'Another bug'
        finally:
            os.unlink(temp_file)
    
    def test_process_csv_with_missing_columns(self):
        """Test processing CSV with missing required columns"""
        csv_content = """Bug number,Summary
QC001,Test bug"""
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            temp_file = f.name
        
        try:
            with pytest.raises(ValueError, match="Missing required columns"):
                self.processor.process_csv(temp_file)
        finally:
            os.unlink(temp_file)
    
    def test_process_nonexistent_file(self):
        """Test processing non-existent CSV file"""
        with pytest.raises(FileNotFoundError):
            self.processor.process_csv('/nonexistent/file.csv')
    
    def test_validate_csv_format_valid(self):
        """Test CSV format validation with valid file"""
        csv_content = """Bug number,Bug summery,Bug description,Detected by,Assign to
QC001,Test bug,Test description,tester1,dev1"""
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write(csv_content)
            temp_file = f.name
        
        try:
            result = self.processor.validate_csv_format(temp_file)
            
            assert result['valid'] is True
            assert result['row_count'] == 1
            assert result['column_count'] == 5
        finally:
            os.unlink(temp_file)
    
    def test_normalize_column_names(self):
        """Test column name normalization"""
        import pandas as pd
        
        # Create DataFrame with various column name formats
        df = pd.DataFrame(columns=['Bug Number', 'bug summery', 'BUG DESCRIPTION', 'detected by', 'assign to'])
        
        normalized_df = self.processor._normalize_column_names(df)
        
        expected_columns = ['bug_number', 'summary', 'description', 'detected_by', 'assign_to']
        assert list(normalized_df.columns) == expected_columns


class TestConfigManager:
    """Test cases for ConfigManager class"""
    
    def setup_method(self):
        """Setup test fixtures"""
        self.valid_config = {
            "jira": {
                "url": "https://test.atlassian.net",
                "username": "test@example.com",
                "password": "test_password",
                "project_key": "TEST"
            },
            "bug_template": {
                "issue_type": "Bug",
                "priority": "Medium",
                "product": "Test Product"
            }
        }
    
    def test_load_valid_config(self):
        """Test loading valid configuration"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(self.valid_config, f)
            temp_file = f.name
        
        try:
            manager = ConfigManager(temp_file)
            config = manager.load_config()
            
            assert config['jira']['url'] == 'https://test.atlassian.net'
            assert config['jira']['project_key'] == 'TEST'
            assert config['bug_template']['issue_type'] == 'Bug'
        finally:
            os.unlink(temp_file)
    
    def test_load_nonexistent_config(self):
        """Test loading non-existent configuration file"""
        manager = ConfigManager('/nonexistent/config.json')
        
        with pytest.raises(FileNotFoundError):
            manager.load_config()
    
    def test_load_invalid_json(self):
        """Test loading invalid JSON configuration"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            f.write('{"invalid": json}')
            temp_file = f.name
        
        try:
            manager = ConfigManager(temp_file)
            
            with pytest.raises(ValueError, match="Invalid JSON"):
                manager.load_config()
        finally:
            os.unlink(temp_file)
    
    def test_validate_jira_credentials(self):
        """Test Jira credentials validation"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(self.valid_config, f)
            temp_file = f.name
        
        try:
            manager = ConfigManager(temp_file)
            manager.load_config()
            
            validation = manager.validate_jira_credentials()
            
            assert validation['has_url'] is True
            assert validation['has_username'] is True
            assert validation['has_password'] is True
            assert validation['has_project_key'] is True
            assert validation['is_complete'] is True
        finally:
            os.unlink(temp_file)
    
    @patch.dict(os.environ, {'JIRA_URL': 'https://env.atlassian.net', 'JIRA_USERNAME': 'env@example.com'})
    def test_environment_overrides(self):
        """Test environment variable overrides"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(self.valid_config, f)
            temp_file = f.name
        
        try:
            manager = ConfigManager(temp_file)
            config = manager.load_config()
            
            # Environment variables should override config file values
            assert config['jira']['url'] == 'https://env.atlassian.net'
            assert config['jira']['username'] == 'env@example.com'
        finally:
            os.unlink(temp_file)


class TestDuplicateChecker:
    """Test cases for DuplicateChecker class"""
    
    def setup_method(self):
        """Setup test fixtures"""
        self.mock_jira = Mock(spec=JiraIntegrator)
        self.checker = DuplicateChecker(self.mock_jira)
    
    def test_is_duplicate_found_in_cache(self):
        """Test duplicate detection when found in cache"""
        # Setup mock response for cache population
        self.mock_jira.get_project_issues.return_value = [
            {
                'key': 'TEST-1',
                'fields': {'summary': 'QC ID QC001 - Test bug'}
            },
            {
                'key': 'TEST-2', 
                'fields': {'summary': 'QC ID QC002 - Another bug'}
            }
        ]
        
        result = self.checker.is_duplicate('QC001', 'TEST')
        
        assert result is True
        self.mock_jira.get_project_issues.assert_called_once()
    
    def test_is_duplicate_not_found(self):
        """Test duplicate detection when not found"""
        # Setup mock response for cache population
        self.mock_jira.get_project_issues.return_value = [
            {
                'key': 'TEST-1',
                'fields': {'summary': 'QC ID QC001 - Test bug'}
            }
        ]
        
        # Setup mock response for direct search
        self.mock_jira.search_issues.return_value = []
        
        result = self.checker.is_duplicate('QC999', 'TEST')
        
        assert result is False
    
    def test_find_similar_bugs(self):
        """Test finding similar bugs"""
        self.mock_jira.search_issues.return_value = [
            {
                'key': 'TEST-1',
                'fields': {
                    'summary': 'QC ID QC001 - Similar bug',
                    'status': {'name': 'Open'}
                }
            },
            {
                'key': 'TEST-2',
                'fields': {
                    'summary': 'QC ID QC002 - Another similar bug',
                    'status': {'name': 'In Progress'}
                }
            }
        ]
        
        result = self.checker.find_similar_bugs('QC003', 'TEST')
        
        assert len(result) == 2
        assert result[0]['qc_id'] == 'QC001'
        assert result[1]['qc_id'] == 'QC002'
    
    def test_get_duplicate_statistics(self):
        """Test getting duplicate statistics"""
        self.mock_jira.search_issues.return_value = [
            {
                'key': 'TEST-1',
                'fields': {'summary': 'QC ID QC001 - Test bug'}
            },
            {
                'key': 'TEST-2',
                'fields': {'summary': 'QC ID QC001 - Duplicate bug'}
            },
            {
                'key': 'TEST-3',
                'fields': {'summary': 'QC ID QC002 - Another bug'}
            }
        ]
        
        result = self.checker.get_duplicate_statistics('TEST')
        
        assert result['total_issues'] == 3
        assert result['qc_id_issues'] == 2  # Unique QC IDs
        assert len(result['potential_duplicates']) == 1  # One duplicate group
        assert result['potential_duplicates'][0]['qc_id'] == 'QC001'
        assert result['potential_duplicates'][0]['count'] == 2


class TestIntegration:
    """Integration tests for the complete system"""
    
    def test_end_to_end_dry_run(self):
        """Test complete end-to-end flow in dry run mode"""
        # This test would require more complex setup
        # and would be implemented based on specific requirements
        pass
    
    def test_config_and_csv_integration(self):
        """Test integration between config manager and CSV processor"""
        # Create test CSV
        csv_content = """Bug number,Bug summery,Bug description,Detected by,Assign to
QC001,Test bug,Test description,tester1,dev1"""
        
        # Create test config
        config_data = {
            "jira": {
                "url": "https://test.atlassian.net",
                "project_key": "TEST"
            },
            "bug_template": {
                "issue_type": "Bug",
                "priority": "Medium"
            }
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as csv_file:
            csv_file.write(csv_content)
            csv_path = csv_file.name
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as config_file:
            json.dump(config_data, config_file)
            config_path = config_file.name
        
        try:
            # Test CSV processing
            processor = CSVProcessor()
            bugs = processor.process_csv(csv_path)
            
            # Test config loading
            config_manager = ConfigManager(config_path)
            config = config_manager.load_config()
            
            # Verify integration
            assert len(bugs) == 1
            assert bugs[0]['bug_number'] == 'QC001'
            assert config['jira']['project_key'] == 'TEST'
            
        finally:
            os.unlink(csv_path)
            os.unlink(config_path)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
