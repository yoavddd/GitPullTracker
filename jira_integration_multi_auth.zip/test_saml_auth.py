#!/usr/bin/env python3
"""
SAML Authentication Test Script
Test SAML authentication with your corporate Jira instance
"""

import sys
import json
from saml_auth import authenticate_jira_saml

# REPLACE THESE WITH YOUR ACTUAL VALUES
JIRA_URL = "https://jira.esl.corp.elbit.co.il"
USERNAME = "your-corporate-username"          # Your corporate username/employee ID
PASSWORD = "your-corporate-password"          # Your corporate password
PROJECT_KEY = "TEST"                          # Project where you want to create bugs
VERIFY_SSL = False                            # False for self-signed certificates

def test_saml_authentication():
    """Test SAML authentication with corporate Jira"""
    
    print("=== SAML Authentication Test ===")
    print(f"Jira URL: {JIRA_URL}")
    print(f"Username: {USERNAME}")
    print(f"SSL Verification: {VERIFY_SSL}")
    print("-" * 50)
    
    # Test SAML authentication
    print("1. Testing SAML authentication...")
    session = authenticate_jira_saml(JIRA_URL, USERNAME, PASSWORD, VERIFY_SSL)
    
    if not session:
        print("❌ SAML authentication failed")
        print("\nTroubleshooting steps:")
        print("1. Verify your corporate username and password")
        print("2. Check if you're connected to the corporate network/VPN")
        print("3. Confirm the Jira URL is correct")
        print("4. Try accessing Jira manually in your browser first")
        return False
    
    print("✅ SAML authentication successful!")
    
    # Test basic API access
    print("\n2. Testing API access...")
    try:
        response = session.get(f"{JIRA_URL}/rest/api/2/myself")
        if response.status_code == 200:
            user_info = response.json()
            print("✅ API access confirmed!")
            print(f"   Logged in as: {user_info.get('displayName', 'Unknown')}")
            print(f"   Email: {user_info.get('emailAddress', 'Unknown')}")
            print(f"   Account ID: {user_info.get('accountId', 'Unknown')}")
        else:
            print(f"❌ API access failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ API access error: {e}")
        return False
    
    # Test project access
    print("\n3. Testing project access...")
    try:
        response = session.get(f"{JIRA_URL}/rest/api/2/project/{PROJECT_KEY}")
        if response.status_code == 200:
            project_info = response.json()
            print("✅ Project access confirmed!")
            print(f"   Project: {project_info.get('name', 'Unknown')}")
            print(f"   Key: {project_info.get('key', 'Unknown')}")
            print(f"   Lead: {project_info.get('lead', {}).get('displayName', 'Unknown')}")
        else:
            print(f"❌ Project access failed: {response.status_code}")
            if response.status_code == 404:
                print(f"   Project '{PROJECT_KEY}' not found or no access")
                print("   Please check the project key or request access")
            return False
    except Exception as e:
        print(f"❌ Project access error: {e}")
        return False
    
    # Test issue types
    print("\n4. Testing issue types...")
    try:
        response = session.get(f"{JIRA_URL}/rest/api/2/project/{PROJECT_KEY}")
        if response.status_code == 200:
            project_info = response.json()
            issue_types = project_info.get('issueTypes', [])
            print("✅ Available issue types:")
            for issue_type in issue_types[:5]:  # Show first 5
                print(f"   - {issue_type.get('name')} (ID: {issue_type.get('id')})")
        else:
            print("⚠️  Could not retrieve issue types")
    except Exception as e:
        print(f"⚠️  Issue types error: {e}")
    
    print("\n🎉 All tests passed! SAML authentication is working correctly.")
    print("\nNext steps:")
    print("1. Update config/saml_jira_config.json with your credentials")
    print("2. Run: python main.py --csv sample_data/bugs_input.csv --config config/saml_jira_config.json --dry-run")
    
    return True

def create_saml_config():
    """Create a SAML configuration file with current settings"""
    
    config = {
        "jira": {
            "url": JIRA_URL,
            "username": USERNAME,
            "password": PASSWORD,
            "api_token": "",
            "project_key": PROJECT_KEY,
            "verify_ssl": VERIFY_SSL,
            "use_saml": True
        },
        "bug_template": {
            "issue_type": "Bug",
            "priority": "Medium",
            "product": "Corporate Product",
            "environment": "Testing",
            "reproducible": True,
            "default_assignee": "",
            "default_reporter": "qa-team",
            "components": ["QA Component"],
            "labels": ["QC-Import", "Automated", "SAML-Auth"],
            "custom_fields": {
                "customfield_10001": {"value": "High"},
                "customfield_10002": "QC Import via SAML"
            },
            "additional_notes": "This issue was automatically created from QC bug data using SAML authentication."
        },
        "processing_options": {
            "batch_size": 50,
            "delay_between_requests": 1.0,
            "max_retries": 3,
            "skip_validation": False
        },
        "wbs_structure": {
            "root_component": "Quality Control",
            "default_epic": "QC-001",
            "hierarchy_levels": ["Epic", "Story", "Bug"]
        }
    }
    
    with open('config/my_saml_config.json', 'w') as f:
        json.dump(config, f, indent=2)
    
    print("✅ Created config/my_saml_config.json with your settings")

if __name__ == "__main__":
    if USERNAME == "your-corporate-username":
        print("⚠️  Please edit this file and replace the placeholder values!")
        print("\nYou need to update:")
        print("- USERNAME: Your corporate username/employee ID")
        print("- PASSWORD: Your corporate password") 
        print("- PROJECT_KEY: Your project key (like 'TEST', 'BUG', etc.)")
        print("\nExample:")
        print('USERNAME = "john.doe"')
        print('PASSWORD = "your-password"')
        print('PROJECT_KEY = "MYPROJ"')
        sys.exit(1)
    
    success = test_saml_authentication()
    
    if success:
        create_config = input("\nDo you want to create a config file with these settings? (y/n): ")
        if create_config.lower() in ['y', 'yes']:
            create_saml_config()
    else:
        print("\n❌ Authentication failed. Please check your credentials and network connection.")