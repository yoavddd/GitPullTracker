#!/usr/bin/env python3
"""
Demonstration Script for Jira Bug Integration System
Shows all features and capabilities of the API
"""

import json
from pathlib import Path
from api_interface import JiraBugIntegrationAPI, quick_process_csv, analyze_csv_wbs
from logger_setup import setup_logger

def main():
    """Main demonstration function"""
    
    print("=" * 80)
    print("JIRA BUG INTEGRATION SYSTEM - COMPREHENSIVE DEMONSTRATION")
    print("=" * 80)
    print()
    
    # Configuration paths
    config_path = "config/jira_config.json"
    csv_path = "sample_data/bugs_input.csv"
    
    # Initialize API in test mode
    print("🔧 Initializing API in test mode...")
    api = JiraBugIntegrationAPI(config_path, test_mode=True)
    print("✅ API initialized successfully")
    print()
    
    # 1. System Status Check
    print("📊 SYSTEM STATUS CHECK")
    print("-" * 40)
    status = api.get_system_status()
    print(f"API Version: {status['api_version']}")
    print(f"Test Mode: {status['test_mode']}")
    print(f"Overall Validation: {status['validation']['overall_status']}")
    print(f"WBS Categories: {len(status['wbs_summary']['categories'])}")
    print()
    
    # 2. WBS Analysis
    print("🏗️  WORK BREAKDOWN STRUCTURE ANALYSIS")
    print("-" * 40)
    wbs_analysis = api.get_wbs_analysis(csv_path)
    
    print(f"Total Bugs Analyzed: {wbs_analysis['total_bugs']}")
    print(f"WBS Categories Found: {list(wbs_analysis['categorization_breakdown'].keys())}")
    print()
    print("Category Breakdown:")
    for category, count in wbs_analysis['categorization_breakdown'].items():
        percentage = (count / wbs_analysis['total_bugs']) * 100
        print(f"  • {category}: {count} bugs ({percentage:.1f}%)")
    print()
    
    print("Epic Distribution:")
    for epic, count in wbs_analysis['epic_distribution'].items():
        print(f"  • {epic}: {count} bugs")
    print()
    
    print("Priority Distribution:")
    for priority, count in wbs_analysis['priority_distribution'].items():
        print(f"  • {priority}: {count} bugs")
    print()
    
    # 3. Sample Bug Analysis
    print("🔍 SAMPLE BUG CATEGORIZATION")
    print("-" * 40)
    for i, sample in enumerate(wbs_analysis['bug_samples'][:3], 1):
        print(f"Bug {i}: {sample['bug_number']}")
        print(f"  Summary: {sample['summary'][:60]}...")
        print(f"  WBS Category: {sample['wbs_category']}")
        print(f"  Epic: {sample['epic']}")
        print(f"  Priority: {sample['priority']}")
        print(f"  Components: {', '.join(sample['components'])}")
        print()
    
    # 4. Duplicate Detection Demo
    print("🔍 DUPLICATE DETECTION DEMONSTRATION")
    print("-" * 40)
    test_bug_numbers = ['QC001', 'QC002', 'QC005', 'QC999']  # QC001 and QC005 should be duplicates in test mode
    duplicate_results = api.check_for_duplicates(test_bug_numbers, "PROJ")
    
    print(f"Bugs Checked: {duplicate_results['total_checked']}")
    print(f"Duplicates Found: {duplicate_results['duplicates_found']}")
    print(f"Unique Bugs: {duplicate_results['unique_bugs']}")
    print()
    
    if duplicate_results['duplicate_list']:
        print("Duplicates Found:")
        for dup in duplicate_results['duplicate_list']:
            print(f"  • {dup}")
    print()
    
    # 5. Full Processing Demo
    print("🚀 FULL PROCESSING DEMONSTRATION (DRY RUN)")
    print("-" * 40)
    processing_results = api.process_bugs_from_csv(csv_path, dry_run=True)
    
    print(f"Processing Status: {processing_results['status']}")
    print(f"Total Bugs: {processing_results['total_bugs']}")
    print(f"Successfully Processed: {processing_results['created']}")
    print(f"Skipped (Duplicates): {processing_results['skipped']}")
    print(f"Errors: {processing_results['errors']}")
    print()
    
    # Processing summary
    summary = processing_results['processing_summary']
    print("Processing Summary:")
    print(f"  • Success Rate: {summary['success_rate']:.1f}%")
    print(f"  • Duplicate Rate: {summary['duplicate_rate']:.1f}%")
    print(f"  • Error Rate: {summary['error_rate']:.1f}%")
    print()
    
    # WBS categorization results
    print("WBS Categorization Results:")
    for category, count in processing_results['wbs_categorization'].items():
        print(f"  • {category}: {count} bugs")
    print()
    
    # 6. Detailed Bug Processing Examples
    print("📋 DETAILED BUG PROCESSING EXAMPLES")
    print("-" * 40)
    
    # Show first few processed bugs
    for i, bug_detail in enumerate(processing_results['bug_details'][:5], 1):
        print(f"Bug {i}: {bug_detail['bug_number']}")
        print(f"  Status: {bug_detail['status']}")
        if bug_detail['status'] != 'SKIPPED':
            print(f"  WBS Category: {bug_detail.get('wbs_category', 'N/A')}")
            print(f"  Epic: {bug_detail.get('epic', 'N/A')}")
            print(f"  Priority: {bug_detail.get('priority', 'N/A')}")
            components = bug_detail.get('components', [])
            if components:
                print(f"  Components: {', '.join(components)}")
        else:
            print(f"  Reason: {bug_detail.get('reason', 'N/A')}")
        print()
    
    # 7. Configuration Information
    print("⚙️  SYSTEM CONFIGURATION")
    print("-" * 40)
    config_summary = status['config_summary']
    print(f"Jira URL: {config_summary['jira']['url']}")
    print(f"Project Key: {config_summary['jira']['project_key']}")
    print(f"Has Credentials: {config_summary['jira']['has_credentials']}")
    print(f"Bug Template Issue Type: {config_summary['bug_template']['issue_type']}")
    print(f"Bug Template Priority: {config_summary['bug_template']['priority']}")
    print(f"Components Count: {config_summary['bug_template']['components_count']}")
    print(f"Labels Count: {config_summary['bug_template']['labels_count']}")
    print()
    
    # 8. API Usage Examples
    print("💡 API USAGE EXAMPLES")
    print("-" * 40)
    print("1. Quick CSV Processing:")
    print("   results = quick_process_csv('config.json', 'bugs.csv', dry_run=True)")
    print()
    print("2. WBS Analysis Only:")
    print("   analysis = analyze_csv_wbs('config.json', 'bugs.csv')")
    print()
    print("3. Full API Usage:")
    print("   api = JiraBugIntegrationAPI('config.json', test_mode=False)")
    print("   status = api.validate_system()")
    print("   results = api.process_bugs_from_csv('bugs.csv', dry_run=False)")
    print()
    
    print("=" * 80)
    print("✅ DEMONSTRATION COMPLETED SUCCESSFULLY")
    print("=" * 80)
    print()
    print("Key Features Demonstrated:")
    print("✓ CSV processing with flexible column mapping")
    print("✓ WBS-based bug categorization and prioritization") 
    print("✓ Intelligent duplicate detection using 'QC ID' patterns")
    print("✓ Comprehensive logging and error handling")
    print("✓ Test mode for safe development and testing")
    print("✓ Professional API interface for integration")
    print("✓ Dry-run mode for validation before execution")
    print("✓ Epic and component assignment based on bug content")
    print()


if __name__ == '__main__':
    main()