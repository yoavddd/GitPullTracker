"""
Configuration Manager Module
Handles loading and validation of configuration files.
"""

import json
import logging
import os
from typing import Dict, Any


class ConfigManager:
    """Manager for configuration files."""
    
    def __init__(self, config_file_path: str):
        """Initialize configuration manager."""
        self.logger = logging.getLogger(__name__)
        self.config_file_path = config_file_path
        self.logger.info(f"Initialized config manager for file: {config_file_path}")
    
    def load_config(self) -> Dict[str, Any]:
        """Load configuration from JSON file."""
        try:
            if not os.path.exists(self.config_file_path):
                self.logger.error(f"Configuration file not found: {self.config_file_path}")
                raise FileNotFoundError(f"Configuration file not found: {self.config_file_path}")
            
            with open(self.config_file_path, 'r', encoding='utf-8') as file:
                config = json.load(file)
            
            # Validate configuration
            self._validate_config(config)
            
            # Apply environment variable overrides
            config = self._apply_env_overrides(config)
            
            self.logger.info("Configuration loaded successfully")
            return config
            
        except json.JSONDecodeError as e:
            self.logger.error(f"Invalid JSON in configuration file: {str(e)}")
            raise
        except Exception as e:
            self.logger.error(f"Error loading configuration: {str(e)}")
            raise
    
    def _validate_config(self, config: Dict[str, Any]) -> None:
        """Validate configuration structure and required fields."""
        required_sections = ['jira', 'bug_template']
        
        for section in required_sections:
            if section not in config:
                self.logger.error(f"Missing required configuration section: {section}")
                raise ValueError(f"Missing required configuration section: {section}")
        
        # Validate JIRA configuration
        jira_config = config.get('jira', {})
        required_jira_fields = ['url', 'username', 'password', 'project_key']
        
        for field in required_jira_fields:
            if field not in jira_config or not jira_config[field]:
                self.logger.error(f"Missing required JIRA configuration field: {field}")
                raise ValueError(f"Missing required JIRA configuration field: {field}")
        
        # Validate URLs
        url = jira_config.get('url', '')
        if not url.startswith(('http://', 'https://')):
            self.logger.error(f"Invalid JIRA URL format: {url}")
            raise ValueError(f"Invalid JIRA URL format: {url}")
        
        self.logger.info("Configuration validation passed")
    
    def _apply_env_overrides(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Apply environment variable overrides to configuration."""
        # Override JIRA credentials from environment if available
        jira_config = config.get('jira', {})
        
        # Check for environment variables
        env_overrides = {
            'JIRA_URL': 'url',
            'JIRA_USERNAME': 'username',
            'JIRA_PASSWORD': 'password',
            'JIRA_PROJECT_KEY': 'project_key',
            'JIRA_EPIC_KEY': 'epic_key'
        }
        
        for env_var, config_key in env_overrides.items():
            env_value = os.getenv(env_var)
            if env_value:
                jira_config[config_key] = env_value
                self.logger.info(f"Applied environment override for {config_key}")
        
        config['jira'] = jira_config
        return config
    
    def save_config(self, config: Dict[str, Any]) -> None:
        """Save configuration to JSON file."""
        try:
            with open(self.config_file_path, 'w', encoding='utf-8') as file:
                json.dump(config, file, indent=2, ensure_ascii=False)
            
            self.logger.info(f"Configuration saved to: {self.config_file_path}")
            
        except Exception as e:
            self.logger.error(f"Error saving configuration: {str(e)}")
            raise
    
    def create_default_config(self) -> Dict[str, Any]:
        """Create a default configuration template."""
        default_config = {
            "jira": {
                "url": "https://jira.eal.corp.el.co.il",
                "username": "user",
                "password": "pass",
                "project_key": "123",
                "epic_key": "ASUVNG-1840",
                "structure_board_id": "5062"
            },
            "bug_template": {
                "issue_type": "Bug",
                "priority": "Medium",
                "assignee": "",
                "reporter": "",
                "components": [],
                "labels": ["automated-import", "qc-bug"],
                "custom_fields": {
                    "customfield_10100": "QC Import",
                    "customfield_10101": "Yes"
                }
            },
            "csv_mapping": {
                "defect_id": "defect_id",
                "summary": "summary",
                "description": "bug_description",
                "detected_by": "detected_by",
                "assigned_to": "assign_to"
            }
        }
        
        return default_config
    
    def get_config_template(self) -> str:
        """Get configuration template as JSON string."""
        template = self.create_default_config()
        return json.dumps(template, indent=2, ensure_ascii=False)
