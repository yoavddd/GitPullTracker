"""
CSV Processing Module
Handles reading and validation of CSV bug data
"""

import pandas as pd
import csv
from typing import List, Dict, Any
from pathlib import Path

from logger_setup import setup_logger


class CSVProcessor:
    """Handles processing of CSV files containing bug data"""
    
    def __init__(self):
        """Initialize CSV processor"""
        self.logger = setup_logger()
        self.logger.info("CSV processor initialized")
        
        # Define expected CSV columns
        self.required_columns = {
            'bug_number': ['bug number', 'bug_number', 'qc_id', 'id'],
            'summary': ['bug summery', 'bug_summary', 'summary', 'title'],
            'description': ['bug description', 'description', 'desc'],
            'detected_by': ['detected by', 'detected_by', 'reporter', 'found_by'],
            'assign_to': ['assign to', 'assign_to', 'assignee', 'assigned_to']
        }
        
    def process_csv(self, csv_file_path: str) -> List[Dict[str, Any]]:
        """
        Process CSV file and return list of bug data dictionaries
        
        Args:
            csv_file_path: Path to the CSV file
            
        Returns:
            List of dictionaries containing bug data
        """
        self.logger.info(f"Processing CSV file: {csv_file_path}")
        
        # Validate file exists
        if not Path(csv_file_path).exists():
            raise FileNotFoundError(f"CSV file not found: {csv_file_path}")
        
        try:
            # Read CSV file with pandas
            df = pd.read_csv(csv_file_path)
            self.logger.info(f"Successfully read CSV file with {len(df)} rows and {len(df.columns)} columns")
            self.logger.debug(f"CSV columns: {list(df.columns)}")
            
            # Normalize column names
            df = self._normalize_column_names(df)
            
            # Validate required columns
            self._validate_columns(df)
            
            # Clean and validate data
            df = self._clean_data(df)
            
            # Convert to list of dictionaries
            bug_data_list = df.to_dict('records')
            
            self.logger.info(f"Successfully processed {len(bug_data_list)} bug records")
            
            # Log sample data for debugging
            if bug_data_list:
                self.logger.debug(f"Sample bug record: {bug_data_list[0]}")
            
            return bug_data_list
            
        except pd.errors.EmptyDataError:
            self.logger.error("CSV file is empty")
            raise ValueError("CSV file is empty")
        except pd.errors.ParserError as e:
            self.logger.error(f"Error parsing CSV file: {str(e)}")
            raise ValueError(f"Error parsing CSV file: {str(e)}")
        except Exception as e:
            self.logger.error(f"Unexpected error processing CSV: {str(e)}")
            raise
    
    def _normalize_column_names(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Normalize column names to match expected format
        
        Args:
            df: Input DataFrame
            
        Returns:
            DataFrame with normalized column names
        """
        self.logger.debug("Normalizing column names...")
        
        # Create mapping of original columns to normalized names
        column_mapping = {}
        
        for col in df.columns:
            col_lower = col.strip().lower()
            
            # Find matching standard column name
            for standard_name, variations in self.required_columns.items():
                if col_lower in [v.lower() for v in variations]:
                    column_mapping[col] = standard_name
                    break
        
        if column_mapping:
            self.logger.debug(f"Column mapping applied: {column_mapping}")
            df = df.rename(columns=column_mapping)
        
        return df
    
    def _validate_columns(self, df: pd.DataFrame) -> None:
        """
        Validate that required columns are present
        
        Args:
            df: DataFrame to validate
            
        Raises:
            ValueError: If required columns are missing
        """
        self.logger.debug("Validating CSV columns...")
        
        missing_columns = []
        
        for required_col in self.required_columns.keys():
            if required_col not in df.columns:
                missing_columns.append(required_col)
        
        if missing_columns:
            self.logger.error(f"Missing required columns: {missing_columns}")
            self.logger.info("Available columns: " + ", ".join(df.columns))
            self.logger.info("Expected column variations:")
            for col, variations in self.required_columns.items():
                self.logger.info(f"  {col}: {variations}")
            
            raise ValueError(f"Missing required columns: {missing_columns}")
        
        self.logger.debug("All required columns found")
    
    def _clean_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Clean and validate the data
        
        Args:
            df: Input DataFrame
            
        Returns:
            Cleaned DataFrame
        """
        self.logger.debug("Cleaning and validating data...")
        
        original_count = len(df)
        
        # Remove rows where bug_number is null or empty
        df = df.dropna(subset=['bug_number'])
        df = df[df['bug_number'].astype(str).str.strip() != '']
        
        if len(df) < original_count:
            removed = original_count - len(df)
            self.logger.warning(f"Removed {removed} rows with missing or empty bug numbers")
        
        # Clean string fields
        string_columns = ['bug_number', 'summary', 'description', 'detected_by', 'assign_to']
        
        for col in string_columns:
            if col in df.columns:
                # Convert to string and strip whitespace
                df[col] = df[col].astype(str).str.strip()
                
                # Replace 'nan' string with empty string
                df[col] = df[col].replace('nan', '')
        
        # Validate bug numbers are not empty after cleaning
        empty_bug_numbers = df[df['bug_number'] == '']
        if not empty_bug_numbers.empty:
            self.logger.warning(f"Found {len(empty_bug_numbers)} rows with empty bug numbers after cleaning")
            df = df[df['bug_number'] != '']
        
        # Set default values for optional fields
        if 'summary' in df.columns:
            df['summary'] = df['summary'].fillna('No summary provided')
            df.loc[df['summary'] == '', 'summary'] = 'No summary provided'
        
        if 'description' in df.columns:
            df['description'] = df['description'].fillna('No description provided')
            df.loc[df['description'] == '', 'description'] = 'No description provided'
        
        if 'detected_by' in df.columns:
            df['detected_by'] = df['detected_by'].fillna('Unknown')
            df.loc[df['detected_by'] == '', 'detected_by'] = 'Unknown'
        
        if 'assign_to' in df.columns:
            df['assign_to'] = df['assign_to'].fillna('Unassigned')
            df.loc[df['assign_to'] == '', 'assign_to'] = 'Unassigned'
        
        self.logger.info(f"Data cleaning completed. Final record count: {len(df)}")
        
        # Log data quality statistics
        self._log_data_statistics(df)
        
        return df
    
    def _log_data_statistics(self, df: pd.DataFrame) -> None:
        """
        Log data quality statistics
        
        Args:
            df: DataFrame to analyze
        """
        self.logger.debug("Data quality statistics:")
        self.logger.debug(f"  Total records: {len(df)}")
        
        for col in df.columns:
            if col in df.columns:
                null_count = df[col].isnull().sum()
                empty_count = (df[col] == '').sum()
                unique_count = df[col].nunique()
                
                self.logger.debug(f"  {col}: {unique_count} unique values, {null_count} nulls, {empty_count} empty")
        
        # Check for potential duplicate bug numbers
        duplicate_bugs = df[df.duplicated(subset=['bug_number'], keep=False)]
        if not duplicate_bugs.empty:
            self.logger.warning(f"Found {len(duplicate_bugs)} rows with duplicate bug numbers")
            duplicate_bug_numbers = duplicate_bugs['bug_number'].unique()
            self.logger.warning(f"Duplicate bug numbers: {list(duplicate_bug_numbers)}")
    
    def validate_csv_format(self, csv_file_path: str) -> Dict[str, Any]:
        """
        Validate CSV format without fully processing it
        
        Args:
            csv_file_path: Path to the CSV file
            
        Returns:
            Dictionary containing validation results
        """
        self.logger.info(f"Validating CSV format: {csv_file_path}")
        
        validation_result = {
            'valid': False,
            'errors': [],
            'warnings': [],
            'row_count': 0,
            'column_count': 0,
            'columns': []
        }
        
        try:
            # Check if file exists
            if not Path(csv_file_path).exists():
                validation_result['errors'].append(f"File not found: {csv_file_path}")
                return validation_result
            
            # Try to read just the header
            with open(csv_file_path, 'r', newline='', encoding='utf-8') as file:
                # Detect delimiter
                sample = file.read(1024)
                file.seek(0)
                sniffer = csv.Sniffer()
                delimiter = sniffer.sniff(sample).delimiter
                
                # Read header
                reader = csv.reader(file, delimiter=delimiter)
                header = next(reader)
                
                validation_result['columns'] = header
                validation_result['column_count'] = len(header)
                
                # Count total rows
                row_count = sum(1 for _ in reader)
                validation_result['row_count'] = row_count
            
            # Check for required columns
            df_temp = pd.DataFrame(columns=header)
            df_temp = self._normalize_column_names(df_temp)
            
            missing_columns = []
            for required_col in self.required_columns.keys():
                if required_col not in df_temp.columns:
                    missing_columns.append(required_col)
            
            if missing_columns:
                validation_result['errors'].append(f"Missing required columns: {missing_columns}")
            else:
                validation_result['valid'] = True
            
            # Add warnings for empty file
            if validation_result['row_count'] == 0:
                validation_result['warnings'].append("CSV file appears to be empty (no data rows)")
            
            self.logger.info(f"CSV validation completed. Valid: {validation_result['valid']}")
            
        except Exception as e:
            validation_result['errors'].append(f"Error validating CSV: {str(e)}")
            self.logger.error(f"Error validating CSV: {str(e)}")
        
        return validation_result
