#!/usr/bin/env python3
"""
Jira Bug Integration System
Main entry point for processing CSV bug data and creating Jira issues
"""

import argparse
import sys
import os
from pathlib import Path
from typing import List, Dict, Any

from jira_integration import JiraIntegrator
from browser_session_auth import BrowserSessionJiraIntegrator
from csv_processor import CSVProcessor
from config_manager import ConfigManager
from duplicate_checker import DuplicateChecker
from wbs_structure_manager import WBSStructureManager
from logger_setup import setup_logger


def main():
    """Main function to orchestrate the Jira bug integration process"""
    
    # Setup argument parser
    parser = argparse.ArgumentParser(
        description='Process CSV bug data and create Jira issues',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Standard authentication (API token/password)
  python main.py --csv sample_data/bugs_input.csv --config config/jira_config.json
  
  # Selenium authentication for complex login flows
  python main.py --csv sample_data/bugs_input.csv --config config/selenium_jira_config.json --use-selenium
  
  # SAML authentication for corporate environments
  python main.py --csv sample_data/bugs_input.csv --config config/saml_jira_config.json
  
  # Dry run mode (recommended for testing)
  python main.py --csv bugs.csv --config config.json --dry-run --use-selenium
  
  # Debug mode with detailed logging
  python main.py --csv bugs.csv --config config.json --log-level DEBUG --use-selenium
        """
    )
    
    parser.add_argument('--csv', required=True, 
                       help='Path to CSV file containing bug data')
    parser.add_argument('--config', required=True,
                       help='Path to JSON configuration file')
    parser.add_argument('--dry-run', action='store_true',
                       help='Perform dry run without creating actual Jira issues')
    parser.add_argument('--test-mode', action='store_true',
                       help='Run in test mode without connecting to Jira')
    parser.add_argument('--log-level', default='INFO',
                       choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
                       help='Set logging level')
    parser.add_argument('--log-file', default='jira_integration.log',
                       help='Log file path')
    parser.add_argument('--use-selenium', action='store_true',
                       help='Use Selenium-based authentication for complex login flows')
    
    args = parser.parse_args()
    
    # Setup logging
    logger = setup_logger(args.log_level, args.log_file)
    logger.info("=" * 80)
    logger.info("Starting Jira Bug Integration System")
    logger.info("=" * 80)
    logger.info(f"CSV file: {args.csv}")
    logger.info(f"Config file: {args.config}")
    logger.info(f"Dry run mode: {args.dry_run}")
    logger.info(f"Test mode: {args.test_mode}")
    logger.info(f"Log level: {args.log_level}")
    
    try:
        # Validate input files
        if not os.path.exists(args.csv):
            logger.error(f"CSV file not found: {args.csv}")
            sys.exit(1)
            
        if not os.path.exists(args.config):
            logger.error(f"Config file not found: {args.config}")
            sys.exit(1)
        
        # Initialize components
        logger.info("Initializing system components...")
        
        # Load configuration
        config_manager = ConfigManager(args.config)
        config = config_manager.load_config()
        logger.info("Configuration loaded successfully")
        
        # Initialize CSV processor
        csv_processor = CSVProcessor()
        logger.info("CSV processor initialized")
        
        # Initialize Jira integrator based on authentication method
        if args.use_selenium:
            logger.info("Using browser session-based authentication...")
            jira_integrator = BrowserSessionJiraIntegrator(config['jira'])
            logger.info("Browser session Jira integrator initialized")
            
            # Test Selenium authentication only if not in test mode
            if not args.test_mode:
                logger.info("Testing Selenium authentication...")
                if not jira_integrator.authenticate():
                    logger.error("Failed to authenticate with Jira using Selenium. Please check credentials and browser setup.")
                    sys.exit(1)
                logger.info("Selenium authentication successful")
            else:
                logger.info("Test mode enabled - skipping Selenium authentication test")
        else:
            logger.info("Using standard REST API authentication...")
            jira_integrator = JiraIntegrator(config['jira'])
            logger.info("Standard Jira integrator initialized")
            
            # Test Jira connection only if not in test mode
            if not args.test_mode:
                logger.info("Testing Jira connection...")
                if not jira_integrator.test_connection():
                    logger.error("Failed to connect to Jira. Please check credentials and URL.")
                    sys.exit(1)
                logger.info("Jira connection successful")
            else:
                logger.info("Test mode enabled - skipping Jira connection test")
        
        # Initialize duplicate checker
        duplicate_checker = DuplicateChecker(jira_integrator, test_mode=args.test_mode)
        logger.info("Duplicate checker initialized")
        
        # Initialize WBS structure manager
        wbs_manager = WBSStructureManager(config.get('wbs_structure', {}))
        logger.info("WBS structure manager initialized")
        
        # Process CSV file
        logger.info(f"Processing CSV file: {args.csv}")
        bugs_data = csv_processor.process_csv(args.csv)
        logger.info(f"Successfully processed {len(bugs_data)} bug records from CSV")
        
        # Process each bug
        total_bugs = len(bugs_data)
        created_count = 0
        skipped_count = 0
        error_count = 0
        
        logger.info(f"Starting to process {total_bugs} bugs...")
        
        for i, bug_data in enumerate(bugs_data, 1):
            bug_number = bug_data.get('bug_number', 'Unknown')
            logger.info(f"Processing bug {i}/{total_bugs}: {bug_number}")
            
            try:
                # Check for duplicates
                logger.debug(f"Checking for duplicate of bug: {bug_number}")
                if duplicate_checker.is_duplicate(bug_number, config['jira']['project_key']):
                    logger.info(f"Bug {bug_number} already exists in Jira. Skipping.")
                    skipped_count += 1
                    continue
                
                # Prepare bug data for Jira with WBS enhancement
                jira_issue_data = prepare_jira_issue_data(bug_data, config, wbs_manager)
                
                if args.dry_run:
                    logger.info(f"DRY RUN: Would create Jira issue for bug {bug_number}")
                    logger.debug(f"Issue data: {jira_issue_data}")
                    created_count += 1
                else:
                    # Create Jira issue
                    logger.info(f"Creating Jira issue for bug {bug_number}")
                    issue_key = jira_integrator.create_issue(jira_issue_data)
                    
                    if issue_key:
                        logger.info(f"Successfully created Jira issue: {issue_key} for bug {bug_number}")
                        created_count += 1
                    else:
                        logger.error(f"Failed to create Jira issue for bug {bug_number}")
                        error_count += 1
                        
            except Exception as e:
                logger.error(f"Error processing bug {bug_number}: {str(e)}")
                error_count += 1
                continue
        
        # Summary report
        logger.info("=" * 50)
        logger.info("PROCESSING SUMMARY")
        logger.info("=" * 50)
        logger.info(f"Total bugs processed: {total_bugs}")
        logger.info(f"Issues created: {created_count}")
        logger.info(f"Issues skipped (duplicates): {skipped_count}")
        logger.info(f"Errors encountered: {error_count}")
        
        if args.dry_run:
            logger.info("NOTE: This was a dry run. No actual issues were created.")
        
        logger.info("Jira Bug Integration System completed successfully")
        
        # Exit with appropriate code
        if error_count > 0:
            sys.exit(1)
        else:
            sys.exit(0)
            
    except KeyboardInterrupt:
        logger.warning("Process interrupted by user")
        sys.exit(130)
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}", exc_info=True)
        sys.exit(1)


def prepare_jira_issue_data(bug_data: Dict[str, Any], config: Dict[str, Any], wbs_manager=None) -> Dict[str, Any]:
    """
    Prepare bug data for Jira issue creation
    
    Args:
        bug_data: Dictionary containing bug information from CSV
        config: Configuration dictionary
        wbs_manager: WBS structure manager instance (optional)
        
    Returns:
        Dictionary formatted for Jira API
    """
    logger = setup_logger()
    
    logger.debug(f"Preparing Jira issue data for bug: {bug_data.get('bug_number')}")
    
    # Get bug template from config
    bug_template = config.get('bug_template', {})
    
    # Enhance template with WBS structure if available
    if wbs_manager:
        bug_template = wbs_manager.enhance_bug_template(bug_data, bug_template)
    jira_config = config.get('jira', {})
    
    # Prepare issue data
    issue_data = {
        'project': {'key': jira_config.get('project_key')},
        'issuetype': {'name': bug_template.get('issue_type', 'Bug')},
        'summary': f"QC ID {bug_data.get('bug_number', 'Unknown')} - {bug_data.get('summary', 'No summary provided')}",
        'description': prepare_description(bug_data, bug_template),
        'priority': {'name': bug_template.get('priority', 'Medium')},
    }
    
    # Add assignee if provided
    assignee = bug_data.get('assign_to', '').strip()
    if assignee and assignee.lower() != 'unassigned':
        issue_data['assignee'] = {'name': assignee}
    elif bug_template.get('default_assignee'):
        issue_data['assignee'] = {'name': bug_template['default_assignee']}
    
    # Add reporter
    reporter = bug_data.get('detected_by', '').strip()
    if reporter:
        issue_data['reporter'] = {'name': reporter}
    elif bug_template.get('default_reporter'):
        issue_data['reporter'] = {'name': bug_template['default_reporter']}
    
    # Add custom fields from template
    custom_fields = bug_template.get('custom_fields', {})
    for field_id, field_value in custom_fields.items():
        issue_data[field_id] = field_value
    
    # Add components if specified
    if bug_template.get('components'):
        issue_data['components'] = [{'name': comp} for comp in bug_template['components']]
    
    # Add labels
    labels = bug_template.get('labels', [])
    labels.append(f"QC-{bug_data.get('bug_number', 'Unknown')}")
    issue_data['labels'] = labels
    
    logger.debug(f"Prepared issue data: {issue_data}")
    
    return issue_data


def prepare_description(bug_data: Dict[str, Any], bug_template: Dict[str, Any]) -> str:
    """
    Prepare detailed description for Jira issue
    
    Args:
        bug_data: Bug information from CSV
        bug_template: Bug template configuration
        
    Returns:
        Formatted description string
    """
    description_parts = []
    
    # Add bug description if available
    if bug_data.get('description'):
        description_parts.append(f"*Bug Description:*\n{bug_data['description']}")
    
    # Add bug details section
    description_parts.append("\n*Bug Details:*")
    description_parts.append(f"• QC ID: {bug_data.get('bug_number', 'Not specified')}")
    description_parts.append(f"• Detected By: {bug_data.get('detected_by', 'Not specified')}")
    description_parts.append(f"• Assigned To: {bug_data.get('assign_to', 'Unassigned')}")
    
    # Add template-specific information
    if bug_template.get('product'):
        description_parts.append(f"• Product: {bug_template['product']}")
    
    if bug_template.get('environment'):
        description_parts.append(f"• Environment: {bug_template['environment']}")
    
    if bug_template.get('reproducible') is not None:
        reproducible = "Yes" if bug_template['reproducible'] else "No"
        description_parts.append(f"• Reproducible: {reproducible}")
    
    # Add additional notes from template
    if bug_template.get('additional_notes'):
        description_parts.append(f"\n*Additional Notes:*\n{bug_template['additional_notes']}")
    
    return "\n".join(description_parts)


if __name__ == '__main__':
    main()
