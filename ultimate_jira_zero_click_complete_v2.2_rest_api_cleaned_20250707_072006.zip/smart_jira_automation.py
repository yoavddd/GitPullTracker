#!/usr/bin/env python3
"""
Smart Jira Automation - Simplified with Working Authentication
Uses Basic Authentication that works with corporate Jira
"""

import os
import json
import logging
import pandas as pd
import requests
from datetime import datetime
from typing import Dict, Any, List
import urllib3
import base64

# Disable SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class SmartJiraAutomation:
    """Smart automation using working Basic Authentication"""
    
    def __init__(self, jira_config: Dict[str, Any]):
        """Initialize with configuration"""
        self.jira_config = jira_config
        self.jira_url = jira_config.get('url', '').rstrip('/')
        self.project_key = jira_config.get('project_key', '16400')
        self.username = os.environ.get('JIRA_USERNAME', jira_config.get('username', ''))
        self.password = os.environ.get('JIRA_PASSWORD', jira_config.get('password', ''))
        
        self.logger = logging.getLogger(__name__)
        self.session = None
        self.connection_method = None
        
    def smart_connect(self) -> bool:
        """Connect using working Basic Authentication method"""
        
        try:
            self.logger.info("Connecting using Basic Authentication")
            
            # Setup session
            self.session = requests.Session()
            self.session.verify = False
            
            # Use Basic Authentication (working method)
            user_pass = f"{self.username}:{self.password}"
            encoded_auth = base64.b64encode(user_pass.encode()).decode()
            
            self.session.headers.update({
                "Authorization": f"Basic {encoded_auth}",
                "Content-Type": "application/json"
            })
            
            # Test connection
            response = self.session.get(f"{self.jira_url}/rest/api/2/myself", timeout=10)
            
            if response.status_code == 200:
                self.connection_method = "Basic Authentication"
                self.logger.info("Successfully connected using Basic Authentication")
                return True
            else:
                self.logger.error(f"Connection failed: HTTP {response.status_code}")
                return False
                
        except Exception as e:
            self.logger.error(f"Connection failed: {e}")
            return False
    
    def fetch_qc_bugs(self) -> List[Dict[str, Any]]:
        """Fetch QC bugs using established connection"""
        if not self.session:
            return []
        
        try:
            # Build JQL query to find QC bugs
            jql = f'project={self.project_key} AND issuetype=Bug AND summary ~ "QC ID"'
            
            # API parameters
            params = {
                'jql': jql,
                'fields': 'key,summary,status,assignee,created,priority,description',
                'maxResults': 1000,
                'startAt': 0
            }
            
            # Make API call
            api_url = f"{self.jira_url}/rest/api/2/search"
            response = self.session.get(api_url, params=params, timeout=30)
            
            if response.status_code == 200:
                data = response.json()
                issues = data.get('issues', [])
                
                bugs = []
                for issue in issues:
                    fields = issue.get('fields', {})
                    
                    # Extract QC number from summary
                    summary = fields.get('summary', '')
                    qc_number = self._extract_qc_number(summary)
                    
                    bug_data = {
                        'key': issue.get('key'),
                        'qc_number': qc_number,
                        'summary': summary,
                        'status': fields.get('status', {}).get('name', ''),
                        'assignee': fields.get('assignee', {}).get('displayName', '') if fields.get('assignee') else '',
                        'created': fields.get('created', ''),
                        'priority': fields.get('priority', {}).get('name', '') if fields.get('priority') else '',
                        'jira_url': f"{self.jira_url}/browse/{issue.get('key')}"
                    }
                    bugs.append(bug_data)
                
                self.logger.info(f"Fetched {len(bugs)} QC bugs")
                return bugs
            else:
                self.logger.error(f"Failed to fetch bugs: HTTP {response.status_code}")
                return []
                
        except Exception as e:
            self.logger.error(f"Error fetching bugs: {e}")
            return []
    
    def _extract_qc_number(self, summary: str) -> str:
        """Extract QC number from issue summary"""
        import re
        
        # Common QC patterns
        patterns = [
            r'QC\s*ID#?\s*(\w+)',
            r'QC\s*#?\s*(\w+)',
            r'ID\s*#?\s*(\w+)',
            r'#(\w+)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, summary, re.IGNORECASE)
            if match:
                return match.group(1)
        
        return ""
    
    def compare_with_csv(self, csv_path: str) -> Dict[str, Any]:
        """Compare Jira bugs with CSV input"""
        
        # Fetch existing bugs
        existing_bugs = self.fetch_qc_bugs()
        existing_qc_numbers = {bug['qc_number'] for bug in existing_bugs if bug['qc_number']}
        
        # Process CSV
        df = pd.read_csv(csv_path)
        csv_bugs = []
        
        for _, row in df.iterrows():
            # Extract QC number from CSV
            qc_number = self._extract_qc_from_csv_row(row)
            if qc_number:
                csv_bugs.append({
                    'qc_number': qc_number,
                    'summary': row.get('Bug summery', row.get('summary', '')),
                    'original_data': row.to_dict()
                })
        
        csv_qc_numbers = {bug['qc_number'] for bug in csv_bugs}
        
        # Find duplicates and new bugs
        duplicates = csv_qc_numbers.intersection(existing_qc_numbers)
        new_bugs = csv_qc_numbers - existing_qc_numbers
        
        return {
            'existing_bugs': existing_bugs,
            'csv_bugs': csv_bugs,
            'duplicates': sorted(list(duplicates)),
            'new_bugs': sorted(list(new_bugs)),
            'duplicate_count': len(duplicates),
            'new_count': len(new_bugs),
            'comparison_timestamp': datetime.now().isoformat()
        }
    
    def _extract_qc_from_csv_row(self, row) -> str:
        """Extract QC number from CSV row"""
        
        # Check common column names
        qc_columns = ['Bug number', 'QC number', 'qc_number', 'bug_number', 'QC ID', 'qc_id']
        
        for col in qc_columns:
            if col in row and pd.notna(row[col]):
                value = str(row[col]).strip()
                if value:
                    return value
        
        # Check all columns for QC patterns
        for col, value in row.items():
            if pd.notna(value):
                value_str = str(value)
                qc_number = self._extract_qc_number(value_str)
                if qc_number:
                    return qc_number
        
        return ""
    
    def generate_reports(self, comparison_result: Dict[str, Any], output_dir: str = ".") -> List[str]:
        """Generate comparison reports"""
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        generated_files = []
        
        # 1. New bugs to create (CSV)
        new_bugs_file = f"{output_dir}/new_bugs_to_create_{timestamp}.csv"
        new_bugs_data = []
        
        for qc_num in comparison_result['new_bugs']:
            csv_bug = next((bug for bug in comparison_result['csv_bugs'] if bug['qc_number'] == qc_num), None)
            if csv_bug:
                new_bugs_data.append(csv_bug['original_data'])
        
        if new_bugs_data:
            pd.DataFrame(new_bugs_data).to_csv(new_bugs_file, index=False)
            generated_files.append(new_bugs_file)
        
        # 2. Duplicates to skip (CSV)
        duplicates_file = f"{output_dir}/duplicates_to_skip_{timestamp}.csv"
        duplicate_data = []
        
        for qc_num in comparison_result['duplicates']:
            csv_bug = next((bug for bug in comparison_result['csv_bugs'] if bug['qc_number'] == qc_num), None)
            if csv_bug:
                duplicate_data.append(csv_bug['original_data'])
        
        if duplicate_data:
            pd.DataFrame(duplicate_data).to_csv(duplicates_file, index=False)
            generated_files.append(duplicates_file)
        
        # 3. Existing bugs (CSV)
        existing_file = f"{output_dir}/existing_jira_bugs_{timestamp}.csv"
        if comparison_result['existing_bugs']:
            pd.DataFrame(comparison_result['existing_bugs']).to_csv(existing_file, index=False)
            generated_files.append(existing_file)
        
        # 4. Summary report (TXT)
        summary_file = f"{output_dir}/comparison_summary_{timestamp}.txt"
        with open(summary_file, 'w') as f:
            f.write("JIRA BUG COMPARISON SUMMARY\n")
            f.write("=" * 50 + "\n")
            f.write(f"Generated: {datetime.now()}\n\n")
            f.write(f"CSV Bugs Processed: {len(comparison_result['csv_bugs'])}\n")
            f.write(f"Existing Jira Bugs: {len(comparison_result['existing_bugs'])}\n")
            f.write(f"New Bugs to Create: {comparison_result['new_count']}\n")
            f.write(f"Duplicates to Skip: {comparison_result['duplicate_count']}\n\n")
            
            f.write("NEW BUGS:\n")
            for qc_num in comparison_result['new_bugs']:
                f.write(f"  - {qc_num}\n")
            
            f.write("\nDUPLICATES:\n")
            for qc_num in comparison_result['duplicates']:
                f.write(f"  - {qc_num}\n")
        
        generated_files.append(summary_file)
        
        return generated_files


def run_smart_automation(config_file: str, csv_file: str) -> Dict[str, Any]:
    """Run smart automation with given configuration"""
    
    # Load configuration
    with open(config_file, 'r') as f:
        config = json.load(f)
    
    # Initialize automation
    automation = SmartJiraAutomation(config['jira'])
    
    # Connect to Jira
    if not automation.smart_connect():
        return {'success': False, 'error': 'Failed to connect to Jira'}
    
    # Compare with CSV
    comparison_result = automation.compare_with_csv(csv_file)
    
    # Generate reports
    generated_files = automation.generate_reports(comparison_result)
    
    return {
        'success': True,
        'comparison_result': comparison_result,
        'generated_files': generated_files
    }


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) != 3:
        print("Usage: python smart_jira_automation_clean.py <config_file> <csv_file>")
        sys.exit(1)
    
    config_file = sys.argv[1]
    csv_file = sys.argv[2]
    
    print("🚀 Smart Jira Automation Starting...")
    result = run_smart_automation(config_file, csv_file)
    
    if result['success']:
        print("✅ Automation completed successfully!")
        print(f"📁 Generated {len(result['generated_files'])} files:")
        for file in result['generated_files']:
            print(f"  - {file}")
    else:
        print(f"❌ Automation failed: {result['error']}")