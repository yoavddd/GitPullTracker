#!/usr/bin/env python3
"""
Quick script to test your Jira credentials
Replace the values below with your actual Jira details
"""

import requests
import json

# REPLACE THESE WITH YOUR ACTUAL VALUES
JIRA_URL = "https://jira.esl.corp.elbit.co.il"  # Your corporate Jira URL
USERNAME = "your-email@domain.com"               # Your email/username
API_TOKEN = "your-api-token-here"                # Your API token
PROJECT_KEY = "TEST"                             # Your project key
VERIFY_SSL = False                               # Set to False for corporate self-signed certificates

def test_jira_connection():
    """Test if Jira credentials work"""
    
    print("Testing Jira connection...")
    print(f"URL: {JIRA_URL}")
    print(f"Username: {USERNAME}")
    print(f"Project: {PROJECT_KEY}")
    print("-" * 50)
    
    # Test basic authentication
    auth_url = f"{JIRA_URL}/rest/api/2/myself"
    
    try:
        # Disable SSL warnings for corporate environments
        if not VERIFY_SSL:
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        
        response = requests.get(
            auth_url,
            auth=(USERNAME, API_TOKEN),
            headers={'Accept': 'application/json'},
            timeout=10,
            verify=VERIFY_SSL
        )
        
        if response.status_code == 200:
            user_info = response.json()
            print("✅ Authentication successful!")
            print(f"   Logged in as: {user_info.get('displayName', 'Unknown')}")
            print(f"   Email: {user_info.get('emailAddress', 'Unknown')}")
            
            # Test project access
            project_url = f"{JIRA_URL}/rest/api/2/project/{PROJECT_KEY}"
            project_response = requests.get(
                project_url,
                auth=(USERNAME, API_TOKEN),
                headers={'Accept': 'application/json'},
                timeout=10,
                verify=VERIFY_SSL
            )
            
            if project_response.status_code == 200:
                project_info = project_response.json()
                print(f"✅ Project access confirmed!")
                print(f"   Project: {project_info.get('name', 'Unknown')}")
                print(f"   Key: {project_info.get('key', 'Unknown')}")
                print("\n🎉 All tests passed! Your credentials are working.")
                return True
            else:
                print(f"❌ Project access failed: {project_response.status_code}")
                print(f"   Error: {project_response.text}")
                return False
                
        else:
            print(f"❌ Authentication failed: {response.status_code}")
            print(f"   Error: {response.text}")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Connection error: {e}")
        return False

if __name__ == "__main__":
    if JIRA_URL == "https://your-domain.atlassian.net":
        print("⚠️  Please edit this file and replace the placeholder values with your actual Jira details!")
        print("\nYou need to update:")
        print("- JIRA_URL: Your Jira instance URL")
        print("- USERNAME: Your email address") 
        print("- API_TOKEN: Your API token from Atlassian")
        print("- PROJECT_KEY: Your project key (like 'TEST', 'BUG', etc.)")
    else:
        test_jira_connection()