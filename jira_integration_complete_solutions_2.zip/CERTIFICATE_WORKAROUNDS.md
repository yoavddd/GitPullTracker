# Jira Certificate Trust Workarounds

## Problem
Python doesn't trust your corporate Jira SSL certificate, preventing direct API access.

## Solutions Available

### 1. 🌐 **Web Interface Solution (Recommended)**
**Files Created:**
- `jira_bugs_report.html` - Clickable links to create bugs
- `jira_import.csv` - CSV for Jira's import feature
- `jira_rest_calls.txt` - cURL commands

**How it works:**
- Opens your browser with pre-filled Jira forms
- No certificate issues since your browser already trusts the certificates
- One-click bug creation

**Usage:**
```bash
python jira_web_interface.py
# Opens jira_bugs_report.html in your browser
```

### 2. 🔒 **SSL Bypass Method**
**File:** `ssl_bypass_auth.py`

**How it works:**
- Completely disables SSL certificate verification
- Forces Python to accept any certificate
- Direct API access without trust issues

**Usage:**
```bash
python main.py --csv sample_data/bugs_input.csv --config config/jira_config.json --ssl-bypass
```

### 3. 📁 **CSV Import Method**
**File:** `jira_import.csv`

**How it works:**
- Create CSV file in Jira's import format
- Use Jira's built-in CSV import feature
- No API calls needed

**Steps:**
1. Open `jira_import.csv`
2. Go to Jira → System → External System Import
3. Upload the CSV file
4. Map fields and import

### 4. 🖱️ **Manual cURL Commands**
**File:** `jira_rest_calls.txt`

**How it works:**
- Pre-generated cURL commands
- Run from command line or tools like Postman
- Bypasses Python certificate issues

**Usage:**
```bash
# Edit the file to add your credentials, then:
bash jira_rest_calls.txt
```

### 5. 🌍 **Browser Extension Method**
Create a simple browser extension or bookmarklet that:
- Reads CSV data
- Auto-fills Jira forms
- Works entirely in browser

## Quick Start

### Option A: Web Interface (Easiest)
1. Open `jira_bugs_report.html` in your browser
2. Click "Create in Jira" for each bug
3. Review and submit in Jira

### Option B: CSV Import (No coding)
1. Go to Jira → System → External System Import
2. Upload `jira_import.csv`
3. Map fields and import all bugs at once

### Option C: SSL Bypass (If you want automation)
1. Edit your config file to use your real Jira URL
2. Run: `python main.py --ssl-bypass --dry-run`
3. Remove `--dry-run` when ready

## Certificate Trust Solutions

If you want to fix the certificate issue permanently:

### Windows:
```cmd
# Add certificate to Windows trust store
certlm.msc
# Import your corporate certificate
```

### Python Environment:
```bash
# Add certificate to Python's certificate bundle
pip install certifi
python -m certifi
# Add your certificate to the bundle
```

### Environment Variable:
```bash
# Disable SSL verification (not recommended for production)
export PYTHONHTTPSVERIFY=0
```

## Recommendation

Start with the **Web Interface Solution** (`jira_bugs_report.html`). It's the safest and requires no certificate configuration. Your browser already trusts your corporate certificates, so this will work immediately.