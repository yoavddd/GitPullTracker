"""
Test Browser Session-based Jira Authentication
"""

import logging
from browser_session_auth import BrowserSessionJiraIntegrator

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)s | %(message)s'
)

def test_browser_authentication():
    """Test browser session authentication with your corporate Jira"""
    
    # Configuration for your corporate Jira
    jira_config = {
        'url': 'https://jira.esl.corp.elbit.co.il',
        'username': 'your-corporate-username',  # Replace with your username
        'password': 'your-corporate-password',  # Replace with your password
        'project_key': 'YOUR_PROJECT_KEY',      # Replace with your project key
        'verify_ssl': False  # Set to True if you have proper SSL certificates
    }
    
    print("=== Testing Browser Session-based Jira Authentication ===")
    print(f"Jira URL: {jira_config['url']}")
    print(f"Username: {jira_config['username']}")
    print("Password: [HIDDEN]")
    print("SSL Verification:", jira_config['verify_ssl'])
    print()
    
    try:
        # Create integrator
        integrator = BrowserSessionJiraIntegrator(jira_config)
        
        print("1. Attempting browser session authentication...")
        if integrator.authenticate():
            print("✅ Authentication successful!")
            
            print("\n2. Testing project access...")
            project_info = integrator.get_project_info(jira_config['project_key'])
            if project_info:
                print(f"✅ Project access successful!")
                print(f"Project Name: {project_info.get('name', 'Unknown')}")
                print(f"Project Key: {project_info.get('key', 'Unknown')}")
                print(f"Project Lead: {project_info.get('lead', {}).get('displayName', 'Unknown')}")
            else:
                print("❌ Project access failed - check your project key")
            
            print("\n3. Testing issue search...")
            issues = integrator.search_issues(f"project = {jira_config['project_key']}", max_results=5)
            print(f"✅ Found {len(issues)} issues in project")
            
            if issues:
                print("Sample issues:")
                for issue in issues[:3]:
                    key = issue.get('key', 'Unknown')
                    summary = issue.get('fields', {}).get('summary', 'No summary')
                    print(f"  - {key}: {summary}")
            
            print("\n4. Ready for production use!")
            print("✅ You can now run the main system with:")
            print(f"python main.py --csv sample_data/bugs_input.csv --config config/selenium_jira_config.json --use-selenium --dry-run")
            
        else:
            print("❌ Authentication failed")
            print("\nTroubleshooting tips:")
            print("1. Check your username and password")
            print("2. Verify the Jira URL is correct")
            print("3. Make sure you can log in manually in a browser")
            print("4. Check if your account has proper permissions")
            print("5. Try with SSL verification enabled if your certificates are valid")
            
    except Exception as e:
        print(f"❌ Test failed with error: {e}")
        print("\nPlease check:")
        print("1. Your credentials are correct")
        print("2. Network connectivity to Jira")
        print("3. Jira server is accessible")

if __name__ == "__main__":
    test_browser_authentication()