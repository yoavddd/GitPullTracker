# Configuration File Explanation (config.json)

## Main Sections

### 1. TFS Section - Azure DevOps Team Foundation Server Settings
```json
"tfs": {
    "base_url": "http://tfs1:8080/tfs/SilverArrowCollection",
    "project": "VMSC_App", 
    "repository": "IAFHalcon",
    "token": "o5466gh4ngujsi7iczdpxusqrmbqe5nygppnz5eoorkq2jmcbt2q"
}
```

**What each field means:**
- `base_url`: Your TFS server address - the main URL where your Azure DevOps server is hosted
- `project`: The name of your project in TFS (VMSC_App in your case)
- `repository`: The specific Git repository name within that project (IAFHalcon)
- `token`: Your Personal Access Token for authenticating with TFS - this allows the app to read pull request data

### 2. Repository Section - Local Git Repository Path
```json
"repository": {
    "local_path": "C:\\Dev\\new3_class\\IAFHalcon"
}
```

**What it means:**
- `local_path`: The folder path on your computer where your Git repository is located
- This is used for local Git analysis when TFS API is not available or when you choose local analysis mode

### 3. Submodules Section - Configuration for Each Submodule
```json
"submodules": {
    "IAFHalcon_submodule_1": {
        "base_url": "http://tfs1:8080/tfs/SilverArrowCollection",
        "project": "VMSC_App",
        "repository": "IAFHalcon_submodule_1", 
        "token": "o5466gh4ngujsi7iczdpxusqrmbqe5nygppnz5eoorkq2jmcbt2q"
    }
}
```

**What it means:**
- Each submodule gets its own configuration block
- `IAFHalcon_submodule_1`: This is the name/identifier of your submodule
- The fields inside are the same as the main TFS section but specific to that submodule's repository
- If you have multiple submodules, add more blocks with different names

### 4. Default Commits Section - Your Commit Range
```json
"default_commits": {
    "from": "ff54563f82eb31d22ecb78d4263434a471bee70f",
    "to": "0e6a4bef3cbbfa0d79d3cd9fcee81b78d36e2ed7"
}
```

**What it means:**
- `from`: The starting commit hash - where your analysis begins
- `to`: The ending commit hash - where your analysis ends
- These are your actual commit hashes that you provided
- The app will find all pull requests that happened between these two points

### 5. Logging Section - How Much Detail in Logs
```json
"logging": {
    "level": "DEBUG",
    "format": "%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s"
}
```

**What it means:**
- `level`: How much detail you want in the logs (DEBUG shows everything, INFO shows less)
- `format`: How the log messages are structured (includes timestamp, function name, line number)

### 6. Analysis Options Section - Additional Settings
```json
"analysis_options": {
    "include_merge_commits": true,
    "extract_pr_info_from_commits": true,
    "use_tfs_api": true,
    "fallback_to_local_analysis": true,
    "max_commits_per_submodule": 100
}
```

**What each option means:**
- `include_merge_commits`: Whether to look at merge commits (usually yes for PR analysis)
- `extract_pr_info_from_commits`: Try to get PR info from commit messages
- `use_tfs_api`: Whether to use TFS API (true = yes, false = no)
- `fallback_to_local_analysis`: If TFS fails, try local Git analysis
- `max_commits_per_submodule`: Limit how many commits to analyze per submodule

## How to Customize for Your Environment

1. **Change TFS URL**: Update `base_url` to match your TFS server
2. **Update Project/Repository**: Change `project` and `repository` to match your names
3. **Add Your Token**: Replace `token` with your actual Personal Access Token
4. **Set Local Path**: Update `local_path` to where your repository is on your computer
5. **Configure Submodules**: Add entries for each submodule you have
6. **Set Commit Range**: Update `from` and `to` with your actual commit hashes