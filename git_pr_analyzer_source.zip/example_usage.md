# Git PR Analyzer - Usage Examples

## Basic Usage

The application analyzes pull requests between two commits or tags in Git repositories with submodules.

### Command Line Usage

```bash
# Basic analysis with your commits
python main.py --from-commit ff54563f82eb31d22ecb78d4263434a471bee70f --to-commit 0e6a4bef3cbbfa0d79d3cd9fcee81b78d36e2ed7

# With custom configuration file
python main.py --config my_config.json --from-commit ff54563f --to-commit 0e6a4be

# Generate only JSON output with debug logging
python main.py --from-commit ff54563f --to-commit 0e6a4be --output-format json --log-level DEBUG

# Custom output directory
python main.py --from-commit ff54563f --to-commit 0e6a4be --output-dir my_reports

# Use only TFS analysis (no local Git)
python main.py --from-commit ff54563f --to-commit 0e6a4be --analysis-mode tfs

# Use only local Git analysis (no TFS API)
python main.py --from-commit ff54563f --to-commit 0e6a4be --analysis-mode local

# Use both TFS and local analysis (default)
python main.py --from-commit ff54563f --to-commit 0e6a4be --analysis-mode both
```

## Configuration File (config.json)

The application reads settings from a JSON configuration file:

```json
{
    "tfs": {
        "base_url": "http://tfs1:8080/tfs/SilverArrowCollection",
        "project": "VMSC_App",
        "repository": "IAFHalcon",
        "token": "your_tfs_token_here"
    },
    "repository": {
        "local_path": "C:\\Dev\\new3_class\\IAFHalcon"
    },
    "submodules": {
        "submodule_name": {
            "base_url": "http://tfs1:8080/tfs/SilverArrowCollection",
            "project": "VMSC_App",
            "repository": "submodule_repo_name",
            "token": "your_tfs_token_here"
        }
    },
    "default_commits": {
        "from": "ff54563f82eb31d22ecb78d4263434a471bee70f",
        "to": "0e6a4bef3cbbfa0d79d3cd9fcee81b78d36e2ed7"
    },
    "logging": {
        "level": "DEBUG",
        "format": "%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s"
    }
}
```

## Analysis Modes

You can choose how the application analyzes your repository:

### --analysis-mode tfs (TFS API Only)
- Uses only Azure DevOps TFS to find pull requests
- Gets complete PR information (title, author, dates, links)
- Works without local repository access
- Best when you only want official TFS data

### --analysis-mode local (Local Git Only)  
- Analyzes only local Git history for merge commits
- Extracts PR information from commit messages
- Requires local repository access
- Best when TFS is not available or you want local-only analysis

### --analysis-mode both (Default - TFS Primary with Local Fallback)
- Tries TFS API first, falls back to local Git if needed
- Combines both approaches for complete coverage
- Most comprehensive analysis
- Recommended for most use cases

## Output Files

The application generates multiple report formats:

### JSON Report (`pr_analysis_*.json`)
Complete data in JSON format for programmatic use:
```json
[
  {
    "project_type": "Super Project",
    "project_name": "IAFHalcon",
    "pr_id": "12345",
    "title": "Feature: Add new authentication module",
    "source_branch": "refs/heads/feature/auth",
    "target_branch": "refs/heads/main",
    "created_date": "2025-06-20T10:30:00Z",
    "completed_date": "2025-06-21T14:45:00Z",
    "status": "completed",
    "author": "John Doe",
    "url": "http://tfs1:8080/tfs/SilverArrowCollection/VMSC_App/_git/IAFHalcon/pullrequest/12345"
  }
]
```

### CSV Report (`pr_analysis_*.csv`)
Tabular format for spreadsheet analysis with columns:
- Project Type, Project Name, PR ID, Title, Author, Created Date, Status, Source Branch, Target Branch

### HTML Report (`pr_analysis_*.html`)
Visual web-based report with:
- Summary statistics dashboard
- Sortable table with all PR details
- Color-coded project types
- Clickable PR links

### Summary Report (`pr_analysis_*_summary.json`)
Analysis statistics:
- Total pull requests found
- Breakdown by project type (Super Project vs Submodules)
- Date ranges and analysis metadata

## Logging

The application provides extensive logging:

- **Console Output**: Real-time progress and key information
- **Log Files**: Detailed logs saved to `logs/` directory
- **Debug Mode**: Verbose logging for troubleshooting

Log levels: DEBUG, INFO, WARNING, ERROR

## Submodule Support

The application automatically:
1. Detects all submodules in the super project
2. Tracks commit changes in each submodule between the specified range
3. Fetches PR data for each submodule from TFS (if configured)
4. Provides fallback local analysis if TFS is unavailable

## Error Handling

The application gracefully handles:
- Missing local repository (falls back to TFS-only analysis)
- Network connectivity issues (retry with exponential backoff)
- Invalid commit hashes or tags
- Missing submodule configurations
- Authentication failures

## Performance

- Processes large repositories efficiently
- Batches API requests to minimize TFS load
- Provides progress tracking for long-running operations
- Caches results where possible