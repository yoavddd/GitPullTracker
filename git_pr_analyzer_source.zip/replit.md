# Git PR Analyzer

## Overview

This is a Python-based Git repository analyzer that focuses on analyzing pull requests and commit changes between different commits or tags in Git repositories with submodule support. The application integrates with Azure DevOps TFS for additional repository management capabilities and generates comprehensive reports in multiple formats.

## System Architecture

The application follows a modular Python architecture with clear separation of concerns:

**Core Components:**
- **Configuration Management**: Centralized JSON-based configuration handling
- **Git Analysis Engine**: Git repository operations and commit analysis using GitPython
- **TFS Integration**: Azure DevOps TFS API client for extended repository management
- **Report Generation**: Multi-format report output (JSON, CSV, DataFrame support)
- **Utility Layer**: Common logging and helper functions

**Technology Stack:**
- Python 3.11+ runtime environment
- GitPython for Git operations
- Requests for HTTP API interactions
- Pandas for data manipulation and CSV generation
- JSON for configuration and data serialization

## Key Components

### Configuration Manager (`src/config_manager.py`)
- Handles JSON configuration file loading and validation
- Manages TFS connection settings, repository paths, and logging configuration
- Provides centralized access to application settings including default commit ranges and submodule configurations

### Git Analyzer (`src/git_analyzer.py`)
- Core Git repository analysis functionality
- Analyzes commit ranges between specified commits or tags
- Handles Git repository initialization and operations
- Provides commit comparison and change tracking capabilities

### TFS Client (`src/tfs_client.py`)
- Azure DevOps TFS API integration
- Handles authentication using Personal Access Tokens
- Provides repository management capabilities through TFS REST API
- Supports project-specific repository operations

### Report Generator (`src/report_generator.py`)
- Multi-format report generation (JSON, CSV)
- Optional Pandas integration for enhanced data manipulation
- Configurable output directory management
- Structured data export capabilities

### Main Application (`main.py`)
- Command-line interface with argument parsing
- Orchestrates all components for end-to-end analysis
- Supports configurable commit ranges and output formats
- Provides help documentation and usage examples

## Data Flow

1. **Configuration Loading**: Application starts by loading configuration from JSON file containing TFS settings, repository paths, and default parameters
2. **Repository Analysis**: Git analyzer examines the specified repository and analyzes commits between the provided range
3. **TFS Integration**: Optional TFS client interaction for additional repository metadata and pull request information
4. **Report Generation**: Analysis results are processed and exported in the requested format (JSON, CSV, or both)
5. **Output Management**: Generated reports are saved to the configured output directory with timestamp-based naming

## External Dependencies

**Required Python Packages:**
- `GitPython>=3.1.44`: Git repository operations and analysis
- `pandas>=2.3.0`: Data manipulation and CSV generation
- `requests>=2.32.4`: HTTP client for TFS API interactions

**External Services:**
- Azure DevOps TFS: Repository management and pull request tracking
- Git repositories: Local or remote Git repositories for analysis

**System Requirements:**
- Python 3.11+ runtime environment
- Git command-line tools (required by GitPython)
- Network access for TFS API calls (when using TFS integration)

## Deployment Strategy

**Development Environment:**
- Replit-based development with Nix package management
- Automatic dependency installation via pyproject.toml and uv.lock
- Parallel workflow execution for development and testing

**Configuration Management:**
- JSON-based configuration files for environment-specific settings
- Separate configuration for development, staging, and production environments
- Token-based authentication for secure TFS access

**Output Management:**
- Structured output directory with .gitkeep files for version control
- Separate logging directory for application logs
- Configurable report formats and naming conventions

## Recent Changes

- **June 30, 2025**: Deployment fixes applied:
  - Converted command-line tool to web application with Flask interface
  - Removed --help flag from run command to prevent immediate exit
  - Added proper web interface for running analyses and downloading reports
  - Configured TFS_TOKEN environment variable for secure authentication
  - Created production-ready server configuration with Gunicorn support
  - Web application now serves on port 5000 with proper HTTP endpoints

- **June 23, 2025**: Complete Git PR Analyzer application created with:
  - Full TFS Azure DevOps integration for pull request analysis
  - Local Git repository analysis with submodule support  
  - Multi-format report generation (JSON, CSV, HTML)
  - Comprehensive error handling and logging system
  - Command-line interface with flexible configuration
  - Support for both API-based and local Git analysis approaches

## User Preferences

- Preferred communication style: Simple, everyday language
- Requires extensive logging throughout the application
- Needs dual analysis approach: TFS API primary, local Git fallback
- Configuration-driven setup with JSON input files
- Output in multiple formats for different use cases