#!/usr/bin/env python3
"""
Web Interface for Git PR Analyzer
Provides a simple web interface to run the Git PR analysis tool
"""

import os
import json
import subprocess
from datetime import datetime
from pathlib import Path
from flask import Flask, render_template, request, jsonify, send_file, redirect, url_for
import logging

# Setup basic logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)

# Ensure output directory exists
output_dir = Path("output")
output_dir.mkdir(exist_ok=True)

@app.route('/')
def index():
    """Main page with analysis form"""
    try:
        # Read default configuration
        with open('config.json', 'r') as f:
            config = json.load(f)
        
        default_from = config.get('default_commits', {}).get('from', '')
        default_to = config.get('default_commits', {}).get('to', '')
        
        return render_template('index.html', 
                             default_from=default_from, 
                             default_to=default_to)
    except Exception as e:
        logger.error(f"Error loading config: {e}")
        return render_template('index.html', 
                             default_from='', 
                             default_to='',
                             error="Configuration file not found or invalid")

@app.route('/analyze', methods=['POST'])
def analyze():
    """Run the analysis"""
    try:
        # Get form data
        from_commit = request.form.get('from_commit', '').strip()
        to_commit = request.form.get('to_commit', '').strip()
        analysis_mode = request.form.get('analysis_mode', 'both')
        output_format = request.form.get('output_format', 'both')
        
        if not from_commit or not to_commit:
            return jsonify({'error': 'Both from and to commits are required'}), 400
        
        # Build command
        cmd = [
            'python', 'main.py',
            '--from-commit', from_commit,
            '--to-commit', to_commit,
            '--analysis-mode', analysis_mode,
            '--output-format', output_format,
            '--log-level', 'INFO'
        ]
        
        logger.info(f"Running analysis command: {' '.join(cmd)}")
        
        # Run the analysis
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        
        if result.returncode == 0:
            # Find generated files
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            base_pattern = f"pr_analysis_{from_commit[:8]}_{to_commit[:8]}"
            
            files = []
            for file_path in output_dir.glob(f"{base_pattern}*"):
                if file_path.is_file():
                    files.append({
                        'name': file_path.name,
                        'path': str(file_path),
                        'size': file_path.stat().st_size
                    })
            
            return jsonify({
                'success': True,
                'message': 'Analysis completed successfully',
                'output': result.stdout,
                'files': files
            })
        else:
            logger.error(f"Analysis failed: {result.stderr}")
            return jsonify({
                'error': 'Analysis failed',
                'details': result.stderr,
                'output': result.stdout
            }), 500
            
    except subprocess.TimeoutExpired:
        return jsonify({'error': 'Analysis timed out after 5 minutes'}), 500
    except Exception as e:
        logger.error(f"Error running analysis: {e}")
        return jsonify({'error': f'Server error: {str(e)}'}), 500

@app.route('/download/<filename>')
def download_file(filename):
    """Download generated report files"""
    try:
        file_path = output_dir / filename
        if file_path.exists() and file_path.is_file():
            return send_file(file_path, as_attachment=True)
        else:
            return "File not found", 404
    except Exception as e:
        logger.error(f"Error downloading file: {e}")
        return f"Error downloading file: {str(e)}", 500

@app.route('/files')
def list_files():
    """List available report files"""
    try:
        files = []
        for file_path in output_dir.glob("*"):
            if file_path.is_file():
                files.append({
                    'name': file_path.name,
                    'size': file_path.stat().st_size,
                    'modified': datetime.fromtimestamp(file_path.stat().st_mtime).strftime('%Y-%m-%d %H:%M:%S')
                })
        
        files.sort(key=lambda x: x['modified'], reverse=True)
        return jsonify({'files': files})
    except Exception as e:
        logger.error(f"Error listing files: {e}")
        return jsonify({'error': f'Error listing files: {str(e)}'}), 500

@app.route('/download-source')
def download_source():
    """Download all Python source files as a zip"""
    try:
        import subprocess
        
        # Run the download script to create a fresh zip
        result = subprocess.run(['python', 'download_files.py'], 
                              capture_output=True, text=True)
        
        if result.returncode == 0:
            # Find the most recent zip file
            import glob
            zip_files = glob.glob('output/git_pr_analyzer_python_files_*.zip')
            if zip_files:
                latest_zip = max(zip_files, key=os.path.getctime)
                return send_file(latest_zip, as_attachment=True, 
                               download_name='git_pr_analyzer_source.zip')
        
        return "Error creating source zip file", 500
        
    except Exception as e:
        logger.error(f"Error creating source download: {e}")
        return f"Error: {str(e)}", 500

@app.route('/health')
def health_check():
    """Health check endpoint"""
    return jsonify({'status': 'healthy', 'timestamp': datetime.now().isoformat()})

if __name__ == '__main__':
    # Ensure templates directory exists
    templates_dir = Path("templates")
    templates_dir.mkdir(exist_ok=True)
    
    # Run the Flask app
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)