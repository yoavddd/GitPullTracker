# Git PR Analyzer

A Python application that analyzes pull requests between two commits or tags in Git repositories with submodule support. The tool integrates with Azure DevOps TFS to provide comprehensive PR tracking and generates detailed reports in multiple formats.

## Features

- **Dual Analysis Mode**: TFS API integration with local Git fallback
- **Submodule Support**: Automatically analyzes all submodules in the repository
- **Multiple Output Formats**: JSON, CSV, and HTML reports
- **Comprehensive Logging**: Detailed logs with configurable levels
- **Flexible Configuration**: JSON-based configuration with environment variable support
- **Error Resilience**: Graceful handling of network issues and missing repositories

## Quick Start

1. **Configure your settings** in `config.json`:
```json
{
    "tfs": {
        "base_url": "http://tfs1:8080/tfs/SilverArrowCollection",
        "project": "VMSC_App",
        "repository": "IAFHalcon",
        "token": "your_tfs_token"
    },
    "repository": {
        "local_path": "C:\\Dev\\new3_class\\IAFHalcon"
    }
}
```

2. **Run the analysis**:
```bash
python main.py --from-commit ff54563f82eb31d22ecb78d4263434a471bee70f --to-commit 0e6a4bef3cbbfa0d79d3cd9fcee81b78d36e2ed7
```

3. **View results** in the `output/` directory:
   - HTML report for visual analysis
   - CSV for spreadsheet import
   - JSON for programmatic use

## Installation

```bash
pip install GitPython requests pandas
```

## Command Line Options

```
--from-commit     Source commit hash or tag (required)
--to-commit       Target commit hash or tag (required)
--config          Configuration file path (default: config.json)
--output-format   Report format: json, csv, or both (default: both)
--output-dir      Output directory (default: output)
--log-level       Logging level: DEBUG, INFO, WARNING, ERROR
--analysis-mode   Analysis mode: tfs, local, or both (default: both)
```

## Analysis Modes

### TFS API Analysis (`--analysis-mode tfs`)
- Queries Azure DevOps for pull requests between commits
- Provides complete PR metadata and links
- Works without local repository access
- Best for official TFS data only

### Local Git Analysis (`--analysis-mode local`)
- Analyzes local Git history for merge commits
- Extracts PR information from commit messages
- Requires local repository access
- Best when TFS is unavailable

### Combined Analysis (`--analysis-mode both`) - Default
- Uses TFS API first with local Git fallback
- Provides most comprehensive results
- Combines official TFS data with local commit analysis
- Recommended for complete coverage

## Output Reports

### HTML Report
Interactive web-based report with:
- Summary statistics dashboard
- Sortable table with PR details
- Color-coded project types
- Direct links to pull requests

### CSV Report
Tabular data for spreadsheet analysis with all PR details including project type, author, dates, and branch information.

### JSON Report
Complete structured data for programmatic processing and integration with other tools.

## Configuration

The application supports:
- Environment variable substitution (`${VAR_NAME}`)
- Per-submodule TFS configuration
- Flexible logging configuration
- Default commit ranges for repeated analysis

## Project Structure

```
├── src/
│   ├── config_manager.py    # Configuration handling
│   ├── git_analyzer.py      # Git operations and analysis
│   ├── tfs_client.py        # Azure DevOps TFS integration
│   ├── report_generator.py  # Multi-format report generation
│   └── utils.py             # Common utilities and logging
├── logs/                    # Application logs
├── output/                  # Generated reports
├── config.json             # Configuration file
└── main.py                 # Application entry point
```

## Logging

Comprehensive logging system with:
- Console output for real-time progress
- File logging with rotation
- Configurable levels and formats
- External library noise reduction

Log files are automatically created in `logs/` with timestamps for easy tracking.