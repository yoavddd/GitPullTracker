#!/usr/bin/env python3
"""
Download All Python Files
Creates a zip archive of all Python files in the project
"""

import os
import zipfile
from pathlib import Path
from datetime import datetime

def create_python_files_zip():
    """Create a zip file containing all Python files"""
    
    # Get current directory
    project_dir = Path('.')
    
    # Create output directory if it doesn't exist
    output_dir = Path('output')
    output_dir.mkdir(exist_ok=True)
    
    # Create zip filename with timestamp
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    zip_filename = output_dir / f'git_pr_analyzer_python_files_{timestamp}.zip'
    
    # Find all Python files
    python_files = []
    
    # Main directory Python files
    for py_file in project_dir.glob('*.py'):
        if py_file.is_file():
            python_files.append(py_file)
    
    # Source directory Python files
    src_dir = project_dir / 'src'
    if src_dir.exists():
        for py_file in src_dir.glob('*.py'):
            if py_file.is_file():
                python_files.append(py_file)
    
    # Configuration and documentation files
    config_files = ['config.json', 'replit.md', 'README.md', 'DEPLOYMENT.md', 
                   'example_usage.md', 'config_explanation.md']
    
    for config_file in config_files:
        config_path = project_dir / config_file
        if config_path.exists():
            python_files.append(config_path)
    
    # Templates directory
    templates_dir = project_dir / 'templates'
    if templates_dir.exists():
        for template_file in templates_dir.glob('*'):
            if template_file.is_file():
                python_files.append(template_file)
    
    # Create the zip file
    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for file_path in python_files:
            # Add file to zip with relative path
            arcname = str(file_path.relative_to(project_dir))
            zipf.write(file_path, arcname)
            print(f"Added: {arcname}")
    
    print(f"\nZip file created: {zip_filename}")
    print(f"Total files: {len(python_files)}")
    print(f"File size: {zip_filename.stat().st_size} bytes")
    
    return str(zip_filename)

if __name__ == '__main__':
    zip_file = create_python_files_zip()
    print(f"\nDownload the zip file: {zip_file}")