#!/usr/bin/env python3
"""
Git Repository Pull Request Analyzer
Main entry point for analyzing pull requests between commits/tags in Git repositories with submodules
"""

import argparse
import logging
import sys
from pathlib import Path
from datetime import datetime

from src.config_manager import ConfigManager
from src.git_analyzer import GitAnalyzer
from src.tfs_client import TFSClient
from src.report_generator import ReportGenerator
from src.utils import setup_logging


def parse_arguments():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(
        description="Analyze Git repositories with submodules to track pull requests between commits/tags"
    )
    
    parser.add_argument(
        "--config",
        type=str,
        default="config.json",
        help="Path to configuration JSON file (default: config.json)"
    )
    
    parser.add_argument(
        "--from-commit",
        type=str,
        required=True,
        help="Source commit hash or tag"
    )
    
    parser.add_argument(
        "--to-commit",
        type=str,
        required=True,
        help="Target commit hash or tag"
    )
    
    parser.add_argument(
        "--output-format",
        choices=["json", "csv", "both"],
        default="both",
        help="Output format for results (default: both)"
    )
    
    parser.add_argument(
        "--output-dir",
        type=str,
        default="output",
        help="Output directory for results (default: output)"
    )
    
    parser.add_argument(
        "--log-level",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default="INFO",
        help="Logging level (default: INFO)"
    )
    
    parser.add_argument(
        "--analysis-mode",
        choices=["tfs", "local", "both"],
        default="both",
        help="Analysis mode: tfs (TFS API only), local (local Git only), both (TFS primary with local fallback) (default: both)"
    )
    
    return parser.parse_args()


def main():
    """Main application entry point"""
    args = parse_arguments()
    
    # Setup logging
    log_file = f"logs/git_pr_analyzer_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
    logger = setup_logging(args.log_level, log_file)
    
    logger.info("=" * 60)
    logger.info("Git Repository Pull Request Analyzer Started")
    logger.info("=" * 60)
    logger.info(f"Configuration file: {args.config}")
    logger.info(f"From commit/tag: {args.from_commit}")
    logger.info(f"To commit/tag: {args.to_commit}")
    logger.info(f"Output format: {args.output_format}")
    logger.info(f"Output directory: {args.output_dir}")
    logger.info(f"Analysis mode: {args.analysis_mode}")
    
    try:
        # Load configuration
        logger.info("Loading configuration...")
        config_manager = ConfigManager(args.config)
        config = config_manager.load_config()
        logger.info("Configuration loaded successfully")
        
        # Initialize components based on analysis mode
        repo_path = Path(config['repository']['local_path'])
        git_analyzer = None
        git_analysis = None
        tfs_client = None
        
        # Initialize Git analyzer if needed and available
        if args.analysis_mode in ["local", "both"]:
            if repo_path.exists() and (repo_path / '.git').exists():
                logger.info("Initializing Git analyzer...")
                git_analyzer = GitAnalyzer(config['repository']['local_path'])
                logger.info("Git analyzer initialized")
            else:
                if args.analysis_mode == "local":
                    raise ValueError("Local analysis mode selected but repository not available locally")
                logger.warning("Local repository not available, using TFS API only")
        
        # Initialize TFS client if needed
        if args.analysis_mode in ["tfs", "both"]:
            logger.info("Initializing TFS client...")
            tfs_client = TFSClient(
                base_url=config['tfs']['base_url'],
                token=config['tfs']['token'],
                project=config['tfs']['project'],
                repository=config['tfs']['repository']
            )
            logger.info("TFS client initialized")
        
        # Analyze Git repository and submodules based on mode
        git_analysis = {
            'submodules': [],
            'commits': [],
            'merge_commits': []
        }
        
        if args.analysis_mode in ["local", "both"] and git_analyzer is not None:
            logger.info("Analyzing Git repository and submodules...")
            git_analysis = git_analyzer.analyze_commits_range(
                from_commit=args.from_commit,
                to_commit=args.to_commit
            )
            logger.info(f"Found {len(git_analysis['submodules'])} submodules to analyze")
        else:
            if args.analysis_mode == "local":
                logger.warning("Local analysis requested but Git analyzer not available")
            else:
                logger.info("Skipping local Git analysis based on selected mode")
        
        # Get pull requests from TFS for super project if TFS mode is enabled
        super_project_prs = []
        if args.analysis_mode in ["tfs", "both"] and tfs_client is not None:
            logger.info("Fetching pull requests from TFS for super project...")
            super_project_prs = tfs_client.get_pull_requests_between_commits(
                from_commit=args.from_commit,
                to_commit=args.to_commit
            )
            logger.info(f"Found {len(super_project_prs)} pull requests for super project")
        else:
            if args.analysis_mode == "tfs":
                logger.warning("TFS analysis requested but TFS client not available")
            else:
                logger.info("Skipping TFS analysis for super project based on selected mode")
        
        # Collect all pull request data
        all_pr_data = []
        
        # Add super project PRs
        for pr in super_project_prs:
            all_pr_data.append({
                'project_type': 'Super Project',
                'project_name': config['tfs']['repository'],
                'submodule_path': '',
                'pr_id': pr['pullRequestId'],
                'title': pr['title'],
                'source_branch': pr['sourceRefName'],
                'target_branch': pr['targetRefName'],
                'created_date': pr['creationDate'],
                'completed_date': pr.get('closedDate', ''),
                'status': pr['status'],
                'author': pr['createdBy']['displayName'],
                'url': pr['url']
            })
        
        # Analyze submodules
        for submodule_info in git_analysis['submodules']:
            submodule_name = submodule_info['name']
            submodule_path = submodule_info['path']
            
            logger.info(f"Analyzing submodule: {submodule_name}")
            
            try:
                # Analyze submodule commits if local analysis is enabled
                submodule_analysis = None
                if args.analysis_mode in ["local", "both"]:
                    try:
                        submodule_analyzer = GitAnalyzer(submodule_path)
                        submodule_analysis = submodule_analyzer.analyze_commits_range(
                            from_commit=submodule_info['from_commit'],
                            to_commit=submodule_info['to_commit']
                        )
                        logger.debug(f"Local analysis completed for submodule: {submodule_name}")
                    except Exception as e:
                        logger.warning(f"Local analysis failed for submodule {submodule_name}: {e}")
                
                # Try to get TFS data for submodule if TFS analysis is enabled
                if args.analysis_mode in ["tfs", "both"]:
                    submodule_tfs_config = config.get('submodules', {}).get(submodule_name, {})
                    if submodule_tfs_config:
                        logger.info(f"Fetching TFS data for submodule: {submodule_name}")
                        try:
                            submodule_tfs_client = TFSClient(
                                base_url=submodule_tfs_config.get('base_url', config['tfs']['base_url']),
                                token=submodule_tfs_config.get('token', config['tfs']['token']),
                                project=submodule_tfs_config.get('project', config['tfs']['project']),
                                repository=submodule_tfs_config.get('repository', submodule_name)
                            )
                            
                            submodule_prs = submodule_tfs_client.get_pull_requests_between_commits(
                                from_commit=submodule_info['from_commit'],
                                to_commit=submodule_info['to_commit']
                            )
                            
                            for pr in submodule_prs:
                                all_pr_data.append({
                                    'project_type': 'Submodule',
                                    'project_name': submodule_name,
                                    'submodule_path': submodule_path,
                                    'pr_id': pr['pullRequestId'],
                                    'title': pr['title'],
                                    'source_branch': pr['sourceRefName'],
                                    'target_branch': pr['targetRefName'],
                                    'created_date': pr['creationDate'],
                                    'completed_date': pr.get('closedDate', ''),
                                    'status': pr['status'],
                                    'author': pr['createdBy']['displayName'],
                                    'url': pr['url']
                                })
                        except Exception as e:
                            logger.warning(f"TFS analysis failed for submodule {submodule_name}: {e}")
                    else:
                        logger.debug(f"No TFS configuration found for submodule: {submodule_name}")
                
                # Use local commit information if no TFS data and local analysis available
                if submodule_analysis and not any(pr['project_name'] == submodule_name and pr['project_type'] == 'Submodule' for pr in all_pr_data):
                    logger.info(f"Using local commit data for submodule: {submodule_name}")
                    for commit in submodule_analysis['commits']:
                        all_pr_data.append({
                            'project_type': 'Submodule (Local)',
                            'project_name': submodule_name,
                            'submodule_path': submodule_path,
                            'pr_id': 'N/A',
                            'title': commit['message'],
                            'source_branch': 'N/A',
                            'target_branch': 'N/A',
                            'created_date': commit['date'],
                            'completed_date': '',
                            'status': 'Committed',
                            'author': commit['author'],
                            'url': 'N/A'
                        })
                        
            except Exception as e:
                logger.error(f"Error analyzing submodule {submodule_name}: {str(e)}")
                continue
        
        # Generate reports
        logger.info("Generating reports...")
        report_generator = ReportGenerator(args.output_dir)
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        base_filename = f"pr_analysis_{args.from_commit[:8]}_{args.to_commit[:8]}_{timestamp}"
        
        if args.output_format in ["json", "both"]:
            json_file = report_generator.generate_json_report(all_pr_data, f"{base_filename}.json")
            logger.info(f"JSON report generated: {json_file}")
        
        if args.output_format in ["csv", "both"]:
            csv_file = report_generator.generate_csv_report(all_pr_data, f"{base_filename}.csv")
            logger.info(f"CSV report generated: {csv_file}")
        
        # Always generate HTML report for better visualization
        html_file = report_generator.generate_html_report(
            all_pr_data, 
            f"{base_filename}.html",
            f"Pull Request Analysis: {args.from_commit[:8]}...{args.to_commit[:8]}"
        )
        logger.info(f"HTML report generated: {html_file}")
        
        # Generate summary
        summary = {
            'total_pull_requests': len(all_pr_data),
            'super_project_prs': len([pr for pr in all_pr_data if pr['project_type'] == 'Super Project']),
            'submodule_prs': len([pr for pr in all_pr_data if pr['project_type'] == 'Submodule']),
            'local_commits': len([pr for pr in all_pr_data if pr['project_type'] == 'Submodule (Local)']),
            'from_commit': args.from_commit,
            'to_commit': args.to_commit,
            'analysis_timestamp': datetime.now().isoformat()
        }
        
        summary_file = report_generator.generate_json_report(summary, f"{base_filename}_summary.json")
        logger.info(f"Summary report generated: {summary_file}")
        
        logger.info("=" * 60)
        logger.info("Analysis completed successfully!")
        logger.info(f"Total pull requests found: {summary['total_pull_requests']}")
        logger.info(f"Super project PRs: {summary['super_project_prs']}")
        logger.info(f"Submodule PRs: {summary['submodule_prs']}")
        logger.info(f"Local commits: {summary['local_commits']}")
        logger.info("=" * 60)
        
    except Exception as e:
        logger.error(f"Application error: {str(e)}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
