"""
Report Generator
Generates output reports in various formats
"""

import json
import csv
import logging
from pathlib import Path
from typing import List, Dict, Any
from datetime import datetime

try:
    import pandas as pd
    PANDAS_AVAILABLE = True
except ImportError:
    PANDAS_AVAILABLE = False
    logging.warning("Pandas not available, using basic CSV generation")


class ReportGenerator:
    """Generates reports from pull request analysis data"""
    
    def __init__(self, output_dir: str = "output"):
        """
        Initialize ReportGenerator
        
        Args:
            output_dir: Directory for output files
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.logger = logging.getLogger(__name__)
        
        self.logger.info(f"Report generator initialized with output directory: {self.output_dir}")
    
    def generate_json_report(self, data: Any, filename: str) -> str:
        """
        Generate JSON report
        
        Args:
            data: Data to export
            filename: Output filename
            
        Returns:
            Path to generated file
        """
        output_path = self.output_dir / filename
        
        try:
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False, default=str)
            
            self.logger.info(f"JSON report generated: {output_path}")
            return str(output_path)
            
        except Exception as e:
            self.logger.error(f"Error generating JSON report: {e}")
            raise
    
    def generate_csv_report(self, data: List[Dict[str, Any]], filename: str) -> str:
        """
        Generate CSV report
        
        Args:
            data: List of dictionaries to export
            filename: Output filename
            
        Returns:
            Path to generated file
        """
        output_path = self.output_dir / filename
        
        try:
            if PANDAS_AVAILABLE and data:
                # Use pandas for better CSV handling
                df = pd.DataFrame(data)
                df.to_csv(output_path, index=False, encoding='utf-8')
            else:
                # Fallback to basic CSV writer
                self._generate_csv_basic(data, output_path)
            
            self.logger.info(f"CSV report generated: {output_path}")
            return str(output_path)
            
        except Exception as e:
            self.logger.error(f"Error generating CSV report: {e}")
            raise
    
    def _generate_csv_basic(self, data: List[Dict[str, Any]], output_path: Path) -> None:
        """
        Generate CSV using basic CSV writer
        
        Args:
            data: Data to write
            output_path: Output file path
        """
        if not data:
            # Create empty CSV file
            with open(output_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow(['No data available'])
            return
        
        # Get all unique keys from all dictionaries
        fieldnames = set()
        for item in data:
            fieldnames.update(item.keys())
        
        fieldnames = sorted(list(fieldnames))
        
        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            
            for item in data:
                # Handle non-string values
                row = {}
                for key in fieldnames:
                    value = item.get(key, '')
                    if isinstance(value, (dict, list)):
                        row[key] = json.dumps(value)
                    else:
                        row[key] = str(value) if value is not None else ''
                writer.writerow(row)
    
    def generate_html_report(self, data: List[Dict[str, Any]], filename: str, title: str = "Pull Request Analysis Report") -> str:
        """
        Generate HTML report
        
        Args:
            data: Data to display
            filename: Output filename
            title: Report title
            
        Returns:
            Path to generated file
        """
        output_path = self.output_dir / filename
        
        try:
            html_content = self._create_html_content(data, title)
            
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(html_content)
            
            self.logger.info(f"HTML report generated: {output_path}")
            return str(output_path)
            
        except Exception as e:
            self.logger.error(f"Error generating HTML report: {e}")
            raise
    
    def _create_html_content(self, data: List[Dict[str, Any]], title: str) -> str:
        """
        Create HTML content for report
        
        Args:
            data: Data to display
            title: Report title
            
        Returns:
            HTML content string
        """
        html = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        h1 {{
            color: #333;
            text-align: center;
            margin-bottom: 30px;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }}
        th, td {{
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }}
        th {{
            background-color: #f8f9fa;
            font-weight: 600;
            color: #495057;
        }}
        tr:nth-child(even) {{
            background-color: #f8f9fa;
        }}
        tr:hover {{
            background-color: #e9ecef;
        }}
        .pr-id {{
            font-weight: bold;
            color: #007bff;
        }}
        .project-type {{
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.875em;
            font-weight: 500;
        }}
        .super-project {{
            background-color: #d4edda;
            color: #155724;
        }}
        .submodule {{
            background-color: #cce5ff;
            color: #004085;
        }}
        .local {{
            background-color: #fff3cd;
            color: #856404;
        }}
        .status {{
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 0.8em;
        }}
        .status-completed {{
            background-color: #d4edda;
            color: #155724;
        }}
        .status-active {{
            background-color: #cce5ff;
            color: #004085;
        }}
        .summary {{
            background-color: #e9ecef;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
        }}
        .summary h3 {{
            margin-top: 0;
            color: #495057;
        }}
        .summary-stats {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 10px;
        }}
        .stat {{
            background: white;
            padding: 10px;
            border-radius: 4px;
            text-align: center;
        }}
        .stat-number {{
            font-size: 24px;
            font-weight: bold;
            color: #007bff;
        }}
        .stat-label {{
            font-size: 14px;
            color: #6c757d;
            margin-top: 5px;
        }}
        .no-data {{
            text-align: center;
            color: #6c757d;
            font-style: italic;
            padding: 40px;
        }}
        a {{
            color: #007bff;
            text-decoration: none;
        }}
        a:hover {{
            text-decoration: underline;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>{title}</h1>
        <div class="summary">
            <h3>Analysis Summary</h3>
            <div class="summary-stats">
                <div class="stat">
                    <div class="stat-number">{len(data)}</div>
                    <div class="stat-label">Total Pull Requests</div>
                </div>
                <div class="stat">
                    <div class="stat-number">{len([item for item in data if item.get('project_type') == 'Super Project'])}</div>
                    <div class="stat-label">Super Project PRs</div>
                </div>
                <div class="stat">
                    <div class="stat-number">{len([item for item in data if item.get('project_type') == 'Submodule'])}</div>
                    <div class="stat-label">Submodule PRs</div>
                </div>
                <div class="stat">
                    <div class="stat-number">{len([item for item in data if item.get('project_type') == 'Submodule (Local)'])}</div>
                    <div class="stat-label">Local Commits</div>
                </div>
            </div>
        </div>
"""
        
        if not data:
            html += '<div class="no-data">No pull requests found in the specified range.</div>'
        else:
            html += '<table>'
            
            # Table header
            headers = [
                'Project Type', 'Project Name', 'PR ID', 'Title', 
                'Author', 'Created Date', 'Status', 'Source Branch', 'Target Branch'
            ]
            html += '<thead><tr>'
            for header in headers:
                html += f'<th>{header}</th>'
            html += '</tr></thead><tbody>'
            
            # Table rows
            for item in data:
                html += '<tr>'
                
                # Project Type
                project_type = item.get('project_type', '')
                css_class = ''
                if 'Super Project' in project_type:
                    css_class = 'super-project'
                elif 'Submodule (Local)' in project_type:
                    css_class = 'local'
                elif 'Submodule' in project_type:
                    css_class = 'submodule'
                
                html += f'<td><span class="project-type {css_class}">{project_type}</span></td>'
                
                # Project Name
                html += f'<td>{item.get("project_name", "")}</td>'
                
                # PR ID
                pr_id = item.get('pr_id', '')
                if pr_id != 'N/A' and item.get('url'):
                    html += f'<td><a href="{item.get("url", "")}" class="pr-id">#{pr_id}</a></td>'
                else:
                    html += f'<td class="pr-id">{pr_id}</td>'
                
                # Title (truncate if too long)
                title_text = item.get('title', '')
                if len(title_text) > 80:
                    title_text = title_text[:77] + '...'
                html += f'<td title="{item.get("title", "")}">{title_text}</td>'
                
                # Author
                html += f'<td>{item.get("author", "")}</td>'
                
                # Created Date
                created_date = item.get('created_date', '')
                if created_date:
                    try:
                        # Try to format the date nicely
                        dt = datetime.fromisoformat(created_date.replace('Z', '+00:00'))
                        formatted_date = dt.strftime('%Y-%m-%d %H:%M')
                    except:
                        formatted_date = created_date
                else:
                    formatted_date = ''
                html += f'<td>{formatted_date}</td>'
                
                # Status
                status = item.get('status', '')
                status_class = 'status-active' if status.lower() in ['active', 'open'] else 'status-completed'
                html += f'<td><span class="status {status_class}">{status}</span></td>'
                
                # Source Branch
                source_branch = item.get('source_branch', '').replace('refs/heads/', '')
                html += f'<td>{source_branch}</td>'
                
                # Target Branch
                target_branch = item.get('target_branch', '').replace('refs/heads/', '')
                html += f'<td>{target_branch}</td>'
                
                html += '</tr>'
            
            html += '</tbody></table>'
        
        html += f"""
        <div style="margin-top: 30px; text-align: center; color: #6c757d; font-size: 0.875em;">
            Report generated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        </div>
    </div>
</body>
</html>
"""
        
        return html
    
    def generate_summary_report(self, data: List[Dict[str, Any]], analysis_info: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate summary statistics
        
        Args:
            data: Pull request data
            analysis_info: Analysis metadata
            
        Returns:
            Summary statistics dictionary
        """
        summary = {
            'analysis_info': analysis_info,
            'timestamp': datetime.now().isoformat(),
            'total_items': len(data),
            'statistics': {}
        }
        
        if not data:
            return summary
        
        # Count by project type
        project_types = {}
        for item in data:
            project_type = item.get('project_type', 'Unknown')
            project_types[project_type] = project_types.get(project_type, 0) + 1
        
        summary['statistics']['by_project_type'] = project_types
        
        # Count by status
        statuses = {}
        for item in data:
            status = item.get('status', 'Unknown')
            statuses[status] = statuses.get(status, 0) + 1
        
        summary['statistics']['by_status'] = statuses
        
        # Count by project
        projects = {}
        for item in data:
            project = item.get('project_name', 'Unknown')
            projects[project] = projects.get(project, 0) + 1
        
        summary['statistics']['by_project'] = projects
        
        # Date range
        dates = [item.get('created_date') for item in data if item.get('created_date')]
        if dates:
            try:
                parsed_dates = []
                for date_str in dates:
                    try:
                        parsed_dates.append(datetime.fromisoformat(date_str.replace('Z', '+00:00')))
                    except:
                        continue
                
                if parsed_dates:
                    summary['statistics']['date_range'] = {
                        'earliest': min(parsed_dates).isoformat(),
                        'latest': max(parsed_dates).isoformat()
                    }
            except Exception as e:
                self.logger.debug(f"Error calculating date range: {e}")
        
        return summary
