"""
Git Repository Pull Request Analyzer Package
"""

__version__ = "1.0.0"
__author__ = "Git PR Analyzer"
__description__ = "A tool for analyzing pull requests between commits/tags in Git repositories with submodules"
