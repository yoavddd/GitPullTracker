"""
Configuration Manager
Handles loading and validation of configuration files
"""

import json
import logging
import os
from pathlib import Path
from typing import Dict, Any


class ConfigManager:
    """Manages application configuration"""
    
    def __init__(self, config_path: str):
        """
        Initialize ConfigManager
        
        Args:
            config_path: Path to configuration JSON file
        """
        self.config_path = Path(config_path)
        self.logger = logging.getLogger(__name__)
        
    def load_config(self) -> Dict[str, Any]:
        """
        Load configuration from JSON file
        
        Returns:
            Dictionary containing configuration data
            
        Raises:
            FileNotFoundError: If config file doesn't exist
            json.JSONDecodeError: If config file is invalid JSON
            ValueError: If required configuration is missing
        """
        self.logger.info(f"Loading configuration from: {self.config_path}")
        
        if not self.config_path.exists():
            raise FileNotFoundError(f"Configuration file not found: {self.config_path}")
        
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
            
            self.logger.debug("Configuration loaded successfully")
            
            # Validate required configuration
            self._validate_config(config)
            
            # Process environment variable substitutions
            config = self._process_env_vars(config)
            
            self.logger.info("Configuration validation completed")
            return config
            
        except json.JSONDecodeError as e:
            self.logger.error(f"Invalid JSON in configuration file: {e}")
            raise
        except Exception as e:
            self.logger.error(f"Error loading configuration: {e}")
            raise
    
    def _validate_config(self, config: Dict[str, Any]) -> None:
        """
        Validate required configuration fields
        
        Args:
            config: Configuration dictionary to validate
            
        Raises:
            ValueError: If required fields are missing
        """
        required_fields = [
            'tfs.base_url',
            'tfs.project',
            'tfs.repository',
            'tfs.token',
            'repository.local_path'
        ]
        
        for field in required_fields:
            keys = field.split('.')
            current = config
            
            try:
                for key in keys:
                    current = current[key]
                
                if not current:
                    raise ValueError(f"Required configuration field '{field}' is empty")
                    
            except KeyError:
                raise ValueError(f"Required configuration field '{field}' is missing")
        
        # Validate local repository path exists
        repo_path = Path(config['repository']['local_path'])
        if not repo_path.exists():
            self.logger.warning(f"Repository path does not exist: {repo_path}")
            self.logger.warning("The application will attempt to use TFS API only for analysis")
        else:
            # Check if it's a git repository
            git_dir = repo_path / '.git'
            if not git_dir.exists():
                self.logger.warning(f"Path is not a Git repository: {repo_path}")
                self.logger.warning("The application will attempt to use TFS API only for analysis")
        
        self.logger.debug("Configuration validation passed")
    
    def _process_env_vars(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process environment variable substitutions in configuration
        
        Args:
            config: Configuration dictionary
            
        Returns:
            Configuration with environment variables substituted
        """
        def process_value(value):
            if isinstance(value, str):
                # Look for environment variable patterns like ${ENV_VAR} or $ENV_VAR
                import re
                pattern = r'\$\{([^}]+)\}|\$([A-Z_][A-Z0-9_]*)'
                
                def replace_env_var(match):
                    var_name = match.group(1) or match.group(2)
                    return os.getenv(var_name, match.group(0))
                
                return re.sub(pattern, replace_env_var, value)
            elif isinstance(value, dict):
                return {k: process_value(v) for k, v in value.items()}
            elif isinstance(value, list):
                return [process_value(item) for item in value]
            else:
                return value
        
        processed_config = process_value(config)
        
        # Also check for direct environment variable overrides
        tfs_token = os.getenv('TFS_TOKEN')
        if tfs_token:
            processed_config['tfs']['token'] = tfs_token
            self.logger.info("TFS token loaded from environment variable")
        
        return processed_config
    
    def save_config(self, config: Dict[str, Any], output_path: str = None) -> None:
        """
        Save configuration to JSON file
        
        Args:
            config: Configuration dictionary to save
            output_path: Optional output path, defaults to original config path
        """
        output_path = Path(output_path) if output_path else self.config_path
        
        try:
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
            
            self.logger.info(f"Configuration saved to: {output_path}")
            
        except Exception as e:
            self.logger.error(f"Error saving configuration: {e}")
            raise
