"""
Utility functions
Common utilities used across the application
"""

import logging
import sys
from pathlib import Path
from typing import Optional
from datetime import datetime


def setup_logging(level: str = "INFO", log_file: Optional[str] = None) -> logging.Logger:
    """
    Setup application logging
    
    Args:
        level: Logging level (DEBUG, INFO, WARNING, ERROR)
        log_file: Optional log file path
        
    Returns:
        Configured logger
    """
    # Create logs directory if it doesn't exist
    if log_file:
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
    
    # Configure logging format
    log_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    date_format = "%Y-%m-%d %H:%M:%S"
    
    # Configure root logger
    logging.basicConfig(
        level=getattr(logging, level.upper()),
        format=log_format,
        datefmt=date_format,
        handlers=[]
    )
    
    # Create formatters
    formatter = logging.Formatter(log_format, date_format)
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    console_handler.setLevel(getattr(logging, level.upper()))
    
    # File handler if log file specified
    handlers = [console_handler]
    if log_file:
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setFormatter(formatter)
        file_handler.setLevel(logging.DEBUG)  # Always log everything to file
        handlers.append(file_handler)
    
    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.handlers.clear()
    for handler in handlers:
        root_logger.addHandler(handler)
    
    # Reduce noise from external libraries
    logging.getLogger('urllib3').setLevel(logging.WARNING)
    logging.getLogger('requests').setLevel(logging.WARNING)
    logging.getLogger('git').setLevel(logging.WARNING)
    
    logger = logging.getLogger(__name__)
    logger.info(f"Logging initialized - Level: {level}")
    if log_file:
        logger.info(f"Log file: {log_file}")
    
    return logger


def validate_commit_hash(commit_hash: str) -> bool:
    """
    Validate if string looks like a Git commit hash
    
    Args:
        commit_hash: String to validate
        
    Returns:
        True if valid commit hash format
    """
    if not commit_hash:
        return False
    
    # Git commit hashes are 40 character hex strings (or shorter for abbreviated)
    import re
    pattern = r'^[a-fA-F0-9]{7,40}$'
    return bool(re.match(pattern, commit_hash))


def sanitize_filename(filename: str) -> str:
    """
    Sanitize filename for cross-platform compatibility
    
    Args:
        filename: Original filename
        
    Returns:
        Sanitized filename
    """
    import re
    
    # Replace invalid characters
    sanitized = re.sub(r'[<>:"/\\|?*]', '_', filename)
    
    # Remove leading/trailing spaces and dots
    sanitized = sanitized.strip(' .')
    
    # Limit length
    if len(sanitized) > 200:
        sanitized = sanitized[:200]
    
    return sanitized


def format_duration(seconds: float) -> str:
    """
    Format duration in human-readable format
    
    Args:
        seconds: Duration in seconds
        
    Returns:
        Formatted duration string
    """
    if seconds < 60:
        return f"{seconds:.1f} seconds"
    elif seconds < 3600:
        minutes = seconds / 60
        return f"{minutes:.1f} minutes"
    else:
        hours = seconds / 3600
        return f"{hours:.1f} hours"


def parse_date_string(date_string: str) -> Optional[datetime]:
    """
    Parse various date string formats
    
    Args:
        date_string: Date string to parse
        
    Returns:
        Parsed datetime object or None if parsing fails
    """
    if not date_string:
        return None
    
    # Common date formats to try
    formats = [
        '%Y-%m-%dT%H:%M:%S.%fZ',  # ISO format with microseconds
        '%Y-%m-%dT%H:%M:%SZ',     # ISO format
        '%Y-%m-%dT%H:%M:%S.%f%z', # ISO format with timezone
        '%Y-%m-%dT%H:%M:%S%z',    # ISO format with timezone
        '%Y-%m-%d %H:%M:%S',      # Simple format
        '%Y-%m-%d',               # Date only
    ]
    
    for fmt in formats:
        try:
            return datetime.strptime(date_string, fmt)
        except ValueError:
            continue
    
    # Try fromisoformat as fallback (Python 3.7+)
    try:
        # Handle Z timezone
        if date_string.endswith('Z'):
            date_string = date_string[:-1] + '+00:00'
        return datetime.fromisoformat(date_string)
    except:
        pass
    
    return None


def ensure_directory(path: str) -> Path:
    """
    Ensure directory exists
    
    Args:
        path: Directory path
        
    Returns:
        Path object
    """
    dir_path = Path(path)
    dir_path.mkdir(parents=True, exist_ok=True)
    return dir_path


def truncate_string(text: str, max_length: int = 100, suffix: str = "...") -> str:
    """
    Truncate string to maximum length
    
    Args:
        text: Text to truncate
        max_length: Maximum length
        suffix: Suffix to add when truncating
        
    Returns:
        Truncated string
    """
    if not text or len(text) <= max_length:
        return text
    
    return text[:max_length - len(suffix)] + suffix


def safe_get(dictionary: dict, key_path: str, default=None):
    """
    Safely get nested dictionary value using dot notation
    
    Args:
        dictionary: Dictionary to search
        key_path: Dot-separated key path (e.g., "user.profile.name")
        default: Default value if key not found
        
    Returns:
        Value or default
    """
    keys = key_path.split('.')
    current = dictionary
    
    try:
        for key in keys:
            current = current[key]
        return current
    except (KeyError, TypeError):
        return default


class ProgressTracker:
    """Simple progress tracker for long-running operations"""
    
    def __init__(self, total: int, description: str = "Processing"):
        """
        Initialize progress tracker
        
        Args:
            total: Total number of items
            description: Description of the operation
        """
        self.total = total
        self.current = 0
        self.description = description
        self.start_time = datetime.now()
        self.logger = logging.getLogger(__name__)
        
        self.logger.info(f"Starting {description} - {total} items")
    
    def update(self, increment: int = 1) -> None:
        """
        Update progress
        
        Args:
            increment: Number to increment by
        """
        self.current += increment
        
        if self.total > 0:
            percentage = (self.current / self.total) * 100
            
            if self.current % max(1, self.total // 10) == 0 or self.current == self.total:
                elapsed = datetime.now() - self.start_time
                self.logger.info(
                    f"{self.description}: {self.current}/{self.total} "
                    f"({percentage:.1f}%) - Elapsed: {format_duration(elapsed.total_seconds())}"
                )
    
    def finish(self) -> None:
        """Mark progress as finished"""
        elapsed = datetime.now() - self.start_time
        self.logger.info(
            f"{self.description} completed: {self.current}/{self.total} items "
            f"in {format_duration(elapsed.total_seconds())}"
        )
