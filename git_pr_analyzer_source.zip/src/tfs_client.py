"""
TFS Client
Handles Azure DevOps TFS API interactions
"""

import logging
import requests
import base64
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import time


class TFSClient:
    """Client for Azure DevOps TFS API"""
    
    def __init__(self, base_url: str, token: str, project: str, repository: str):
        """
        Initialize TFS Client
        
        Args:
            base_url: TFS base URL (e.g., http://tfs1:8080/tfs/Collection)
            token: Personal Access Token
            project: TFS project name
            repository: Repository name
        """
        self.base_url = base_url.rstrip('/')
        self.token = token
        self.project = project
        self.repository = repository
        self.logger = logging.getLogger(__name__)
        
        # Setup authentication
        self.auth_header = self._create_auth_header()
        
        # API endpoints
        self.api_version = "6.0"
        self.rest_api_base = f"{self.base_url}/{self.project}/_apis"
        
        self.logger.info(f"Initialized TFS client for project: {project}, repository: {repository}")
    
    def _create_auth_header(self) -> str:
        """
        Create authentication header for TFS API
        
        Returns:
            Base64 encoded authentication header
        """
        # TFS uses basic auth with empty username and PAT as password
        credentials = f":{self.token}"
        encoded_credentials = base64.b64encode(credentials.encode('utf-8')).decode('utf-8')
        return f"Basic {encoded_credentials}"
    
    def _make_request(self, endpoint: str, params: Dict[str, Any] = None, retries: int = 3) -> Dict[str, Any]:
        """
        Make HTTP request to TFS API
        
        Args:
            endpoint: API endpoint
            params: Query parameters
            retries: Number of retry attempts
            
        Returns:
            JSON response data
            
        Raises:
            requests.RequestException: If request fails after retries
        """
        url = f"{self.rest_api_base}/{endpoint}"
        headers = {
            'Authorization': self.auth_header,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        
        if params is None:
            params = {}
        
        params['api-version'] = self.api_version
        
        for attempt in range(retries + 1):
            try:
                self.logger.debug(f"Making request to: {url}")
                response = requests.get(url, headers=headers, params=params, timeout=30)
                
                if response.status_code == 200:
                    return response.json()
                elif response.status_code == 401:
                    raise requests.RequestException(f"Authentication failed. Check your TFS token.")
                elif response.status_code == 404:
                    raise requests.RequestException(f"Resource not found: {url}")
                else:
                    response.raise_for_status()
                    
            except requests.RequestException as e:
                self.logger.warning(f"Request failed (attempt {attempt + 1}/{retries + 1}): {e}")
                if attempt == retries:
                    raise
                time.sleep(2 ** attempt)  # Exponential backoff
    
    def get_pull_requests_between_commits(self, from_commit: str, to_commit: str) -> List[Dict[str, Any]]:
        """
        Get pull requests between two commits
        
        Args:
            from_commit: Source commit hash or tag
            to_commit: Target commit hash or tag
            
        Returns:
            List of pull request data
        """
        self.logger.info(f"Fetching pull requests between {from_commit} and {to_commit}")
        
        try:
            # Get commit details to find date range
            from_commit_info = self._get_commit_info(from_commit)
            to_commit_info = self._get_commit_info(to_commit)
            
            if not from_commit_info or not to_commit_info:
                self.logger.error("Could not retrieve commit information")
                return []
            
            # Get pull requests in date range with some buffer
            from_date = datetime.fromisoformat(from_commit_info['committer']['date'].replace('Z', '+00:00'))
            to_date = datetime.fromisoformat(to_commit_info['committer']['date'].replace('Z', '+00:00'))
            
            # Add buffer to catch PRs that might be slightly outside the exact commit dates
            from_date_buffered = from_date - timedelta(days=7)
            to_date_buffered = to_date + timedelta(days=1)
            
            # Get all pull requests in the time range
            all_prs = self._get_pull_requests_in_date_range(from_date_buffered, to_date_buffered)
            
            # Filter PRs that actually contain commits in our range
            filtered_prs = []
            for pr in all_prs:
                if self._pr_contains_commits_in_range(pr, from_commit, to_commit):
                    filtered_prs.append(pr)
            
            self.logger.info(f"Found {len(filtered_prs)} pull requests in commit range")
            return filtered_prs
            
        except Exception as e:
            self.logger.error(f"Error fetching pull requests: {e}")
            return []
    
    def _get_commit_info(self, commit_ref: str) -> Optional[Dict[str, Any]]:
        """
        Get commit information from TFS
        
        Args:
            commit_ref: Commit hash or tag
            
        Returns:
            Commit information or None if not found
        """
        try:
            endpoint = f"git/repositories/{self.repository}/commits/{commit_ref}"
            return self._make_request(endpoint)
        except Exception as e:
            self.logger.debug(f"Could not get commit info for {commit_ref}: {e}")
            return None
    
    def _get_pull_requests_in_date_range(self, from_date: datetime, to_date: datetime) -> List[Dict[str, Any]]:
        """
        Get pull requests created in date range
        
        Args:
            from_date: Start date
            to_date: End date
            
        Returns:
            List of pull requests
        """
        try:
            endpoint = f"git/repositories/{self.repository}/pullrequests"
            params = {
                'searchCriteria.status': 'all',
                '$top': 100,  # Get more PRs to ensure we don't miss any
                'searchCriteria.minTime': from_date.isoformat(),
                'searchCriteria.maxTime': to_date.isoformat()
            }
            
            all_prs = []
            skip = 0
            
            while True:
                params['$skip'] = skip
                response = self._make_request(endpoint, params)
                
                prs = response.get('value', [])
                if not prs:
                    break
                
                all_prs.extend(prs)
                
                # Check if there are more results
                if len(prs) < 100:
                    break
                
                skip += 100
            
            self.logger.debug(f"Retrieved {len(all_prs)} pull requests in date range")
            return all_prs
            
        except Exception as e:
            self.logger.error(f"Error getting pull requests in date range: {e}")
            return []
    
    def _pr_contains_commits_in_range(self, pr: Dict[str, Any], from_commit: str, to_commit: str) -> bool:
        """
        Check if pull request contains commits in the specified range
        
        Args:
            pr: Pull request data
            from_commit: Source commit
            to_commit: Target commit
            
        Returns:
            True if PR contains relevant commits
        """
        try:
            pr_id = pr['pullRequestId']
            
            # Get PR commits
            pr_commits = self._get_pull_request_commits(pr_id)
            
            if not pr_commits:
                return False
            
            # Get the commit range we're interested in
            target_commits = self._get_commits_in_range(from_commit, to_commit)
            target_commit_shas = {commit['commitId'] for commit in target_commits}
            
            # Check if any PR commits are in our target range
            pr_commit_shas = {commit['commitId'] for commit in pr_commits}
            
            intersection = pr_commit_shas.intersection(target_commit_shas)
            
            if intersection:
                self.logger.debug(f"PR {pr_id} contains {len(intersection)} commits in range")
                return True
            
            return False
            
        except Exception as e:
            self.logger.debug(f"Error checking PR commits: {e}")
            return False
    
    def _get_pull_request_commits(self, pr_id: int) -> List[Dict[str, Any]]:
        """
        Get commits for a specific pull request
        
        Args:
            pr_id: Pull request ID
            
        Returns:
            List of commits in the pull request
        """
        try:
            endpoint = f"git/repositories/{self.repository}/pullrequests/{pr_id}/commits"
            response = self._make_request(endpoint)
            return response.get('value', [])
        except Exception as e:
            self.logger.debug(f"Error getting commits for PR {pr_id}: {e}")
            return []
    
    def _get_commits_in_range(self, from_commit: str, to_commit: str) -> List[Dict[str, Any]]:
        """
        Get commits between two commit references
        
        Args:
            from_commit: Source commit
            to_commit: Target commit
            
        Returns:
            List of commits
        """
        try:
            endpoint = f"git/repositories/{self.repository}/commits"
            params = {
                'searchCriteria.fromCommitId': from_commit,
                'searchCriteria.toCommitId': to_commit,
                '$top': 1000
            }
            
            response = self._make_request(endpoint, params)
            return response.get('value', [])
            
        except Exception as e:
            self.logger.debug(f"Error getting commits in range: {e}")
            return []
    
    def get_repository_info(self) -> Dict[str, Any]:
        """
        Get repository information
        
        Returns:
            Repository information
        """
        try:
            endpoint = f"git/repositories/{self.repository}"
            return self._make_request(endpoint)
        except Exception as e:
            self.logger.error(f"Error getting repository info: {e}")
            return {}
    
    def test_connection(self) -> bool:
        """
        Test TFS connection
        
        Returns:
            True if connection is successful
        """
        try:
            repo_info = self.get_repository_info()
            if repo_info and 'id' in repo_info:
                self.logger.info("TFS connection test successful")
                return True
            else:
                self.logger.error("TFS connection test failed - no repository info")
                return False
        except Exception as e:
            self.logger.error(f"TFS connection test failed: {e}")
            return False
