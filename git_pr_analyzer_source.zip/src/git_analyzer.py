"""
Git Analyzer
Handles Git repository operations and analysis
"""

import logging
import os
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime

try:
    import git
    from git import Repo, GitCommandError
except ImportError:
    raise ImportError("GitPython is required. Install with: pip install GitPython")


class GitAnalyzer:
    """Analyzes Git repositories and submodules"""
    
    def __init__(self, repo_path: str):
        """
        Initialize GitAnalyzer
        
        Args:
            repo_path: Path to Git repository
        """
        self.repo_path = Path(repo_path)
        self.logger = logging.getLogger(__name__)
        
        try:
            self.repo = Repo(self.repo_path)
            self.logger.info(f"Initialized Git repository: {self.repo_path}")
        except Exception as e:
            self.logger.error(f"Failed to initialize Git repository: {e}")
            raise
    
    def analyze_commits_range(self, from_commit: str, to_commit: str) -> Dict[str, Any]:
        """
        Analyze commits between two commit hashes or tags
        
        Args:
            from_commit: Source commit hash or tag
            to_commit: Target commit hash or tag
            
        Returns:
            Dictionary containing analysis results
        """
        self.logger.info(f"Analyzing commits from {from_commit} to {to_commit}")
        
        try:
            # Resolve commit hashes from tags if necessary
            from_sha = self._resolve_commit(from_commit)
            to_sha = self._resolve_commit(to_commit)
            
            self.logger.debug(f"Resolved commits: {from_sha} -> {to_sha}")
            
            # Get commits in range
            commits = self._get_commits_between(from_sha, to_sha)
            
            # Analyze submodules
            submodules = self._analyze_submodules(from_sha, to_sha)
            
            # Get merge commits (potential PR merges)
            merge_commits = self._get_merge_commits(from_sha, to_sha)
            
            analysis_result = {
                'repository_path': str(self.repo_path),
                'from_commit': from_commit,
                'to_commit': to_commit,
                'from_sha': from_sha,
                'to_sha': to_sha,
                'total_commits': len(commits),
                'merge_commits': len(merge_commits),
                'commits': commits,
                'submodules': submodules,
                'merge_commit_details': merge_commits,
                'analysis_timestamp': datetime.now().isoformat()
            }
            
            self.logger.info(f"Analysis completed: {len(commits)} commits, {len(submodules)} submodules")
            return analysis_result
            
        except Exception as e:
            self.logger.error(f"Error analyzing commits: {e}")
            raise
    
    def _resolve_commit(self, commit_ref: str) -> str:
        """
        Resolve commit reference to SHA hash
        
        Args:
            commit_ref: Commit hash or tag name
            
        Returns:
            Full SHA hash
        """
        try:
            # Try as direct commit hash first
            commit = self.repo.commit(commit_ref)
            return commit.hexsha
        except Exception:
            # Try as tag
            try:
                tag = self.repo.tags[commit_ref]
                return tag.commit.hexsha
            except Exception:
                # Try as branch
                try:
                    branch = self.repo.heads[commit_ref]
                    return branch.commit.hexsha
                except Exception:
                    self.logger.error(f"Could not resolve commit reference: {commit_ref}")
                    raise ValueError(f"Invalid commit reference: {commit_ref}")
    
    def _get_commits_between(self, from_sha: str, to_sha: str) -> List[Dict[str, Any]]:
        """
        Get commits between two SHA hashes
        
        Args:
            from_sha: Source commit SHA
            to_sha: Target commit SHA
            
        Returns:
            List of commit information dictionaries
        """
        commits = []
        
        try:
            # Get commits using GitPython's rev_list
            commit_range = f"{from_sha}..{to_sha}"
            commit_iter = self.repo.iter_commits(commit_range)
            
            for commit in commit_iter:
                commit_info = {
                    'sha': commit.hexsha,
                    'short_sha': commit.hexsha[:8],
                    'message': commit.message.strip(),
                    'author': commit.author.name,
                    'author_email': commit.author.email,
                    'date': commit.committed_datetime.isoformat(),
                    'is_merge': len(commit.parents) > 1,
                    'parent_count': len(commit.parents)
                }
                commits.append(commit_info)
            
            self.logger.debug(f"Found {len(commits)} commits in range")
            return commits
            
        except Exception as e:
            self.logger.error(f"Error getting commits between {from_sha} and {to_sha}: {e}")
            raise
    
    def _get_merge_commits(self, from_sha: str, to_sha: str) -> List[Dict[str, Any]]:
        """
        Get merge commits between two SHA hashes
        
        Args:
            from_sha: Source commit SHA
            to_sha: Target commit SHA
            
        Returns:
            List of merge commit information dictionaries
        """
        merge_commits = []
        
        try:
            commit_range = f"{from_sha}..{to_sha}"
            commit_iter = self.repo.iter_commits(commit_range)
            
            for commit in commit_iter:
                if len(commit.parents) > 1:  # Merge commit
                    # Try to extract PR information from commit message
                    pr_info = self._extract_pr_info_from_message(commit.message)
                    
                    merge_info = {
                        'sha': commit.hexsha,
                        'short_sha': commit.hexsha[:8],
                        'message': commit.message.strip(),
                        'author': commit.author.name,
                        'date': commit.committed_datetime.isoformat(),
                        'parents': [p.hexsha for p in commit.parents],
                        'pr_number': pr_info.get('pr_number'),
                        'pr_title': pr_info.get('pr_title'),
                        'source_branch': pr_info.get('source_branch'),
                        'target_branch': pr_info.get('target_branch')
                    }
                    merge_commits.append(merge_info)
            
            self.logger.debug(f"Found {len(merge_commits)} merge commits")
            return merge_commits
            
        except Exception as e:
            self.logger.error(f"Error getting merge commits: {e}")
            raise
    
    def _extract_pr_info_from_message(self, message: str) -> Dict[str, Optional[str]]:
        """
        Extract pull request information from commit message
        
        Args:
            message: Commit message
            
        Returns:
            Dictionary with extracted PR information
        """
        import re
        
        pr_info = {
            'pr_number': None,
            'pr_title': None,
            'source_branch': None,
            'target_branch': None
        }
        
        # Common PR merge message patterns
        patterns = [
            r'Merged PR (\d+): (.+)',  # Azure DevOps style
            r'Merge pull request #(\d+) from (.+)',  # GitHub style
            r'Pull request #(\d+): (.+)',  # Generic style
            r'PR #?(\d+):?\s*(.+)',  # Short style
        ]
        
        for pattern in patterns:
            match = re.search(pattern, message, re.IGNORECASE)
            if match:
                pr_info['pr_number'] = match.group(1)
                pr_info['pr_title'] = match.group(2).strip()
                break
        
        # Try to extract branch information
        branch_patterns = [
            r'from\s+([^\s]+)\s+to\s+([^\s]+)',
            r'from\s+([^\s]+)',
            r'into\s+([^\s]+)'
        ]
        
        for pattern in branch_patterns:
            match = re.search(pattern, message, re.IGNORECASE)
            if match:
                if 'to' in pattern:
                    pr_info['source_branch'] = match.group(1)
                    pr_info['target_branch'] = match.group(2)
                else:
                    pr_info['source_branch'] = match.group(1)
                break
        
        return pr_info
    
    def _analyze_submodules(self, from_sha: str, to_sha: str) -> List[Dict[str, Any]]:
        """
        Analyze submodules and their commit changes
        
        Args:
            from_sha: Source commit SHA
            to_sha: Target commit SHA
            
        Returns:
            List of submodule analysis results
        """
        submodules = []
        
        try:
            # Check if repository has submodules
            gitmodules_path = self.repo_path / '.gitmodules'
            if not gitmodules_path.exists():
                self.logger.info("No .gitmodules file found, no submodules to analyze")
                return submodules
            
            # Get submodule information
            try:
                repo_submodules = self.repo.submodules
            except Exception as e:
                self.logger.warning(f"Could not load submodules: {e}")
                return submodules
            
            for submodule in repo_submodules:
                self.logger.info(f"Analyzing submodule: {submodule.name}")
                
                try:
                    # Get submodule commit at from_sha
                    from_commit_obj = self.repo.commit(from_sha)
                    from_submodule_sha = self._get_submodule_commit_at_commit(
                        submodule, from_commit_obj
                    )
                    
                    # Get submodule commit at to_sha
                    to_commit_obj = self.repo.commit(to_sha)
                    to_submodule_sha = self._get_submodule_commit_at_commit(
                        submodule, to_commit_obj
                    )
                    
                    if from_submodule_sha and to_submodule_sha:
                        submodule_info = {
                            'name': submodule.name,
                            'path': str(submodule.path),
                            'url': submodule.url,
                            'from_commit': from_submodule_sha,
                            'to_commit': to_submodule_sha,
                            'changed': from_submodule_sha != to_submodule_sha,
                            'absolute_path': str(self.repo_path / submodule.path)
                        }
                        
                        # If submodule changed, get detailed commit info
                        if submodule_info['changed']:
                            submodule_info['commit_details'] = self._get_submodule_commit_details(
                                submodule_info['absolute_path'],
                                from_submodule_sha,
                                to_submodule_sha
                            )
                        
                        submodules.append(submodule_info)
                        self.logger.debug(f"Submodule {submodule.name}: {from_submodule_sha} -> {to_submodule_sha}")
                    else:
                        self.logger.warning(f"Could not get commit info for submodule: {submodule.name}")
                        
                except Exception as e:
                    self.logger.error(f"Error analyzing submodule {submodule.name}: {e}")
                    continue
            
            self.logger.info(f"Analyzed {len(submodules)} submodules")
            return submodules
            
        except Exception as e:
            self.logger.error(f"Error analyzing submodules: {e}")
            return submodules
    
    def _get_submodule_commit_at_commit(self, submodule, commit) -> Optional[str]:
        """
        Get the submodule commit SHA at a specific parent commit
        
        Args:
            submodule: GitPython submodule object
            commit: Parent commit object
            
        Returns:
            Submodule commit SHA or None if not found
        """
        try:
            # Get the tree entry for the submodule at this commit
            tree_entry = commit.tree[submodule.path]
            return tree_entry.hexsha
        except Exception as e:
            self.logger.debug(f"Could not get submodule commit for {submodule.name} at {commit.hexsha}: {e}")
            return None
    
    def _get_submodule_commit_details(self, submodule_path: str, from_sha: str, to_sha: str) -> Dict[str, Any]:
        """
        Get detailed commit information for submodule changes
        
        Args:
            submodule_path: Path to submodule directory
            from_sha: Source commit SHA
            to_sha: Target commit SHA
            
        Returns:
            Dictionary with commit details
        """
        try:
            submodule_repo = Repo(submodule_path)
            
            # Get commits between the two SHAs
            commit_range = f"{from_sha}..{to_sha}"
            commits = list(submodule_repo.iter_commits(commit_range))
            
            commit_details = {
                'total_commits': len(commits),
                'commits': []
            }
            
            for commit in commits[:10]:  # Limit to first 10 commits
                commit_info = {
                    'sha': commit.hexsha,
                    'message': commit.message.strip(),
                    'author': commit.author.name,
                    'date': commit.committed_datetime.isoformat()
                }
                commit_details['commits'].append(commit_info)
            
            return commit_details
            
        except Exception as e:
            self.logger.error(f"Error getting submodule commit details: {e}")
            return {'total_commits': 0, 'commits': []}
