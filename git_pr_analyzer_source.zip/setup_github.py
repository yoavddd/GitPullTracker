#!/usr/bin/env python3
"""
GitHub Setup Helper
Creates necessary files for pushing to GitHub
"""

import os
import json
from pathlib import Path
from datetime import datetime

def create_gitignore():
    """Create .gitignore file"""
    gitignore_content = """# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
*.egg-info/
.installed.cfg
*.egg
MANIFEST

# Environment variables
.env
.venv
env/
venv/
ENV/
env.bak/
venv.bak/

# IDE
.vscode/
.idea/
*.swp
*.swo
*~

# Logs
logs/*.log
*.log

# Output files (reports)
output/*.json
output/*.csv
output/*.html
output/*.zip

# OS
.DS_Store
.DS_Store?
._*
.Spotlight-V100
.Trashes
ehthumbs.db
Thumbs.db

# Replit specific
.replit
.upm
.breakpoints
uv.lock
"""
    
    with open('.gitignore', 'w') as f:
        f.write(gitignore_content)
    print("✓ Created .gitignore")

def create_github_readme():
    """Create GitHub-specific README"""
    readme_content = """# Git PR Analyzer

A comprehensive Python tool for analyzing Git repository pull requests with Azure DevOps TFS integration.

## Features

- **Multiple Analysis Modes**: TFS API, Local Git, or hybrid approach
- **Web Interface**: User-friendly Flask web application
- **Multiple Output Formats**: JSON, CSV, and HTML reports
- **Submodule Support**: Analyzes changes across Git submodules
- **TFS Integration**: Connects to Azure DevOps for complete PR information

## Quick Start

### Web Application
```bash
python run.py
```
Visit http://localhost:5000 to use the web interface.

### Command Line
```bash
python main.py --from-commit <commit1> --to-commit <commit2>
```

## Installation

```bash
pip install -r requirements.txt
```

## Configuration

Create a `config.json` file with your TFS and repository settings:

```json
{
    "tfs": {
        "base_url": "your-tfs-url",
        "project": "your-project",
        "repository": "your-repo",
        "token": "${TFS_TOKEN}"
    },
    "repository": {
        "local_path": "./your-repo-path"
    }
}
```

## Environment Variables

- `TFS_TOKEN`: Your Azure DevOps Personal Access Token

## Project Structure

```
├── src/                    # Core application modules
│   ├── git_analyzer.py     # Git operations
│   ├── tfs_client.py       # TFS API client
│   ├── config_manager.py   # Configuration handling
│   ├── report_generator.py # Report generation
│   └── utils.py           # Utilities
├── templates/             # Web interface templates
├── main.py               # Command-line interface
├── web_app.py           # Flask web application
├── run.py               # Production entry point
└── config.json          # Configuration file
```

## Usage Examples

See `example_usage.md` for detailed usage examples and configuration options.

## License

MIT License - see LICENSE file for details.
"""
    
    with open('README_GITHUB.md', 'w') as f:
        f.write(readme_content)
    print("✓ Created README_GITHUB.md (GitHub-specific)")

def create_requirements_txt():
    """Create requirements.txt from pyproject.toml"""
    requirements = [
        "GitPython>=3.1.44",
        "pandas>=2.3.0", 
        "requests>=2.32.4",
        "flask>=3.1.1",
        "gunicorn>=23.0.0"
    ]
    
    with open('requirements.txt', 'w') as f:
        for req in requirements:
            f.write(req + '\n')
    print("✓ Created requirements.txt")

def create_license():
    """Create MIT license file"""
    license_content = """MIT License

Copyright (c) 2025 Git PR Analyzer

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""
    
    with open('LICENSE', 'w') as f:
        f.write(license_content)
    print("✓ Created LICENSE")

def print_github_instructions():
    """Print instructions for pushing to GitHub"""
    print("\n" + "="*60)
    print("GITHUB SETUP INSTRUCTIONS")
    print("="*60)
    print("""
1. CREATE A NEW GITHUB REPOSITORY:
   - Go to https://github.com/new
   - Name it 'git-pr-analyzer' (or your preferred name)
   - Make it public or private
   - Don't initialize with README (we have files already)

2. PUSH YOUR CODE TO GITHUB:
   Run these commands in the Replit terminal:

   # Initialize git repository
   git init
   
   # Add all files
   git add .
   
   # Make first commit
   git commit -m "Initial commit: Git PR Analyzer web application"
   
   # Add your GitHub repository as origin
   git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO-NAME.git
   
   # Push to GitHub
   git push -u origin main

3. ALTERNATIVE: Use GitHub CLI (if available):
   gh repo create git-pr-analyzer --public
   git push -u origin main

4. WHAT'S INCLUDED:
   ✓ All Python source files
   ✓ Web application templates
   ✓ Configuration files
   ✓ Documentation
   ✓ .gitignore (excludes logs, cache files)
   ✓ requirements.txt (for pip install)
   ✓ LICENSE file

5. AFTER PUSHING:
   - Your repository will be available at: https://github.com/YOUR-USERNAME/YOUR-REPO-NAME
   - Others can clone it with: git clone https://github.com/YOUR-USERNAME/YOUR-REPO-NAME.git
   - Install dependencies with: pip install -r requirements.txt
""")

def main():
    """Main setup function"""
    print("Setting up files for GitHub...")
    
    create_gitignore()
    create_github_readme()
    create_requirements_txt()
    create_license()
    
    print_github_instructions()

if __name__ == '__main__':
    main()