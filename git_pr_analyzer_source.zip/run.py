#!/usr/bin/env python3
"""
Production entry point for Git PR Analyzer Web Application
Handles both development and deployment environments
"""

import os
import sys
from pathlib import Path

# Add the current directory to Python path
sys.path.insert(0, str(Path(__file__).parent))

from web_app import app

if __name__ == '__main__':
    # Get port from environment (Replit deployment sets this)
    port = int(os.environ.get('PORT', 5000))
    
    # Get host from environment 
    host = os.environ.get('HOST', '0.0.0.0')
    
    # Determine if we're in production
    is_production = os.environ.get('REPLIT_ENVIRONMENT') == 'production'
    
    print(f"Starting Git PR Analyzer Web Server...")
    print(f"Host: {host}")
    print(f"Port: {port}")
    print(f"Environment: {'Production' if is_production else 'Development'}")
    
    # Run the application
    app.run(
        host=host,
        port=port,
        debug=not is_production,
        threaded=True
    )