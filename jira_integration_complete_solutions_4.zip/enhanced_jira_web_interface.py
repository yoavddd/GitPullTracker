"""
Enhanced Jira Web Interface with Duplicate Checking and Epic Assignment
"""

import logging
import json
import csv
import requests
import urllib3
from typing import Dict, Any, List, Optional
from urllib.parse import urlencode, quote

# Disable SSL warnings for corporate environments
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class EnhancedJiraWebInterface:
    """Enhanced web interface with duplicate checking and epic assignment"""
    
    def __init__(self, jira_config: Dict[str, Any]):
        """Initialize enhanced web interface"""
        self.jira_config = jira_config
        self.jira_url = jira_config.get('url', '').rstrip('/')
        self.project_key = jira_config.get('project_key', '')
        self.epic_key = jira_config.get('epic_key', '')
        self.structure_board_id = jira_config.get('structure_board_id', '')
        self.username = jira_config.get('username', '')
        self.password = jira_config.get('password', '')
        
        self.logger = logging.getLogger(__name__)
        self.session = self._create_session()
        self.existing_qc_numbers = set()
    
    def _create_session(self) -> requests.Session:
        """Create authenticated session for Jira API calls"""
        session = requests.Session()
        session.verify = False  # For corporate SSL issues
        session.auth = (self.username, self.password)
        session.headers.update({
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        })
        return session
    
    def check_existing_qc_numbers(self) -> None:
        """Check existing QC numbers in Jira to prevent duplicates"""
        try:
            self.logger.info("Checking existing QC numbers in Jira...")
            
            # Search for issues with QC labels in the project
            jql = f'project = "{self.project_key}" AND labels in ("QC-Import") OR summary ~ "QC*"'
            url = f"{self.jira_url}/rest/api/2/search"
            
            params = {
                'jql': jql,
                'fields': 'summary,labels,description',
                'maxResults': 1000
            }
            
            response = self.session.get(url, params=params, timeout=30)
            
            if response.status_code == 200:
                issues = response.json().get('issues', [])
                self.logger.info(f"Found {len(issues)} existing issues")
                
                # Extract QC numbers from existing issues
                for issue in issues:
                    summary = issue.get('fields', {}).get('summary', '')
                    labels = issue.get('fields', {}).get('labels', [])
                    description = issue.get('fields', {}).get('description', '')
                    
                    # Look for QC numbers in labels
                    for label in labels:
                        if label.startswith('QC-') and label != 'QC-Import':
                            qc_num = label.replace('QC-', '')
                            self.existing_qc_numbers.add(qc_num)
                    
                    # Look for QC numbers in summary
                    if 'QC' in summary:
                        import re
                        qc_matches = re.findall(r'QC[- ]?(\d+)', summary, re.IGNORECASE)
                        for match in qc_matches:
                            self.existing_qc_numbers.add(match)
                    
                    # Look for QC numbers in description
                    if description and 'QC' in description:
                        import re
                        qc_matches = re.findall(r'QC[- ]?(\d+)', description, re.IGNORECASE)
                        for match in qc_matches:
                            self.existing_qc_numbers.add(match)
                
                self.logger.info(f"Found {len(self.existing_qc_numbers)} existing QC numbers: {sorted(list(self.existing_qc_numbers))}")
                
            else:
                self.logger.warning(f"Could not check existing QC numbers. Status: {response.status_code}")
                self.logger.warning("Proceeding without duplicate checking")
                
        except Exception as e:
            self.logger.warning(f"Error checking existing QC numbers: {e}")
            self.logger.warning("Proceeding without duplicate checking")
    
    def is_duplicate_qc(self, qc_number: str) -> bool:
        """Check if QC number already exists"""
        # Clean the QC number
        clean_qc = str(qc_number).replace('QC', '').replace('-', '').strip()
        return clean_qc in self.existing_qc_numbers
    
    def generate_create_bug_urls(self, bugs_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Generate Jira URLs with duplicate checking and epic assignment
        """
        urls = []
        
        for i, bug in enumerate(bugs_data):
            qc_number = bug.get('qc_number', bug.get('bug_number', f'Bug-{i+1}'))
            
            # Check if this QC number already exists
            is_duplicate = self.is_duplicate_qc(qc_number)
            
            bug_info = {
                'bug_number': qc_number,
                'summary': bug.get('summary', f'Bug {i+1}'),
                'is_duplicate': is_duplicate,
                'manual_data': self._prepare_manual_data(bug)
            }
            
            if not is_duplicate:
                # Create URL with epic assignment
                params = {
                    'pid': self._get_project_id(),
                    'issuetype': '1',  # Bug
                    'summary': self._clean_text(bug.get('summary', f'QC {qc_number}')),
                    'description': self._format_description(bug),
                    'priority': self._map_priority(bug.get('priority', 'Medium')),
                    'labels': f"QC-Import,QC-{qc_number}",
                }
                
                # Add epic link if configured
                if self.epic_key:
                    params['customfield_10014'] = self.epic_key  # Epic Link field
                
                # Remove empty parameters
                params = {k: v for k, v in params.items() if v}
                
                # Create the URL
                base_url = f"{self.jira_url}/secure/CreateIssue!default.jspa"
                query_string = urlencode(params)
                bug_info['url'] = f"{base_url}?{query_string}"
            
            urls.append(bug_info)
        
        return urls
    
    def create_enhanced_html_report(self, bugs_data: List[Dict[str, Any]], output_file: str = 'enhanced_jira_bugs_report.html') -> str:
        """
        Create enhanced HTML report with duplicate checking and epic assignment
        """
        # First, check for existing QC numbers
        self.check_existing_qc_numbers()
        
        # Generate URLs with duplicate checking
        bug_info_list = self.generate_create_bug_urls(bugs_data)
        
        # Count duplicates and new bugs
        new_bugs = [b for b in bug_info_list if not b['is_duplicate']]
        duplicate_bugs = [b for b in bug_info_list if b['is_duplicate']]
        
        html_content = f"""
<!DOCTYPE html>
<html>
<head>
    <title>Enhanced Jira Bug Creation Report</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; background-color: #f5f5f5; }}
        .header {{ background-color: #0052cc; color: white; padding: 20px; border-radius: 5px; margin-bottom: 20px; }}
        .stats {{ background-color: #e8f4fd; padding: 15px; border-radius: 5px; margin-bottom: 20px; }}
        .bug-item {{ border: 1px solid #ddd; margin: 10px 0; padding: 15px; border-radius: 5px; background-color: white; }}
        .bug-item.duplicate {{ background-color: #fff3cd; border-color: #ffeaa7; }}
        .bug-number {{ font-weight: bold; color: #0052cc; }}
        .duplicate-badge {{ background-color: #f39c12; color: white; padding: 3px 8px; border-radius: 3px; font-size: 12px; }}
        .create-button {{ 
            background-color: #0052cc; 
            color: white; 
            padding: 10px 20px; 
            text-decoration: none; 
            border-radius: 3px; 
            display: inline-block; 
            margin: 10px 0;
        }}
        .create-button:hover {{ background-color: #003d99; }}
        .duplicate-message {{ 
            background-color: #f39c12; 
            color: white; 
            padding: 10px 20px; 
            border-radius: 3px; 
            display: inline-block; 
            margin: 10px 0;
        }}
        .manual-data {{ background-color: #f5f5f5; padding: 10px; margin: 10px 0; border-radius: 3px; }}
        .instructions {{ background-color: #d4edda; padding: 15px; margin: 20px 0; border-radius: 5px; }}
        .epic-info {{ background-color: #e8f4fd; padding: 10px; margin: 10px 0; border-radius: 3px; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>Enhanced Jira Bug Creation Report</h1>
        <p>Project: {self.project_key} | Epic: {self.epic_key if self.epic_key else 'Not specified'}</p>
        <p>Jira URL: {self.jira_url}</p>
    </div>
    
    <div class="stats">
        <h3>Summary:</h3>
        <ul>
            <li><strong>Total Bugs:</strong> {len(bugs_data)}</li>
            <li><strong>New Bugs:</strong> {len(new_bugs)} (will show create buttons)</li>
            <li><strong>Duplicate Bugs:</strong> {len(duplicate_bugs)} (already exist in Jira)</li>
        </ul>
    </div>
    
    <div class="instructions">
        <h3>Instructions:</h3>
        <ol>
            <li>Only <strong>NEW</strong> bugs will show "Create in Jira" buttons</li>
            <li>Click the button to open Jira with pre-filled form</li>
            <li>Bugs will be automatically assigned to epic: <strong>{self.epic_key if self.epic_key else 'No epic configured'}</strong></li>
            <li>Duplicate bugs are marked and won't have create buttons</li>
        </ol>
    </div>
"""

        # Show new bugs first
        if new_bugs:
            html_content += "<h2>🆕 New Bugs to Create</h2>"
            for i, bug_info in enumerate(new_bugs):
                html_content += f"""
    <div class="bug-item">
        <div class="bug-number">New Bug: {bug_info['bug_number']}</div>
        <h3>{bug_info['summary']}</h3>
        
        {"<div class='epic-info'><strong>Will be assigned to Epic:</strong> " + self.epic_key + "</div>" if self.epic_key else ""}
        
        <a href="{bug_info['url']}" target="_blank" class="create-button">Create in Jira</a>
        
        <div class="manual-data">
            <strong>Manual Entry Data (if needed):</strong><br>
            {bug_info['manual_data']}
        </div>
    </div>
"""

        # Show duplicate bugs
        if duplicate_bugs:
            html_content += "<h2>🔄 Duplicate Bugs (Already Exist)</h2>"
            for bug_info in duplicate_bugs:
                html_content += f"""
    <div class="bug-item duplicate">
        <div class="bug-number">Duplicate: {bug_info['bug_number']} <span class="duplicate-badge">EXISTS</span></div>
        <h3>{bug_info['summary']}</h3>
        
        <div class="duplicate-message">This QC number already exists in Jira - no action needed</div>
        
        <div class="manual-data">
            <strong>Original Data:</strong><br>
            {bug_info['manual_data']}
        </div>
    </div>
"""

        html_content += """
</body>
</html>
"""

        # Write to file
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        self.logger.info(f"Enhanced HTML report created: {output_file}")
        self.logger.info(f"New bugs: {len(new_bugs)}, Duplicates: {len(duplicate_bugs)}")
        
        return output_file
    
    def _get_project_id(self) -> str:
        """Get project ID"""
        return self.project_key
    
    def _clean_text(self, text: str) -> str:
        """Clean text for URL encoding"""
        if not text:
            return ""
        return str(text).strip()[:250]
    
    def _format_description(self, bug: Dict[str, Any]) -> str:
        """Format bug description with QC number"""
        description_parts = []
        
        if bug.get('qc_number'):
            description_parts.append(f"QC Number: {bug['qc_number']}")
        
        if bug.get('description'):
            description_parts.append(f"Description: {bug['description']}")
        
        if bug.get('steps'):
            description_parts.append(f"Steps to Reproduce: {bug['steps']}")
        
        if bug.get('expected_result'):
            description_parts.append(f"Expected Result: {bug['expected_result']}")
        
        if bug.get('actual_result'):
            description_parts.append(f"Actual Result: {bug['actual_result']}")
        
        if bug.get('environment'):
            description_parts.append(f"Environment: {bug['environment']}")
        
        return "\\n\\n".join(description_parts)
    
    def _map_priority(self, priority: str) -> str:
        """Map priority to Jira values"""
        priority_map = {
            'critical': 'Highest',
            'high': 'High', 
            'medium': 'Medium',
            'low': 'Low',
            'minor': 'Lowest'
        }
        return priority_map.get(str(priority).lower(), 'Medium')
    
    def _prepare_manual_data(self, bug: Dict[str, Any]) -> str:
        """Prepare manual entry data"""
        data_parts = []
        
        for key, value in bug.items():
            if value and key not in ['summary']:
                data_parts.append(f"<strong>{key.replace('_', ' ').title()}:</strong> {value}")
        
        return "<br>".join(data_parts)


def create_enhanced_solution(csv_file: str, config_file: str) -> str:
    """
    Create enhanced web interface solution with duplicate checking
    """
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    
    # Load configuration
    with open(config_file, 'r') as f:
        config = json.load(f)
    
    # Load CSV data
    bugs_data = []
    with open(csv_file, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            bugs_data.append(row)
    
    logger.info(f"Loaded {len(bugs_data)} bugs from {csv_file}")
    
    # Create enhanced web interface
    enhanced_interface = EnhancedJiraWebInterface(config['jira'])
    
    # Create enhanced HTML report
    output_file = enhanced_interface.create_enhanced_html_report(bugs_data)
    
    logger.info("Enhanced solution created successfully!")
    return output_file


if __name__ == "__main__":
    # Create enhanced solution
    output_file = create_enhanced_solution(
        'sample_data/bugs_input.csv',
        'config/your_corporate_jira_config.json'
    )
    
    print(f"Enhanced HTML report created: {output_file}")
    print("Features:")
    print("- Checks for existing QC numbers")
    print("- Assigns bugs to specified epic")
    print("- Hides create buttons for duplicates")
    print("- Shows summary of new vs duplicate bugs")