# Jira Bug Integration System

A comprehensive Python-based system for processing CSV bug data and automatically creating Jira issues with intelligent categorization, duplicate detection, and Work Breakdown Structure (WBS) integration.

## Features

### Core Functionality
- **CSV Processing**: Flexible column mapping handles various CSV formats
- **Jira Integration**: Full REST API integration with authentication support
- **Duplicate Detection**: Intelligent pattern matching using "QC ID" to prevent duplicates
- **WBS Categorization**: Automatic bug categorization and epic assignment
- **Priority Management**: Content-based priority determination
- **Comprehensive Logging**: Detailed logging with multiple levels and structured output

### Advanced Features
- **Test Mode**: Safe development and testing without Jira API calls
- **Dry Run Mode**: Validation before actual issue creation
- **API Interface**: Professional programmatic interface for integration
- **Component Assignment**: Automatic component assignment based on bug content
- **Epic Linking**: Automatic epic assignment based on WBS structure
- **Error Handling**: Robust error handling with detailed reporting

## Quick Start

### 1. Basic Usage
```bash
# Process CSV in dry-run mode with test mode enabled
python main.py --csv sample_data/bugs_input.csv --config config/jira_config.json --dry-run --test-mode

# Process CSV with actual Jira integration (requires valid credentials)
python main.py --csv sample_data/bugs_input.csv --config config/jira_config.json --dry-run
```

### 2. API Usage
```python
from api_interface import JiraBugIntegrationAPI

# Initialize API in test mode
api = JiraBugIntegrationAPI('config/jira_config.json', test_mode=True)

# Validate system
status = api.validate_system()
print(f"System Status: {status['overall_status']}")

# Process bugs
results = api.process_bugs_from_csv('sample_data/bugs_input.csv', dry_run=True)
print(f"Processed: {results['created']} bugs")

# Get WBS analysis
analysis = api.get_wbs_analysis('sample_data/bugs_input.csv')
print(f"Categories: {list(analysis['categorization_breakdown'].keys())}")
```

### 3. Quick Functions
```python
from api_interface import quick_process_csv, analyze_csv_wbs

# Quick processing
results = quick_process_csv('config.json', 'bugs.csv', dry_run=True, test_mode=True)

# Quick analysis
analysis = analyze_csv_wbs('config.json', 'bugs.csv')
```

## Configuration

### CSV Format
The system expects CSV files with these columns (flexible naming):
- **Bug number**: QC ID or bug identifier
- **Bug summary**: Short description of the bug
- **Bug description**: Detailed description
- **Detected by**: Reporter name/email
- **Assign to**: Assignee name/email

### Jira Configuration
Edit `config/jira_config.json`:
```json
{
  "jira": {
    "url": "https://your-domain.atlassian.net",
    "username": "your-email@domain.com",
    "password": "your-password",
    "api_token": "your-api-token",
    "project_key": "PROJ"
  }
}
```

### Environment Variables
Set these for secure credential management:
```bash
export JIRA_URL="https://your-domain.atlassian.net"
export JIRA_USERNAME="your-email@domain.com"
export JIRA_API_TOKEN="your-api-token"
export JIRA_PROJECT_KEY="PROJ"
```

## WBS Structure

The system automatically categorizes bugs into these categories:

### UI Category
- **Keywords**: ui, interface, button, page, mobile, screen, display
- **Components**: Frontend, Mobile, Web
- **Epic**: QC-UI-EPIC

### Backend Category
- **Keywords**: api, database, server, connection, timeout, authentication
- **Components**: API, Database, Authentication
- **Epic**: QC-BE-EPIC

### Performance Category
- **Keywords**: slow, performance, loading, timeout, speed, delay
- **Components**: Load Testing, Performance
- **Epic**: QC-PERF-EPIC

### Security Category
- **Keywords**: security, password, authentication, authorization, access
- **Components**: Authentication, Authorization, Data Protection
- **Epic**: QC-SEC-EPIC

## Installation

```bash
# Install dependencies
pip install pandas requests jsonschema pytest

# Clone/download the system files
# Configure your Jira settings in config/jira_config.json
# Run the demo
python demo.py
```

## Testing

### Run Tests
```bash
# Run unit tests
pytest tests/

# Run system demonstration
python demo.py

# Test with sample data
python main.py --csv sample_data/bugs_input.csv --config config/jira_config.json --dry-run --test-mode
```

### Test Data
- `sample_data/bugs_input.csv`: Basic test data (10 bugs)
- `sample_data/comprehensive_bugs.csv`: Advanced test data (15 bugs with diverse categories)

## Logging

The system provides comprehensive logging:
- **Console Output**: Real-time processing information
- **File Logging**: Detailed logs saved to `jira_integration.log`
- **Structured Logging**: API operations with structured format
- **Debug Mode**: Detailed debugging information with `--log-level DEBUG`

## Error Handling

- **Authentication Errors**: Clear messages for credential issues
- **CSV Validation**: Detailed validation with suggestions for fixes
- **Duplicate Detection**: Intelligent matching with pattern explanation
- **API Errors**: Detailed Jira API error parsing and reporting

## Advanced Usage

### Bulk Duplicate Check
```python
api = JiraBugIntegrationAPI('config.json', test_mode=True)
bug_numbers = ['QC001', 'QC002', 'QC003']
results = api.check_for_duplicates(bug_numbers, 'PROJ')
```

### System Validation
```python
api = JiraBugIntegrationAPI('config.json')
validation = api.validate_system()
if validation['overall_status'] == 'READY':
    # Proceed with processing
    pass
```

### WBS Structure Export
```python
from wbs_structure_manager import WBSStructureManager
wbs = WBSStructureManager({})
wbs.export_wbs_structure('wbs_export.json')
```

## Architecture

### Modular Design
- **main.py**: Command-line interface and orchestration
- **api_interface.py**: Professional API for programmatic access
- **jira_integration.py**: Jira REST API communication
- **csv_processor.py**: CSV file processing and validation
- **config_manager.py**: Configuration management with validation
- **duplicate_checker.py**: Duplicate detection with caching
- **wbs_structure_manager.py**: Work breakdown structure management
- **logger_setup.py**: Comprehensive logging configuration

### Data Flow
1. **Configuration Loading**: JSON config with environment overrides
2. **CSV Processing**: Flexible parsing with column normalization
3. **WBS Categorization**: Content analysis for intelligent categorization
4. **Duplicate Detection**: Cache-based duplicate checking
5. **Issue Creation**: Jira API integration with enhanced templates
6. **Logging**: Comprehensive activity logging

## Security

- **Credential Management**: Environment variable support
- **API Token Support**: Recommended over password authentication
- **Test Mode**: Safe development without API calls
- **Input Validation**: Comprehensive validation of all inputs
- **Error Sanitization**: Safe error reporting without credential exposure

## Performance

- **Caching**: Duplicate detection uses in-memory caching
- **Batch Processing**: Efficient processing of large CSV files
- **Connection Management**: Persistent HTTP connections
- **Memory Management**: Efficient pandas operations
- **Logging Optimization**: Configurable logging levels

## Contributing

1. Follow the modular architecture
2. Add comprehensive logging to new features
3. Include unit tests for new functionality
4. Update documentation for API changes
5. Use structured logging for operations
6. Maintain backwards compatibility

## Support

For issues or questions:
1. Check the logs in `jira_integration.log`
2. Run in test mode to validate configuration
3. Use the demo script to verify functionality
4. Review the comprehensive error messages
5. Validate your CSV format and Jira credentials

## License

This system is designed for internal use and integration with Jira systems. Ensure compliance with your organization's API usage policies.