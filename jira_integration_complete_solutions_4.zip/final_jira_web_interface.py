"""
Final Jira Web Interface with Working URLs and Bug List Display
Uses your actual working Jira URLs for bug creation and filtering
"""

import logging
import json
import csv
import requests
import urllib3
from typing import Dict, Any, List, Optional
from urllib.parse import urlencode, quote

# Disable SSL warnings for corporate environments
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class FinalJiraWebInterface:
    """Final web interface with your working Jira URLs"""
    
    def __init__(self, jira_config: Dict[str, Any]):
        """Initialize with your configuration"""
        self.jira_config = jira_config
        self.jira_url = jira_config.get('url', '').rstrip('/')
        self.project_key = jira_config.get('project_key', '16400')  # Your project ID
        self.epic_key = jira_config.get('epic_key', 'ASUVNG-1840')
        self.username = jira_config.get('username', '')
        self.password = jira_config.get('password', '')
        
        self.logger = logging.getLogger(__name__)
        self.session = self._create_session()
        
        # Your working URLs
        self.create_url_template = "https://jira.esl.corp.elbit.co.il/secure/CreateIssueDetails!init.jspa"
        self.filter_url = "https://jira.esl.corp.elbit.co.il/issues/?jql=project=16400%20AND%20issuetype=Bug%20AND%20summary%20~%20%22QC%20ID%23%22"
    
    def _create_session(self) -> requests.Session:
        """Create authenticated session for API calls"""
        session = requests.Session()
        session.verify = False  # For corporate SSL issues
        session.auth = (self.username, self.password)
        session.headers.update({
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        })
        return session
    
    def get_existing_qc_bugs(self) -> List[Dict[str, Any]]:
        """Get existing QC bugs from your Jira using the working filter URL"""
        try:
            self.logger.info("Fetching existing QC bugs from Jira...")
            
            # Use JQL from your working filter URL
            jql = 'project=16400 AND issuetype=Bug AND summary ~ "QC ID#"'
            url = f"{self.jira_url}/rest/api/2/search"
            
            params = {
                'jql': jql,
                'fields': 'key,summary,status,assignee,created,description',
                'maxResults': 1000
            }
            
            response = self.session.get(url, params=params, timeout=30)
            
            if response.status_code == 200:
                result = response.json()
                issues = result.get('issues', [])
                self.logger.info(f"Found {len(issues)} existing QC bugs")
                
                existing_bugs = []
                for issue in issues:
                    fields = issue.get('fields', {})
                    existing_bugs.append({
                        'key': issue.get('key'),
                        'summary': fields.get('summary', ''),
                        'status': fields.get('status', {}).get('name', ''),
                        'assignee': fields.get('assignee', {}).get('displayName', 'Unassigned') if fields.get('assignee') else 'Unassigned',
                        'created': fields.get('created', ''),
                        'description': fields.get('description', '')
                    })
                
                return existing_bugs
            else:
                self.logger.warning(f"Could not fetch existing bugs. Status: {response.status_code}")
                return []
                
        except Exception as e:
            self.logger.warning(f"Error fetching existing bugs: {e}")
            return []
    
    def extract_qc_number(self, text: str) -> Optional[str]:
        """Extract QC number from text"""
        if not text:
            return None
        
        import re
        # Look for QC ID# patterns
        matches = re.findall(r'QC\s*ID#?\s*(\d+)', text, re.IGNORECASE)
        if matches:
            return matches[0]
        
        # Look for QC followed by number
        matches = re.findall(r'QC[- ]?(\d+)', text, re.IGNORECASE)
        if matches:
            return matches[0]
        
        return None
    
    def generate_working_bug_urls(self, bugs_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Generate URLs using your working create URL format"""
        urls = []
        
        # Get existing bugs to check for duplicates
        existing_bugs = self.get_existing_qc_bugs()
        existing_qc_numbers = set()
        
        for bug in existing_bugs:
            qc_num = self.extract_qc_number(bug['summary'])
            if qc_num:
                existing_qc_numbers.add(qc_num)
        
        for i, bug in enumerate(bugs_data):
            qc_number = bug.get('qc_number', bug.get('bug_number', f'{i+1}'))
            clean_qc = str(qc_number).replace('QC', '').replace('-', '').strip()
            
            # Check if duplicate
            is_duplicate = clean_qc in existing_qc_numbers
            
            bug_info = {
                'bug_number': qc_number,
                'summary': bug.get('summary', f'QC ID#{qc_number}'),
                'is_duplicate': is_duplicate,
                'manual_data': self._prepare_manual_data(bug)
            }
            
            if not is_duplicate:
                # Use your working URL format
                params = {
                    'pid': '16400',  # Your project ID
                    'issuetype': '10004',  # Your bug issue type ID
                    'summary': f"QC ID#{qc_number} - {bug.get('summary', 'Bug')}",
                    'description': self._format_description(bug),
                    'customfield_10008': 'ASUVNG-1840'  # Your epic field
                }
                
                # Create URL
                query_string = urlencode(params)
                bug_info['url'] = f"{self.create_url_template}?{query_string}"
            
            urls.append(bug_info)
        
        return urls, existing_bugs
    
    def create_final_html_report(self, bugs_data: List[Dict[str, Any]], output_file: str = 'final_jira_bugs_report.html') -> str:
        """Create final HTML report with existing bug list and new bug creation"""
        
        # Generate URLs and get existing bugs
        bug_info_list, existing_bugs = self.generate_working_bug_urls(bugs_data)
        
        # Count stats
        new_bugs = [b for b in bug_info_list if not b['is_duplicate']]
        duplicate_bugs = [b for b in bug_info_list if b['is_duplicate']]
        
        html_content = f"""
<!DOCTYPE html>
<html>
<head>
    <title>Final Jira Bug Management Report</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; background-color: #f5f5f5; }}
        .header {{ background-color: #0052cc; color: white; padding: 20px; border-radius: 5px; margin-bottom: 20px; }}
        .nav-tabs {{ display: flex; margin-bottom: 20px; }}
        .nav-tab {{ 
            background-color: #ddd; 
            border: none; 
            padding: 10px 20px; 
            cursor: pointer; 
            border-radius: 5px 5px 0 0;
            margin-right: 5px;
        }}
        .nav-tab.active {{ background-color: #0052cc; color: white; }}
        .tab-content {{ display: none; }}
        .tab-content.active {{ display: block; }}
        .stats {{ background-color: #e8f4fd; padding: 15px; border-radius: 5px; margin-bottom: 20px; }}
        .bug-item {{ border: 1px solid #ddd; margin: 10px 0; padding: 15px; border-radius: 5px; background-color: white; }}
        .bug-item.duplicate {{ background-color: #fff3cd; border-color: #ffeaa7; }}
        .bug-item.existing {{ background-color: #f8f9fa; border-color: #dee2e6; }}
        .bug-number {{ font-weight: bold; color: #0052cc; }}
        .bug-status {{ padding: 3px 8px; border-radius: 3px; font-size: 12px; color: white; }}
        .status-todo {{ background-color: #6c757d; }}
        .status-inprogress {{ background-color: #007bff; }}
        .status-done {{ background-color: #28a745; }}
        .duplicate-badge {{ background-color: #f39c12; color: white; padding: 3px 8px; border-radius: 3px; font-size: 12px; }}
        .create-button {{ 
            background-color: #0052cc; 
            color: white; 
            padding: 10px 20px; 
            text-decoration: none; 
            border-radius: 3px; 
            display: inline-block; 
            margin: 10px 0;
        }}
        .create-button:hover {{ background-color: #003d99; }}
        .view-button {{ 
            background-color: #6c757d; 
            color: white; 
            padding: 8px 15px; 
            text-decoration: none; 
            border-radius: 3px; 
            font-size: 12px;
            margin: 5px 0;
        }}
        .filter-button {{ 
            background-color: #28a745; 
            color: white; 
            padding: 10px 20px; 
            text-decoration: none; 
            border-radius: 3px; 
            display: inline-block; 
            margin: 10px 0;
        }}
        .duplicate-message {{ 
            background-color: #f39c12; 
            color: white; 
            padding: 10px 20px; 
            border-radius: 3px; 
            display: inline-block; 
            margin: 10px 0;
        }}
        .manual-data {{ background-color: #f5f5f5; padding: 10px; margin: 10px 0; border-radius: 3px; }}
        .epic-info {{ background-color: #e8f4fd; padding: 10px; margin: 10px 0; border-radius: 3px; }}
        .table {{ width: 100%; border-collapse: collapse; margin: 10px 0; }}
        .table th, .table td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
        .table th {{ background-color: #f8f9fa; }}
    </style>
    <script>
        function showTab(tabName) {{
            // Hide all tabs
            var tabs = document.getElementsByClassName('tab-content');
            for (var i = 0; i < tabs.length; i++) {{
                tabs[i].classList.remove('active');
            }}
            
            // Remove active from all nav tabs
            var navTabs = document.getElementsByClassName('nav-tab');
            for (var i = 0; i < navTabs.length; i++) {{
                navTabs[i].classList.remove('active');
            }}
            
            // Show selected tab
            document.getElementById(tabName).classList.add('active');
            event.target.classList.add('active');
        }}
    </script>
</head>
<body>
    <div class="header">
        <h1>Final Jira Bug Management Report</h1>
        <p>Project: {self.project_key} | Epic: {self.epic_key}</p>
        <p>Jira URL: {self.jira_url}</p>
    </div>
    
    <div class="nav-tabs">
        <button class="nav-tab active" onclick="showTab('existing-bugs')">Existing QC Bugs ({len(existing_bugs)})</button>
        <button class="nav-tab" onclick="showTab('new-bugs')">New Bugs to Create ({len(new_bugs)})</button>
        <button class="nav-tab" onclick="showTab('duplicates')">Duplicates ({len(duplicate_bugs)})</button>
    </div>
    
    <div id="existing-bugs" class="tab-content active">
        <div class="stats">
            <h3>Existing QC Bugs in Your Jira:</h3>
            <p>Total: {len(existing_bugs)} bugs found</p>
            <a href="{self.filter_url}" target="_blank" class="filter-button">View All in Jira Filter</a>
        </div>
        
        <table class="table">
            <thead>
                <tr>
                    <th>Bug Key</th>
                    <th>Summary</th>
                    <th>Status</th>
                    <th>Assignee</th>
                    <th>Created</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
"""

        # Add existing bugs to table
        for bug in existing_bugs:
            status_class = bug['status'].lower().replace(' ', '')
            html_content += f"""
                <tr>
                    <td><strong>{bug['key']}</strong></td>
                    <td>{bug['summary']}</td>
                    <td><span class="bug-status status-{status_class}">{bug['status']}</span></td>
                    <td>{bug['assignee']}</td>
                    <td>{bug['created'][:10] if bug['created'] else 'N/A'}</td>
                    <td><a href="{self.jira_url}/browse/{bug['key']}" target="_blank" class="view-button">View</a></td>
                </tr>
"""

        html_content += """
            </tbody>
        </table>
    </div>
    
    <div id="new-bugs" class="tab-content">
        <div class="stats">
            <h3>New Bugs to Create:</h3>
            <p>These QC numbers don't exist in Jira yet</p>
        </div>
"""

        # Add new bugs
        for bug_info in new_bugs:
            html_content += f"""
        <div class="bug-item">
            <div class="bug-number">New: {bug_info['bug_number']}</div>
            <h3>{bug_info['summary']}</h3>
            
            <div class="epic-info"><strong>Will be assigned to Epic:</strong> {self.epic_key}</div>
            
            <a href="{bug_info['url']}" target="_blank" class="create-button">Create in Jira</a>
            
            <div class="manual-data">
                <strong>Bug Details:</strong><br>
                {bug_info['manual_data']}
            </div>
        </div>
"""

        html_content += """
    </div>
    
    <div id="duplicates" class="tab-content">
        <div class="stats">
            <h3>Duplicate Bugs:</h3>
            <p>These QC numbers already exist in Jira</p>
        </div>
"""

        # Add duplicate bugs
        for bug_info in duplicate_bugs:
            html_content += f"""
        <div class="bug-item duplicate">
            <div class="bug-number">Duplicate: {bug_info['bug_number']} <span class="duplicate-badge">EXISTS</span></div>
            <h3>{bug_info['summary']}</h3>
            
            <div class="duplicate-message">This QC number already exists in Jira</div>
            
            <div class="manual-data">
                <strong>Original Data:</strong><br>
                {bug_info['manual_data']}
            </div>
        </div>
"""

        html_content += """
    </div>
</body>
</html>
"""

        # Write to file
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        self.logger.info(f"Final HTML report created: {output_file}")
        self.logger.info(f"Existing bugs: {len(existing_bugs)}, New bugs: {len(new_bugs)}, Duplicates: {len(duplicate_bugs)}")
        
        return output_file
    
    def _format_description(self, bug: Dict[str, Any]) -> str:
        """Format bug description"""
        description_parts = []
        
        if bug.get('qc_number'):
            description_parts.append(f"QC Number: {bug['qc_number']}")
        
        if bug.get('description'):
            description_parts.append(f"Description: {bug['description']}")
        
        if bug.get('steps'):
            description_parts.append(f"Steps to Reproduce: {bug['steps']}")
        
        if bug.get('expected_result'):
            description_parts.append(f"Expected Result: {bug['expected_result']}")
        
        if bug.get('actual_result'):
            description_parts.append(f"Actual Result: {bug['actual_result']}")
        
        if bug.get('environment'):
            description_parts.append(f"Environment: {bug['environment']}")
        
        return " | ".join(description_parts)
    
    def _prepare_manual_data(self, bug: Dict[str, Any]) -> str:
        """Prepare manual entry data"""
        data_parts = []
        
        for key, value in bug.items():
            if value and key not in ['summary']:
                data_parts.append(f"<strong>{key.replace('_', ' ').title()}:</strong> {value}")
        
        return "<br>".join(data_parts)


def create_final_solution(csv_file: str, config_file: str) -> str:
    """Create final solution with working URLs"""
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    
    # Load configuration
    with open(config_file, 'r') as f:
        config = json.load(f)
    
    # Load CSV data
    bugs_data = []
    with open(csv_file, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            bugs_data.append(row)
    
    logger.info(f"Loaded {len(bugs_data)} bugs from {csv_file}")
    
    # Create final web interface
    final_interface = FinalJiraWebInterface(config['jira'])
    
    # Create final HTML report
    output_file = final_interface.create_final_html_report(bugs_data)
    
    logger.info("Final solution created successfully!")
    return output_file


if __name__ == "__main__":
    # Create final solution
    output_file = create_final_solution(
        'sample_data/bugs_input.csv',
        'config/your_corporate_jira_config.json'
    )
    
    print(f"Final HTML report created: {output_file}")
    print("Features:")
    print("- Uses your working Jira URLs")
    print("- Shows existing QC bugs from your project")
    print("- Creates new bugs with correct format")
    print("- Assigns to Epic ASUVNG-1840")
    print("- Three tabs: Existing | New | Duplicates")