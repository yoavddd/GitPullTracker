"""
Export Existing QC Bugs from Jira and Compare with Input CSV
Creates a standalone HTML page that helps you export and compare bugs
"""

import json
import csv
import logging
from typing import Dict, Any, List, Set

class BugExportManager:
    """Manages exporting and comparing QC bugs"""
    
    def __init__(self, jira_config: Dict[str, Any]):
        """Initialize with Jira configuration"""
        self.jira_config = jira_config
        self.jira_url = jira_config.get('url', '').rstrip('/')
        self.project_key = jira_config.get('project_key', '16400')
        self.logger = logging.getLogger(__name__)
        
        # Your working filter URL
        self.filter_url = f"https://jira.esl.corp.elbit.co.il/issues/?jql=project={self.project_key}%20AND%20issuetype=Bug%20AND%20summary%20~%20%22QC%20ID%23%22"
        self.api_url = f"{self.jira_url}/rest/api/2/search?jql=project={self.project_key}%20AND%20issuetype=Bug%20AND%20summary%20~%20%22QC%20ID%23%22&fields=key,summary,status,assignee,created,description&maxResults=1000"
    
    def create_export_instructions_html(self, input_csv_path: str, output_file: str = 'export_existing_bugs.html') -> str:
        """Create HTML with instructions to export existing bugs and compare"""
        
        # Load input CSV to show what we're comparing against
        input_bugs = []
        try:
            with open(input_csv_path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    input_bugs.append(row)
        except Exception as e:
            self.logger.warning(f"Could not load input CSV: {e}")
        
        html_content = f"""
<!DOCTYPE html>
<html>
<head>
    <title>Export and Compare QC Bugs</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; background-color: #f5f5f5; }}
        .header {{ background-color: #0052cc; color: white; padding: 20px; border-radius: 5px; margin-bottom: 20px; }}
        .section {{ background-color: white; padding: 20px; margin: 20px 0; border-radius: 5px; border: 1px solid #ddd; }}
        .step {{ background-color: #e8f4fd; padding: 15px; margin: 10px 0; border-radius: 5px; border-left: 4px solid #0052cc; }}
        .url-box {{ background-color: #f8f9fa; padding: 10px; border: 1px solid #dee2e6; border-radius: 3px; font-family: monospace; word-break: break-all; }}
        .button {{ 
            background-color: #0052cc; 
            color: white; 
            padding: 10px 20px; 
            text-decoration: none; 
            border-radius: 3px; 
            display: inline-block; 
            margin: 10px 5px 10px 0;
        }}
        .button:hover {{ background-color: #003d99; }}
        .export-button {{ background-color: #28a745; }}
        .compare-button {{ background-color: #ffc107; color: black; }}
        .table {{ width: 100%; border-collapse: collapse; margin: 10px 0; }}
        .table th, .table td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
        .table th {{ background-color: #f8f9fa; }}
        .input-area {{ width: 100%; height: 200px; border: 1px solid #ddd; padding: 10px; font-family: monospace; }}
        .comparison-result {{ background-color: #fff3cd; padding: 15px; border-radius: 5px; margin: 10px 0; }}
        .duplicate {{ background-color: #f8d7da; }}
        .new {{ background-color: #d4edda; }}
    </style>
    <script>
        function openJiraFilter() {{
            window.open('{self.filter_url}', '_blank');
        }}
        
        function copyApiUrl() {{
            navigator.clipboard.writeText('{self.api_url}');
            alert('API URL copied to clipboard!');
        }}
        
        function parseJiraData() {{
            const jiraData = document.getElementById('jiraData').value;
            const inputBugs = {json.dumps([bug.get('qc_number', bug.get('bug_number', '')) for bug in input_bugs])};
            
            try {{
                const data = JSON.parse(jiraData);
                const existingBugs = [];
                const existingQCNumbers = new Set();
                
                // Parse Jira API response
                if (data.issues) {{
                    data.issues.forEach(issue => {{
                        const summary = issue.fields.summary || '';
                        const qcMatch = summary.match(/QC\\s*ID#?\\s*(\\d+)/i);
                        if (qcMatch) {{
                            const qcNum = qcMatch[1];
                            existingQCNumbers.add(qcNum);
                            existingBugs.push({{
                                key: issue.key,
                                summary: summary,
                                qc_number: qcNum,
                                status: issue.fields.status ? issue.fields.status.name : 'Unknown',
                                assignee: issue.fields.assignee ? issue.fields.assignee.displayName : 'Unassigned'
                            }});
                        }}
                    }});
                }}
                
                // Compare with input CSV
                const newBugs = [];
                const duplicateBugs = [];
                
                inputBugs.forEach(inputQC => {{
                    const cleanQC = inputQC.replace(/[^0-9]/g, '');
                    if (existingQCNumbers.has(cleanQC)) {{
                        duplicateBugs.push(inputQC);
                    }} else {{
                        newBugs.push(inputQC);
                    }}
                }});
                
                // Display results
                displayResults(existingBugs, newBugs, duplicateBugs);
                
            }} catch (e) {{
                alert('Error parsing JSON data: ' + e.message);
            }}
        }}
        
        function displayResults(existingBugs, newBugs, duplicateBugs) {{
            const resultsDiv = document.getElementById('results');
            
            let html = '<h3>Comparison Results:</h3>';
            
            // Existing bugs table
            html += '<h4>Existing QC Bugs in Jira (' + existingBugs.length + '):</h4>';
            html += '<table class="table"><thead><tr><th>QC#</th><th>Key</th><th>Summary</th><th>Status</th><th>Assignee</th></tr></thead><tbody>';
            existingBugs.forEach(bug => {{
                html += `<tr><td>${{bug.qc_number}}</td><td>${{bug.key}}</td><td>${{bug.summary}}</td><td>${{bug.status}}</td><td>${{bug.assignee}}</td></tr>`;
            }});
            html += '</tbody></table>';
            
            // New bugs
            html += '<h4 class="new">New QC Numbers to Create (' + newBugs.length + '):</h4>';
            html += '<div class="comparison-result new">';
            newBugs.forEach(qc => {{
                html += '<span style="margin: 5px; padding: 5px; background: #28a745; color: white; border-radius: 3px;">' + qc + '</span> ';
            }});
            html += '</div>';
            
            // Duplicates
            html += '<h4 class="duplicate">Duplicate QC Numbers (Skip These) (' + duplicateBugs.length + '):</h4>';
            html += '<div class="comparison-result duplicate">';
            duplicateBugs.forEach(qc => {{
                html += '<span style="margin: 5px; padding: 5px; background: #dc3545; color: white; border-radius: 3px;">' + qc + '</span> ';
            }});
            html += '</div>';
            
            resultsDiv.innerHTML = html;
        }}
    </script>
</head>
<body>
    <div class="header">
        <h1>Export and Compare QC Bugs</h1>
        <p>Project: {self.project_key} | Total Input Bugs: {len(input_bugs)}</p>
    </div>
    
    <div class="section">
        <h2>Step 1: Get Existing QC Bugs from Jira</h2>
        
        <div class="step">
            <h3>Option A: Use Jira Filter (Manual)</h3>
            <p>Click to open your QC bugs filter in Jira:</p>
            <button class="button" onclick="openJiraFilter()">Open QC Bugs Filter</button>
            <p>Then manually compare the QC numbers you see with your input CSV.</p>
        </div>
        
        <div class="step">
            <h3>Option B: Use API Call (Automatic)</h3>
            <p>Copy this API URL and open it in your browser (you'll need to be logged into Jira):</p>
            <div class="url-box">{self.api_url}</div>
            <button class="button export-button" onclick="copyApiUrl()">Copy API URL</button>
            
            <p><strong>Instructions:</strong></p>
            <ol>
                <li>Copy the API URL above</li>
                <li>Open it in a new browser tab (while logged into Jira)</li>
                <li>Copy the entire JSON response</li>
                <li>Paste it in the text area below</li>
                <li>Click "Compare with Input CSV"</li>
            </ol>
        </div>
    </div>
    
    <div class="section">
        <h2>Step 2: Paste Jira API Response Here</h2>
        <textarea id="jiraData" class="input-area" placeholder="Paste the JSON response from the API URL here..."></textarea>
        <br>
        <button class="button compare-button" onclick="parseJiraData()">Compare with Input CSV</button>
    </div>
    
    <div class="section">
        <h2>Step 3: Your Input CSV Data</h2>
        <p>QC numbers from your input CSV:</p>
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>QC Number</th>
                    <th>Summary</th>
                    <th>Other Data</th>
                </tr>
            </thead>
            <tbody>
"""

        # Show input CSV data
        for i, bug in enumerate(input_bugs[:20]):  # Show first 20
            qc_num = bug.get('qc_number', bug.get('bug_number', f'Bug-{i+1}'))
            summary = bug.get('summary', bug.get('bug_summery', 'No summary'))
            other_data = ', '.join([f"{k}: {v}" for k, v in bug.items() if k not in ['qc_number', 'bug_number', 'summary', 'bug_summery'] and v])[:100]
            
            html_content += f"""
                <tr>
                    <td>{i+1}</td>
                    <td><strong>{qc_num}</strong></td>
                    <td>{summary}</td>
                    <td>{other_data}...</td>
                </tr>
"""

        if len(input_bugs) > 20:
            html_content += f"""
                <tr>
                    <td colspan="4"><em>... and {len(input_bugs) - 20} more bugs</em></td>
                </tr>
"""

        html_content += """
            </tbody>
        </table>
    </div>
    
    <div class="section">
        <h2>Step 4: Comparison Results</h2>
        <div id="results">
            <p><em>Paste Jira API response above and click "Compare with Input CSV" to see results.</em></p>
        </div>
    </div>
    
    <div class="section">
        <h2>Alternative: Manual Export</h2>
        <div class="step">
            <p>If the API method doesn't work, you can manually export from Jira:</p>
            <ol>
                <li>Go to your QC bugs filter in Jira</li>
                <li>Click "Export" → "Excel CSV (all fields)"</li>
                <li>Open the exported CSV file</li>
                <li>Look at the Summary column for QC ID numbers</li>
                <li>Manually compare with your input CSV</li>
            </ol>
        </div>
    </div>
</body>
</html>
"""

        # Write to file
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        self.logger.info(f"Export instructions created: {output_file}")
        return output_file
    
    def create_comparison_csv(self, input_csv_path: str, existing_qc_numbers: Set[str], output_file: str = 'bug_comparison.csv') -> str:
        """Create a CSV comparing input bugs with existing ones"""
        
        comparison_data = []
        
        try:
            with open(input_csv_path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    qc_number = row.get('qc_number', row.get('bug_number', ''))
                    clean_qc = str(qc_number).replace('QC', '').replace('-', '').strip()
                    
                    status = 'DUPLICATE' if clean_qc in existing_qc_numbers else 'NEW'
                    
                    comparison_data.append({
                        'QC_Number': qc_number,
                        'Summary': row.get('summary', row.get('bug_summery', '')),
                        'Status': status,
                        'Action': 'Skip - already exists' if status == 'DUPLICATE' else 'Create in Jira',
                        'Original_Data': json.dumps(row)
                    })
        
        except Exception as e:
            self.logger.error(f"Error creating comparison CSV: {e}")
            return ""
        
        # Write comparison CSV
        with open(output_file, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = ['QC_Number', 'Summary', 'Status', 'Action', 'Original_Data']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(comparison_data)
        
        self.logger.info(f"Comparison CSV created: {output_file}")
        return output_file


def create_export_solution(csv_file: str, config_file: str) -> Dict[str, str]:
    """Create export and comparison solution"""
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    
    # Load configuration
    with open(config_file, 'r') as f:
        config = json.load(f)
    
    # Create export manager
    export_manager = BugExportManager(config['jira'])
    
    # Create export instructions HTML
    export_html = export_manager.create_export_instructions_html(csv_file)
    
    logger.info("Export solution created successfully!")
    
    return {
        'export_html': export_html,
        'api_url': export_manager.api_url,
        'filter_url': export_manager.filter_url
    }


if __name__ == "__main__":
    # Create export solution
    outputs = create_export_solution(
        'sample_data/bugs_input.csv',
        'config/your_corporate_jira_config.json'
    )
    
    print("Export solution created:")
    for name, path in outputs.items():
        print(f"  {name}: {path}")
    
    print("\nInstructions:")
    print("1. Open export_existing_bugs.html")
    print("2. Use the API URL to get existing bugs from Jira")
    print("3. Compare with your input CSV automatically")