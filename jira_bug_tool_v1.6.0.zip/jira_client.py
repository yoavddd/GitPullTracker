"""
JIRA Client Module
Handles all JIRA API interactions including authentication, searching, and issue creation.
"""

import base64
import json
import logging
import requests
from typing import Dict, Any, Optional, List
from urllib.parse import urljoin


class JiraClient:
    """Client for interacting with JIRA REST API."""
    
    def __init__(self, config: Dict[str, Any]):
        """Initialize JIRA client with configuration."""
        self.logger = logging.getLogger(__name__)
        self.config = config
        
        # Extract JIRA configuration
        jira_config = config.get('jira', {})
        self.base_url = jira_config.get('url', '').rstrip('/')
        self.username = jira_config.get('username', '')
        self.password = jira_config.get('password', '')
        self.project_key = jira_config.get('project_key', '')
        self.epic_key = jira_config.get('epic_key', '')
        self.structure_board_id = jira_config.get('structure_board_id', '')
        
        # Setup authentication
        self.session = requests.Session()
        self.session.timeout = 30
        self.session.verify = False  # Disable SSL certificate verification
        
        if self.username and self.password:
            # Use Basic Authentication with base64 encoding as provided by user
            user_pass = f"{self.username}:{self.password}"
            encoded_credentials = base64.b64encode(user_pass.encode()).decode()
            
            # Set headers for every session as requested by user
            self.headers = {
                'Authorization': f'Basic {encoded_credentials}',
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'User-Agent': 'JIRA-Bug-Tool/1.0.0'
            }
            
            # Also set on session for backward compatibility
            self.session.headers.update(self.headers)
            
            self.logger.info(f"Initialized JIRA client for {self.base_url}")
            self.logger.debug(f"Headers set: Authorization=Basic [HIDDEN], Content-Type=application/json, Accept=application/json")
        else:
            self.logger.error("JIRA credentials not provided")
            raise ValueError("JIRA username and password are required")
    
    def test_connection(self) -> bool:
        """Test connection to JIRA instance."""
        try:
            url = urljoin(self.base_url, '/rest/api/2/myself')
            self.logger.debug(f"Testing connection to: {url}")
            
            response = self.session.get(url, headers=self.headers, verify=False)
            
            if response.status_code == 200:
                user_info = response.json()
                self.logger.info(f"Successfully connected to JIRA as: {user_info.get('displayName', 'Unknown')}")
                return True
            else:
                self.logger.error(f"Connection test failed: {response.status_code} - {response.text}")
                return False
                
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Connection test failed with exception: {str(e)}")
            return False
    
    def fetch_all_open_issues(self) -> List[Dict[str, Any]]:
        """Fetch all open issues from JIRA using the provided API link."""
        try:
            # Use the provided JQL query to get all open issues
            jql = f'project={self.project_key} AND statusCategory != Done AND status != Cancelled'
            url = urljoin(self.base_url, '/rest/api/2/search')
            
            # Get max_results from configuration
            max_results = self.config.get('jira', {}).get('max_results', 9999)
            
            params = {
                'jql': jql,
                'fields': 'key,summary,status',
                'maxResults': max_results
            }
            
            self.logger.info(f"Fetching all open issues for offline searching...")
            self.logger.debug(f"Using JQL: {jql}")
            
            response = self.session.get(url, params=params, headers=self.headers, verify=False)
            
            if response.status_code == 200:
                result = response.json()
                issues = result.get('issues', [])
                total = result.get('total', len(issues))
                self.logger.info(f"Fetched {len(issues)} open issues (total: {total}) for offline searching")
                
                # If there are more issues than maxResults, warn user
                if total > len(issues):
                    self.logger.warning(f"Only fetched {len(issues)} out of {total} total issues. Consider increasing maxResults if needed.")
                
                return issues
            else:
                self.logger.error(f"Failed to fetch open issues: {response.status_code} - {response.text}")
                return []
                
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Request failed while fetching open issues: {str(e)}")
            return []
        except Exception as e:
            self.logger.error(f"Unexpected error while fetching open issues: {str(e)}")
            return []
    
    def search_existing_issue(self, search_pattern: str) -> Optional[Dict[str, Any]]:
        """Search for existing issue containing the search pattern in summary using offline search."""
        try:
            # Extract defect ID from the search pattern
            defect_id = search_pattern.replace("QC ID ", "").strip()
            
            # Fetch all open issues if not already cached (single API call)
            if not hasattr(self, '_cached_issues'):
                self._cached_issues = self.fetch_all_open_issues()
            
            # Build multiple search patterns to handle different formats
            search_patterns = [
                f"QC ID {defect_id}",     # QC ID 12345
                f"QC ID# {defect_id}",    # QC ID# 12345
                f"QC ID #{defect_id}",    # QC ID #12345
                f"QC_ID {defect_id}",     # QC_ID 12345
                f"QC_ID#{defect_id}",     # QC_ID#12345
                f"QC ID-{defect_id}",     # QC ID-12345
                defect_id                 # Just the ID number
            ]
            
            # Search through cached issues offline (much faster)
            for issue in self._cached_issues:
                issue_summary = issue.get('fields', {}).get('summary', '')
                
                for pattern in search_patterns:
                    if pattern.lower() in issue_summary.lower():
                        self.logger.info(f"Found existing issue (offline): {issue['key']} - {issue_summary}")
                        return issue
            
            self.logger.debug(f"No existing issue found for defect ID: {defect_id} (searched {len(self._cached_issues)} issues)")
            return None
            
        except Exception as e:
            self.logger.error(f"Unexpected error during offline search: {str(e)}")
            return None
    
    def create_issue(self, bug_data: Dict[str, Any]) -> Optional[str]:
        """Create a new JIRA issue from bug data using the proven working format."""
        try:
            # Get bug template from config
            bug_template = self.config.get('bug_template', {})
            
            # Extract defect ID for the summary
            defect_id = bug_data.get('defect_id', '')
            original_summary = bug_data.get('summary', 'No summary provided')
            
            # Create issue summary with QC ID pattern (with # as requested)
            summary = f"QC ID# {defect_id}: {original_summary}"
            
            # Build description from all CSV columns
            description = self._build_description(bug_data)
            
            # Use the proven working issue creation format with configurable values
            jira_config = self.config.get('jira', {})
            project_name = jira_config.get('project_name', 'ASUVNG')
            epic_key = jira_config.get('epic_key', 'ASUVNG-1840')
            epic_link_field = jira_config.get('epic_link_field', 'customfield_10101')
            
            issue_data = {
                "fields": {
                    "project": {
                        "key": project_name
                    },
                    "summary": summary,
                    "description": description,
                    "issuetype": {
                        "name": bug_template.get('issue_type', 'Bug')
                    },
                    "priority": {
                        "name": "Medium"
                    },
                    epic_link_field: epic_key
                }
            }
            
            # Add assignee from CSV data or template
            assignee = bug_data.get('assign_to') or bug_template.get('assignee')
            if assignee:
                issue_data["fields"]["assignee"] = {"name": assignee}
            
            # Add reporter if specified
            reporter = bug_template.get('reporter')
            if reporter:
                issue_data["fields"]["reporter"] = {"name": reporter}
            
            # Add components if specified
            components = bug_template.get('components', [])
            if components:
                issue_data["fields"]["components"] = [{"name": comp} for comp in components]
            
            # Add labels if specified
            labels = bug_template.get('labels', [])
            if labels:
                issue_data["fields"]["labels"] = labels
            
            # Custom fields removed as requested
            
            self.logger.debug(f"Creating issue with proven format: {json.dumps(issue_data, indent=2)}")
            
            # Create the issue using the proven working format
            url = urljoin(self.base_url, '/rest/api/2/issue')
            response = self.session.post(url, json=issue_data, headers=self.headers, verify=False)
            
            if response.status_code == 201:
                result = response.json()
                issue_key = result.get('key')
                self.logger.info(f"Successfully created issue: {issue_key}")
                return issue_key
            else:
                self.logger.error(f"Issue creation failed: {response.status_code} - {response.text}")
                return None
                
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Issue creation request failed: {str(e)}")
            return None
        except Exception as e:
            self.logger.error(f"Unexpected error during issue creation: {str(e)}")
            return None
    
    def _build_description(self, bug_data: Dict[str, Any]) -> str:
        """Build detailed description from bug data."""
        description_parts = []
        
        # Add header
        description_parts.append("== Bug Details ==")
        description_parts.append("")
        
        # Add all CSV columns
        for key, value in bug_data.items():
            if value and str(value).strip():
                # Format key for display
                display_key = key.replace('_', ' ').title()
                description_parts.append(f"*{display_key}:* {value}")
        
        # Add footer
        description_parts.append("")
        description_parts.append("== Additional Information ==")
        description_parts.append("This issue was automatically created from CSV import.")
        
        return "\n".join(description_parts)
    
    def get_issue_json_for_dry_run(self, bug_data: Dict[str, Any]) -> Dict[str, Any]:
        """Generate the complete JIRA issue JSON that would be created using the proven working format."""
        # Get bug template from config
        bug_template = self.config.get('bug_template', {})
        
        # Extract defect ID for the summary
        defect_id = bug_data.get('defect_id', '')
        original_summary = bug_data.get('summary', 'No summary provided')
        
        # Create issue summary with QC ID pattern (with # as requested)
        summary = f"QC ID# {defect_id}: {original_summary}"
        
        # Build description from all CSV columns
        description = self._build_description(bug_data)
        
        # Use the proven working issue creation format for dry run with configurable values
        jira_config = self.config.get('jira', {})
        project_name = jira_config.get('project_name', 'ASUVNG')
        epic_key = jira_config.get('epic_key', 'ASUVNG-1840')
        epic_link_field = jira_config.get('epic_link_field', 'customfield_10101')
        
        issue_data = {
            "fields": {
                "project": {
                    "key": project_name
                },
                "summary": summary,
                "description": description,
                "issuetype": {
                    "name": bug_template.get('issue_type', 'Bug')
                },
                "priority": {
                    "name": "Medium"
                },
                epic_link_field: epic_key
            }
        }
        
        # Add assignee from CSV data or template
        assignee = bug_data.get('assign_to') or bug_template.get('assignee')
        if assignee:
            issue_data["fields"]["assignee"] = {"name": assignee}
        
        # Add reporter if specified
        reporter = bug_template.get('reporter')
        if reporter:
            issue_data["fields"]["reporter"] = {"name": reporter}
        
        # Add components if specified
        components = bug_template.get('components', [])
        if components:
            issue_data["fields"]["components"] = [{"name": comp} for comp in components]
        
        # Add labels if specified
        labels = bug_template.get('labels', [])
        if labels:
            issue_data["fields"]["labels"] = labels
        
        # Custom fields removed as requested
        
        # Add complete CSV data for reference
        issue_data['csv_data'] = bug_data
        
        return issue_data
    
    def get_project_info(self) -> Optional[Dict[str, Any]]:
        """Get project information for validation."""
        try:
            url = urljoin(self.base_url, f'/rest/api/2/project/{self.project_key}')
            response = self.session.get(url, headers=self.headers, verify=False)
            
            if response.status_code == 200:
                return response.json()
            else:
                self.logger.error(f"Failed to get project info: {response.status_code} - {response.text}")
                return None
                
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Project info request failed: {str(e)}")
            return None
    
    def get_issue_types(self) -> List[Dict[str, Any]]:
        """Get available issue types for the project."""
        try:
            url = urljoin(self.base_url, f'/rest/api/2/project/{self.project_key}')
            response = self.session.get(url, headers=self.headers, verify=False)
            
            if response.status_code == 200:
                project_info = response.json()
                return project_info.get('issueTypes', [])
            else:
                self.logger.error(f"Failed to get issue types: {response.status_code} - {response.text}")
                return []
                
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Issue types request failed: {str(e)}")
            return []
