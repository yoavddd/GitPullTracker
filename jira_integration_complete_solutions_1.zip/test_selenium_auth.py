"""
Test Selenium-based Jira Authentication
"""

import logging
from selenium_jira_auth import SeleniumJiraIntegrator

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)s | %(message)s'
)

def test_selenium_authentication():
    """Test Selenium authentication with your corporate Jira"""
    
    # Configuration for your corporate Jira
    jira_config = {
        'url': 'https://jira.esl.corp.elbit.co.il',
        'username': 'your-corporate-username',  # Replace with your username
        'password': 'your-corporate-password',  # Replace with your password
        'project_key': 'YOUR_PROJECT_KEY',      # Replace with your project key
        'verify_ssl': False  # Set to True if you have proper SSL certificates
    }
    
    print("=== Testing Selenium-based Jira Authentication ===")
    print(f"Jira URL: {jira_config['url']}")
    print(f"Username: {jira_config['username']}")
    print("Password: [HIDDEN]")
    print()
    
    try:
        # Create integrator
        integrator = SeleniumJiraIntegrator(jira_config)
        
        print("1. Attempting authentication...")
        if integrator.authenticate():
            print("✅ Authentication successful!")
            
            print("\n2. Testing project access...")
            project_info = integrator.get_project_info(jira_config['project_key'])
            if project_info:
                print(f"✅ Project access successful!")
                print(f"Project Name: {project_info.get('name', 'Unknown')}")
                print(f"Project Key: {project_info.get('key', 'Unknown')}")
            else:
                print("❌ Project access failed")
            
            print("\n3. Testing issue search...")
            issues = integrator.search_issues(f"project = {jira_config['project_key']}", max_results=5)
            print(f"✅ Found {len(issues)} issues in project")
            
            if issues:
                print("Sample issues:")
                for issue in issues[:3]:
                    print(f"  - {issue.get('key', 'Unknown')}: {issue.get('fields', {}).get('summary', 'No summary')}")
            
            print("\n4. Testing issue creation (DRY RUN)...")
            test_issue = {
                "fields": {
                    "project": {"key": jira_config['project_key']},
                    "summary": "Selenium Test Issue - DO NOT USE",
                    "description": "This is a test issue created by Selenium authentication. Please delete.",
                    "issuetype": {"name": "Bug"},
                    "priority": {"name": "Low"}
                }
            }
            
            print("Issue creation test would work with this data:")
            print(f"Project: {jira_config['project_key']}")
            print("Summary: Selenium Test Issue")
            print("Issue Type: Bug")
            print("✅ Ready for production use!")
            
        else:
            print("❌ Authentication failed")
            print("\nTroubleshooting tips:")
            print("1. Check your username and password")
            print("2. Verify the Jira URL is correct")
            print("3. Make sure you can log in manually in a browser")
            print("4. Check if your account has API access permissions")
            
    except Exception as e:
        print(f"❌ Test failed with error: {e}")
        print("\nPlease check:")
        print("1. Chrome browser is installed")
        print("2. Your credentials are correct")
        print("3. Network connectivity to Jira")

if __name__ == "__main__":
    test_selenium_authentication()