import requests
import logging
import base64
from typing import List, Dict, Optional
from datetime import datetime
import json

class TFSClient:
    """
    Client for interacting with TFS Azure DevOps API to retrieve pull requests
    """
    
    def __init__(self, tfs_url: str, token: str, demo_mode: bool = False):
        self.tfs_url = tfs_url.rstrip('/')
        self.token = token
        self.demo_mode = demo_mode
        self.logger = logging.getLogger('tfs_api')
        self.pr_logger = logging.getLogger('pr_extraction')
        
        # Parse TFS URL to extract components
        self._parse_tfs_url()
        
        # Set up authentication headers
        self.headers = {
            'Authorization': f'Basic {base64.b64encode(f":{token}".encode()).decode()}',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        
        self.logger.info(f"Initialized TFS client for: {self.tfs_url}")
        self.logger.debug(f"Organization: {self.organization}, Project: {self.project}, Repository: {self.repository}")
        if demo_mode:
            self.logger.warning("TFS Client running in DEMO MODE - will return mock data")
    
    def _parse_tfs_url(self):
        """
        Parse TFS URL to extract organization, project, and repository information
        """
        try:
            # Example URL: http://tfs1:8080/tfs/SilverArrowCollection/VMSC_App/_git/IAFHalcon
            url_parts = self.tfs_url.split('/')
            
            # Find the TFS collection and project
            tfs_index = -1
            for i, part in enumerate(url_parts):
                if part.lower() == 'tfs':
                    tfs_index = i
                    break
            
            if tfs_index == -1:
                raise ValueError("Could not find 'tfs' in URL")
            
            self.organization = url_parts[tfs_index + 1]  # SilverArrowCollection
            self.project = url_parts[tfs_index + 2]       # VMSC_App
            
            # Extract repository name
            if '_git' in url_parts:
                git_index = url_parts.index('_git')
                self.repository = url_parts[git_index + 1]  # IAFHalcon
            else:
                self.repository = self.project
            
            # Build base API URL
            self.base_url = f"{'/'.join(url_parts[:tfs_index + 1])}/{self.organization}/{self.project}/_apis"
            
            self.logger.debug(f"Parsed TFS URL - Organization: {self.organization}, Project: {self.project}, Repository: {self.repository}")
            self.logger.debug(f"Base API URL: {self.base_url}")
            
        except Exception as e:
            self.logger.error(f"Error parsing TFS URL '{self.tfs_url}': {str(e)}")
            raise
    
    def test_connection(self) -> bool:
        """
        Test connection to TFS API
        """
        try:
            self.logger.info("Testing TFS API connection...")
            
            # Try to get repository information
            url = f"{self.base_url}/git/repositories/{self.repository}"
            self.logger.debug(f"Testing connection with URL: {url}")
            
            response = requests.get(url, headers=self.headers, timeout=30)
            
            if response.status_code == 200:
                repo_info = response.json()
                self.logger.info(f"Successfully connected to TFS. Repository: {repo_info.get('name', 'Unknown')}")
                return True
            else:
                self.logger.error(f"TFS connection test failed. Status: {response.status_code}, Response: {response.text}")
                return False
                
        except Exception as e:
            self.logger.error(f"Error testing TFS connection: {str(e)}")
            return False
    
    def get_pull_requests_in_commit_range(self, from_commit: str, to_commit: str, repository_name: Optional[str] = None) -> List[Dict]:
        """
        Get pull requests that were merged between two commits
        """
        repo_name = repository_name or self.repository
        self.pr_logger.info(f"Retrieving pull requests for repository '{repo_name}' between commits: {from_commit} -> {to_commit}")
        
        # Return mock data in demo mode
        if self.demo_mode:
            self.pr_logger.warning(f"DEMO MODE: Returning mock pull request data for repository '{repo_name}'")
            return self._get_mock_pull_requests(repo_name, from_commit, to_commit)
        
        try:
            # Get all pull requests for the repository
            all_prs = self._get_all_pull_requests(repo_name)
            self.pr_logger.debug(f"Found {len(all_prs)} total pull requests in repository '{repo_name}'")
            
            # Filter PRs that were merged in the commit range
            merged_prs = []
            
            for pr in all_prs:
                if pr.get('status') == 'completed' and pr.get('mergeStatus') == 'succeeded':
                    merge_commit = pr.get('lastMergeCommit', {}).get('commitId')
                    if merge_commit:
                        if self._is_commit_in_range(merge_commit, from_commit, to_commit, repo_name):
                            merged_prs.append(self._format_pull_request(pr))
                            self.pr_logger.debug(f"PR #{pr['pullRequestId']} merged in range: {pr['title']}")
            
            self.pr_logger.info(f"Found {len(merged_prs)} pull requests merged in commit range")
            return merged_prs
            
        except Exception as e:
            self.pr_logger.error(f"Error retrieving pull requests for repository '{repo_name}': {str(e)}")
            if self.demo_mode:
                self.pr_logger.warning("Falling back to mock data due to connection error")
                return self._get_mock_pull_requests(repo_name, from_commit, to_commit)
            return []
    
    def _get_all_pull_requests(self, repository_name: str) -> List[Dict]:
        """
        Get all pull requests for a repository with improved error handling
        """
        try:
            # Try multiple API endpoint variations to handle different TFS versions
            endpoints = [
                f"{self.base_url}/git/repositories/{repository_name}/pullrequests",
                f"{self.base_url}/git/repositories/{repository_name}/pullRequests",
                f"{self.base_url}/git/pullrequests?repositoryId={repository_name}"
            ]
            
            params = {
                'api-version': '6.0',
                'searchCriteria.status': 'all',
                '$top': 1000
            }
            
            for url in endpoints:
                try:
                    self.logger.debug(f"Trying pull request endpoint: {url}")
                    
                    response = requests.get(url, headers=self.headers, params=params, timeout=60)
                    
                    if response.status_code == 200:
                        data = response.json()
                        prs = data.get('value', [])
                        self.logger.info(f"Successfully retrieved {len(prs)} pull requests from: {url}")
                        return prs
                    elif response.status_code == 404:
                        self.logger.debug(f"Endpoint not found (404): {url}")
                        continue
                    else:
                        self.logger.warning(f"Failed endpoint {url}. Status: {response.status_code}")
                        continue
                        
                except requests.exceptions.RequestException as e:
                    self.logger.debug(f"Request failed for {url}: {str(e)}")
                    continue
            
            # If all endpoints fail, log error and return empty list
            self.logger.error("All pull request API endpoints failed. Check repository name and permissions.")
            return []
                
        except Exception as e:
            self.logger.error(f"Error fetching pull requests: {str(e)}")
            return []
    
    def _is_commit_in_range(self, commit_hash: str, from_commit: str, to_commit: str, repository_name: str) -> bool:
        """
        Check if a commit is in the specified range by getting all commits between from_commit and to_commit
        """
        try:
            # IMPROVED: Get all commits in the range and check if our commit is among them
            commits_in_range = self._get_commits_in_range(from_commit, to_commit, repository_name)
            
            # Check if commit_hash is in the list of commits between from_commit and to_commit
            for commit in commits_in_range:
                if commit.get('commitId') == commit_hash:
                    self.logger.debug(f"Commit {commit_hash[:8]} found in range {from_commit[:8]}..{to_commit[:8]}")
                    return True
            
            self.logger.debug(f"Commit {commit_hash[:8]} NOT found in range {from_commit[:8]}..{to_commit[:8]}")
            return False
            
        except Exception as e:
            self.logger.debug(f"Error checking if commit {commit_hash} is in range: {str(e)}")
            return False
    
    def _get_commits_in_range(self, from_commit: str, to_commit: str, repository_name: str) -> List[Dict]:
        """
        Get all commits between from_commit and to_commit with improved error handling
        """
        try:
            # Try different API endpoint patterns for TFS compatibility
            endpoints = [
                f"{self.base_url}/git/repositories/{repository_name}/commits",
                f"{self.base_url}/git/commits?repositoryId={repository_name}"
            ]
            
            # Try different parameter patterns
            param_patterns = [
                {
                    'api-version': '6.0',
                    'searchCriteria.fromCommitId': from_commit,
                    'searchCriteria.toCommitId': to_commit,
                    '$top': 1000
                },
                {
                    'api-version': '5.1',
                    'searchCriteria.fromCommitId': from_commit,
                    'searchCriteria.toCommitId': to_commit,
                    '$top': 1000
                },
                {
                    'api-version': '6.0',
                    'fromCommitId': from_commit,
                    'toCommitId': to_commit,
                    '$top': 1000
                }
            ]
            
            for url in endpoints:
                for params in param_patterns:
                    try:
                        self.logger.debug(f"Trying commits endpoint: {url} with params: {params}")
                        
                        response = requests.get(url, headers=self.headers, params=params, timeout=60)
                        
                        if response.status_code == 200:
                            data = response.json()
                            commits = data.get('value', [])
                            self.logger.info(f"Successfully found {len(commits)} commits between {from_commit[:8]} and {to_commit[:8]}")
                            return commits
                        elif response.status_code == 404:
                            self.logger.debug(f"Commits endpoint not found (404): {url}")
                            break  # Try next URL
                        else:
                            self.logger.debug(f"Commits endpoint failed: {response.status_code}")
                            continue  # Try next parameter pattern
                            
                    except requests.exceptions.RequestException as e:
                        self.logger.debug(f"Request failed for commits endpoint: {str(e)}")
                        continue
            
            self.logger.warning(f"All commits API endpoints failed for range {from_commit[:8]}..{to_commit[:8]}")
            return []
                
        except Exception as e:
            self.logger.error(f"Error getting commits in range: {str(e)}")
            return []
    
    def _get_commit_date(self, commit_hash: str, repository_name: str) -> Optional[datetime]:
        """
        Get the date of a specific commit
        """
        try:
            url = f"{self.base_url}/git/repositories/{repository_name}/commits/{commit_hash}"
            params = {'api-version': '6.0'}
            
            response = requests.get(url, headers=self.headers, params=params, timeout=30)
            
            if response.status_code == 200:
                commit_data = response.json()
                return datetime.fromisoformat(commit_data['committer']['date'].replace('Z', '+00:00'))
            
            return None
            
        except Exception as e:
            self.logger.debug(f"Error getting commit date for {commit_hash}: {str(e)}")
            return None
    
    def _check_commit_ancestry(self, commit_hash: str, from_commit: str, to_commit: str, repository_name: str) -> bool:
        """
        Check commit ancestry using TFS API (simplified approach)
        """
        try:
            # Get commits between from_commit and to_commit
            url = f"{self.base_url}/git/repositories/{repository_name}/commits"
            params = {
                'api-version': '6.0',
                'searchCriteria.fromCommitId': from_commit,
                'searchCriteria.toCommitId': to_commit,
                '$top': 1000
            }
            
            response = requests.get(url, headers=self.headers, params=params, timeout=60)
            
            if response.status_code == 200:
                data = response.json()
                commits = data.get('value', [])
                
                # Check if our commit is in the list
                for commit in commits:
                    if commit.get('commitId') == commit_hash:
                        return True
            
            return False
            
        except Exception as e:
            self.logger.debug(f"Error checking commit ancestry: {str(e)}")
            return False
    
    def _format_pull_request(self, pr_data: Dict) -> Dict:
        """
        Format pull request data for output with Unicode handling
        """
        def safe_text(text):
            """Safely handle Unicode characters that might cause encoding issues"""
            if not text:
                return ''
            # Replace problematic Unicode characters with safe alternatives
            return str(text).encode('ascii', 'ignore').decode('ascii')
        
        return {
            'id': pr_data.get('pullRequestId'),
            'title': safe_text(pr_data.get('title', '')),
            'description': safe_text(pr_data.get('description', '')),
            'created_by': safe_text(pr_data.get('createdBy', {}).get('displayName', '')),
            'created_date': pr_data.get('creationDate', ''),
            'completed_date': pr_data.get('closedDate', ''),
            'source_branch': pr_data.get('sourceRefName', '').replace('refs/heads/', ''),
            'target_branch': pr_data.get('targetRefName', '').replace('refs/heads/', ''),
            'merge_commit': pr_data.get('lastMergeCommit', {}).get('commitId', ''),
            'status': pr_data.get('status', ''),
            'url': pr_data.get('webUrl', ''),
            'repository': pr_data.get('repository', {}).get('name', self.repository)
        }
    
    def _get_mock_pull_requests(self, repository_name: str, from_commit: str, to_commit: str) -> List[Dict]:
        """
        Generate mock pull request data for demo purposes
        """
        self.pr_logger.debug(f"Generating mock pull request data for repository '{repository_name}'")
        
        import random
        from datetime import datetime, timedelta
        
        # Generate 1-3 mock PRs per repository
        num_prs = random.randint(1, 3)
        mock_prs = []
        
        base_date = datetime.now() - timedelta(days=30)
        
        for i in range(num_prs):
            pr_id = 1000 + i + hash(repository_name) % 1000
            mock_pr = {
                'id': pr_id,
                'title': f'Feature implementation for {repository_name} #{i+1}',
                'description': f'Implements new functionality in {repository_name}. This PR includes code improvements, bug fixes, and enhanced features to improve system performance and user experience.',
                'created_by': f'Developer{i+1}',
                'created_date': (base_date + timedelta(days=i*5)).isoformat(),
                'completed_date': (base_date + timedelta(days=i*5+2)).isoformat(),
                'source_branch': f'feature/mock-feature-{i+1}',
                'target_branch': 'main',
                'merge_commit': f'abc{i}def{random.randint(100,999)}',
                'status': 'completed',
                'url': f'{self.tfs_url}/pullrequest/{pr_id}',
                'repository': repository_name
            }
            mock_prs.append(mock_pr)
            self.pr_logger.debug(f"Generated mock PR #{pr_id}: {mock_pr['title']}")
        
        return mock_prs

    def get_submodule_repository_name(self, submodule_url: str) -> Optional[str]:
        """
        Extract repository name from submodule URL
        """
        try:
            if '_git' in submodule_url:
                # Extract repository name from URL like: http://tfs1:8080/tfs/SilverArrowCollection/VMSC_App/_git/SubmoduleRepo
                parts = submodule_url.split('/')
                if '_git' in parts:
                    git_index = parts.index('_git')
                    if git_index + 1 < len(parts):
                        repo_name = parts[git_index + 1]
                        self.logger.debug(f"Extracted repository name '{repo_name}' from URL: {submodule_url}")
                        return repo_name
            
            # Fallback: try to extract from the end of URL
            repo_name = submodule_url.rstrip('/').split('/')[-1]
            if repo_name and repo_name != '_git':
                self.logger.debug(f"Fallback extracted repository name '{repo_name}' from URL: {submodule_url}")
                return repo_name
            
            self.logger.warning(f"Could not extract repository name from URL: {submodule_url}")
            return None
            
        except Exception as e:
            self.logger.error(f"Error extracting repository name from URL '{submodule_url}': {str(e)}")
            return None
