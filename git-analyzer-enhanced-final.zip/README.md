# Git Submodule Pull Request Analyzer - Setup Guide

## Overview
This tool analyzes Git repository submodule pointer changes between commits and extracts merged pull requests from Team Foundation Server (TFS) Azure DevOps.

## What You'll Get
- **Source Files**: 6 Python files that make up the complete application
- **Configuration**: JSON file to set your TFS server and repository details
- **Reports**: CSV tables, summary reports, and JSON exports of pull request data
- **Logs**: Detailed logging for troubleshooting

## Quick Start (For Beginners)

### Step 1: Download All Source Files
You need to download these 6 files to your computer:

1. **main.py** - Main application file
2. **git_analyzer.py** - Git repository analysis
3. **tfs_client.py** - TFS/Azure DevOps connection
4. **report_generator.py** - Report creation
5. **logger_config.py** - Logging setup
6. **config.json** - Configuration settings

### Step 2: Install Python (if not already installed)
1. Go to https://www.python.org/downloads/
2. Download Python 3.8 or newer
3. Run the installer and check "Add Python to PATH"

### Step 3: Install Required Libraries
Open Command Prompt (Windows) or Terminal (Mac/Linux) and run:
```bash
pip install GitPython requests pandas colorlog tabulate
```

### Step 4: Configure Your Settings
Edit the `config.json` file with your details:

```json
{
    "tfs_url": "http://your-tfs-server:8080/tfs/YourCollection/YourProject/_git/YourRepo",
    "tfs_token": "your-personal-access-token-here",
    "repository_path": "C:\\path\\to\\your\\git\\repository",
    "from_commit": "abc123def456",
    "to_commit": "def456ghi789",
    "output_directory": "./output",
    "log_level": "INFO"
}
```

**How to get your TFS token:**
1. Log into your TFS/Azure DevOps
2. Go to User Settings > Personal Access Tokens
3. Create new token with "Code (read)" permissions
4. Copy the token to `config.json`

### Step 5: Run the Application
Open Command Prompt in the folder with your files and run:
```bash
python main.py
```

## File Descriptions

### Core Application Files
- **main.py**: Entry point that coordinates everything
- **git_analyzer.py**: Analyzes Git repository and finds submodule changes
- **tfs_client.py**: Connects to TFS and gets pull request data
- **report_generator.py**: Creates CSV tables and summary reports
- **logger_config.py**: Sets up detailed logging system

### Configuration File
- **config.json**: Contains all your settings (TFS server, repository path, commits to analyze)

## Output Files You'll Get

### Reports
- **super_project_prs_[timestamp].csv**: Pull requests for main project
- **submodule_[name]_prs_[timestamp].csv**: Pull requests for each submodule
- **combined_summary_[timestamp].txt**: Overview of all findings
- **analysis_data_[timestamp].json**: All data in JSON format

### Logs (for troubleshooting)
- **git_analyzer_[timestamp].log**: Main application log
- **git_diff_[timestamp].log**: Git analysis details
- **submodule_processing_[timestamp].log**: Submodule processing
- **tfs_api_[timestamp].log**: TFS server communication
- **pr_extraction_[timestamp].log**: Pull request extraction

## Common Issues and Solutions

### "Repository path does not exist"
- Check that `repository_path` in config.json points to a valid Git repository
- Use forward slashes (/) or double backslashes (\\\\) in Windows paths

### "Failed to connect to TFS"
- Verify your `tfs_url` is correct
- Check that your `tfs_token` has proper permissions
- Make sure you can access the TFS server from your computer

### "No submodule changes detected"
- This is normal if there are no submodule pointer changes between commits
- The tool will still analyze the super project pull requests

### "Module not found" errors
- Run the pip install command again: `pip install GitPython requests pandas colorlog tabulate`

## Advanced Usage

### Command Line Options
```bash
python main.py --config custom_config.json --output-dir ./my_output --log-level DEBUG
```

### Demo Mode (for testing without TFS)
Add to config.json:
```json
{
    "demo_mode": true,
    "skip_tfs_connection": true
}
```

## How It Works
1. **Reads Configuration**: Loads your TFS server and repository settings
2. **Analyzes Git Repository**: Compares two commits to find submodule changes
3. **Connects to TFS**: Gets pull request data for the specified commit range
4. **Processes Submodules**: For each changed submodule, gets its pull requests
5. **Generates Reports**: Creates CSV tables and summary reports
6. **Saves Results**: All output goes to the specified output directory

## Support
If you encounter issues:
1. Check the log files in the `output/logs` directory
2. Make sure all configuration settings are correct
3. Verify your TFS token has proper permissions
4. Ensure the Git repository path is accessible

## File Structure After Setup
```
your-project-folder/
├── main.py
├── git_analyzer.py
├── tfs_client.py
├── report_generator.py
├── logger_config.py
├── config.json
└── output/
    ├── super_project_prs_[timestamp].csv
    ├── combined_summary_[timestamp].txt
    ├── analysis_data_[timestamp].json
    └── logs/
        ├── git_analyzer_[timestamp].log
        ├── git_diff_[timestamp].log
        ├── submodule_processing_[timestamp].log
        ├── tfs_api_[timestamp].log
        └── pr_extraction_[timestamp].log
```

This tool is ready to use and will help you track pull requests across your Git submodules efficiently!