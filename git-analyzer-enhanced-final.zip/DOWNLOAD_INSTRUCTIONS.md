# How to Download All Source Files

## Method 1: Download Individual Files (Easiest)

### Files You Need to Download:
Right-click each file and "Save As" to your computer:

1. **main.py** - Main application 
2. **git_analyzer.py** - Git analysis engine
3. **tfs_client.py** - TFS server connection
4. **report_generator.py** - Report creation
5. **logger_config.py** - Logging system
6. **config.json** - Your settings
7. **README.md** - Complete setup guide
8. **setup.bat** - Windows setup helper (optional)

### Put All Files in Same Folder
Create a new folder on your computer (like "git-analyzer") and put all 8 files there.

## Method 2: Copy and Paste Files

If you can't download directly, you can copy the content of each file:

1. **Click on each file name** in the file list
2. **Select All** (Ctrl+A) the file content  
3. **Copy** (Ctrl+C) the content
4. **Create a new file** on your computer with the same name
5. **Paste** (Ctrl+V) the content
6. **Save** the file

Repeat for all 8 files.

## After Downloading

1. **Install Python** if you don't have it: https://www.python.org/downloads/
2. **Run setup.bat** (Windows) or install libraries manually:
   ```
   pip install GitPython requests pandas colorlog tabulate
   ```
3. **Edit config.json** with your TFS server details
4. **Run the application**:
   ```
   python main.py
   ```

## What Each File Does

| File | Purpose |
|------|---------|
| main.py | Starts the application and coordinates everything |
| git_analyzer.py | Analyzes your Git repository for submodule changes |
| tfs_client.py | Connects to your TFS server to get pull request data |
| report_generator.py | Creates CSV tables and summary reports |
| logger_config.py | Sets up detailed logging for troubleshooting |
| config.json | Your settings (TFS server, repository path, commits) |
| README.md | Complete setup and usage guide |
| setup.bat | Windows helper script to install libraries |

## Quick Test
After setup, you can test with demo mode by adding this to config.json:
```json
{
    "demo_mode": true,
    "skip_tfs_connection": true
}
```

This will run without connecting to TFS and show you how the reports look.

## Need Help?
Check README.md for detailed instructions and troubleshooting tips!