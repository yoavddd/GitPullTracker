# Git Submodule Pull Request Analyzer - Enhanced Package

## Package Contents (16 Files) - NEW FEATURES ADDED!

### Core Application Files (5 files)
1. **main.py** (9.5 KB) - Main application entry point
2. **git_analyzer.py** (12.1 KB) - Git repository analysis engine
3. **tfs_client.py** (14.6 KB) - TFS Azure DevOps API client
4. **report_generator.py** (15.4 KB) - Report generation system
5. **logger_config.py** (3.9 KB) - Comprehensive logging setup

### Configuration Files (3 files)
6. **config.json** (375 B) - Application configuration template (updated for real TFS connection)
7. **config_demo_combined.json** (NEW!) - Demo configuration for testing combined output
8. **package_requirements.txt** (79 B) - Python library dependencies

### Documentation (5 files)
9. **README.md** (5.6 KB) - Complete setup and usage guide
10. **BEGINNER_GUIDE.md** (7.1 KB) - Step-by-step tutorial for beginners
11. **SIMPLE_TEST_EXAMPLE.md** (4.9 KB) - Easy test instructions
12. **DOWNLOAD_INSTRUCTIONS.md** (2.3 KB) - Simple download instructions
13. **PACKAGE_CONTENTS.md** (4.4 KB) - What each file does

### Helper Scripts (3 files)
14. **setup.bat** (555 B) - Windows automatic setup script
15. **run.bat** (534 B) - Easy Windows launcher
16. **test_demo.bat** (1.8 KB) - Demo test runner

## Total Package Size: ~76 KB

## 🆕 NEW FEATURES ADDED

### ✓ Combined Output File
- **all_pull_requests_[timestamp].csv** - Single file with ALL pull requests (super project + submodules)
- Includes Repository column to identify source
- Sorted by creation date for better organization

### ✓ Enhanced Real Data Support
- Updated config.json for real TFS connection (no demo mode)
- Improved error handling for missing commits
- Better pull request title extraction from TFS

### ✓ Improved Output Organization
- Now generates 5 output files instead of 4:
  1. Super project PRs (separate file)
  2. Individual submodule PRs (separate files)
  3. **Combined ALL PRs (NEW!)** 
  4. Summary report (text)
  5. JSON export (complete data)

## Quick Start Instructions

### For Windows Users:
1. Download all 13 files to a folder
2. Double-click `setup.bat` to install dependencies
3. Edit `config.json` with your settings
4. Double-click `run.bat` to run the analyzer

### For Mac/Linux Users:
1. Download all 13 files to a folder
2. Run: `pip install -r package_requirements.txt`
3. Edit `config.json` with your settings
4. Run: `python main.py`

### For Testing/Demo:
1. Download all files
2. Double-click `test_demo.bat` (Windows) or run the demo commands manually
3. This creates a test repository and runs in demo mode

## What Each File Does

| File | Purpose | Size |
|------|---------|------|
| main.py | Orchestrates the entire analysis process | 9.5 KB |
| git_analyzer.py | Analyzes Git repositories for submodule changes | 12.1 KB |
| tfs_client.py | Connects to TFS/Azure DevOps to get pull requests | 14.6 KB |
| report_generator.py | Creates CSV, text, and JSON reports | 15.4 KB |
| logger_config.py | Sets up detailed logging system | 3.9 KB |
| config.json | Your TFS server and repository settings | 375 B |
| package_requirements.txt | List of Python libraries needed | 79 B |
| README.md | Detailed setup and usage instructions | 5.6 KB |
| BEGINNER_GUIDE.md | Step-by-step tutorial for beginners | 7.1 KB |
| DOWNLOAD_INSTRUCTIONS.md | Simple download guide | 2.3 KB |
| setup.bat | Automatic setup for Windows | 555 B |
| run.bat | Easy launcher for Windows | 534 B |
| test_demo.bat | Demo test runner for Windows | 1.8 KB |

## Features Included

✓ **JSON Configuration** - All settings in one file
✓ **Git Repository Analysis** - Detects submodule pointer changes
✓ **TFS Integration** - Extracts pull requests from Azure DevOps
✓ **Multiple Report Formats** - CSV, text summaries, JSON exports
✓ **Comprehensive Logging** - 5 separate log files for troubleshooting
✓ **Demo Mode** - Test without TFS connection
✓ **Error Handling** - Robust error handling and recovery
✓ **Cross-Platform** - Works on Windows, Mac, and Linux
✓ **Beginner-Friendly** - Complete documentation and helper scripts

## System Requirements

- **Python 3.8+** (Download from python.org)
- **Git** (Usually already installed)
- **Internet Access** (to connect to TFS server)
- **5 Python Libraries** (automatically installed by setup.bat):
  - GitPython (Git operations)
  - requests (HTTP client for TFS API)
  - pandas (Data manipulation)
  - colorlog (Colored console output)
  - tabulate (Table formatting)

## Output Files Generated

When you run the analyzer, it creates:

### Reports Directory (./output/)
- `super_project_prs_[timestamp].csv` - Main project pull requests
- `submodule_[name]_prs_[timestamp].csv` - Each submodule's pull requests
- `combined_summary_[timestamp].txt` - Human-readable summary
- `analysis_data_[timestamp].json` - Complete data export

### Logs Directory (./output/logs/)
- `git_analyzer_[timestamp].log` - Main application log
- `git_diff_[timestamp].log` - Git analysis details
- `submodule_processing_[timestamp].log` - Submodule processing
- `tfs_api_[timestamp].log` - TFS API interactions
- `pr_extraction_[timestamp].log` - Pull request extraction

This complete package provides everything needed to analyze Git submodule changes and extract pull request data from TFS Azure DevOps!