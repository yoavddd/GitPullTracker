# JIRA Bug Creation Tool

A comprehensive Python command-line tool for processing CSV bug data and creating JIRA issues with duplicate checking and extensive logging.

## Features

- **Dual-Mode Operation**: Add new bugs or update existing ones based on CSV data
- **CSV Processing**: Parse CSV files containing bug data with flexible column mapping
- **JIRA Integration**: Full JIRA REST API integration with Basic Authentication
- **Duplicate Prevention**: Automatic checking for existing bugs using "QC ID" pattern matching (offline search for better performance)
- **Smart Transformations**: Automatic status mapping and assignee email transformation
- **Batch Processing**: Process multiple bugs efficiently with error handling
- **Comprehensive Logging**: Detailed logging for debugging and monitoring
- **Configuration Management**: JSON-based configuration with environment variable support
- **Epic Integration**: Automatically link created bugs to specified epics
- **Dry Run Mode**: Test functionality without creating actual JIRA issues

## Installation

1. **Extract the deployment ZIP** to your desired directory
2. **Install required Python packages**:
   ```bash
   pip install requests pandas
   ```

3. **Optional: Create a virtual environment**:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   pip install requests pandas
   ```

## Configuration

### 1. Edit config.json

Update the configuration file with your JIRA instance details:

```json
{
  "jira": {
    "url": "https://your-jira-instance.com",
    "username": "your-username",
    "password": "your-password",
    "project_key": "YOUR_PROJECT",
    "epic_key": "YOUR_EPIC_KEY",
    "structure_board_id": "5062"
  },
  "bug_template": {
    "issue_type": "Bug",
    "priority": "Medium",
    "assignee": "default-assignee",
    "reporter": "default-reporter",
    "components": ["Component1", "Component2"],
    "labels": ["automated-import", "qc-bug"],
    "custom_fields": {
      "customfield_10100": "QC Import"
    }
  }
}

## Usage

### Command Line Parameters

The tool supports several command-line parameters:

```bash
python main.py --csv-file <CSV_FILE> --config-file <CONFIG_FILE> [OPTIONS]
```

**Required Parameters:**
- `--csv-file` : Path to your CSV file containing bug data
- `--config-file` : Path to your JSON configuration file
- `--mode` : Operation mode - 'add' (create new bugs) or 'update' (update existing bugs)

**Optional Parameters:**
- `--log-level` : Set logging level (DEBUG, INFO, WARNING, ERROR) - default: INFO
- `--dry-run` : Test mode - shows what would be created/updated without actually modifying bugs
- `--skip-connection-test` : Skip JIRA connection test (useful for offline CSV validation)

### Usage Examples

**Mode 1 - Add New Bugs:**
```bash
# Basic usage - create new bugs
python main.py --csv-file bugs.csv --config-file config.json --mode add

# Dry run - test bug creation without actually creating
python main.py --csv-file bugs.csv --config-file config.json --mode add --dry-run

# Test with sample data
python main.py --csv-file sample_bugs.csv --config-file config.json --mode add --dry-run
```

**Mode 2 - Update Existing Bugs:**
```bash
# Basic usage - update existing bugs
python main.py --csv-file bugs.csv --config-file config.json --mode update

# Dry run - test bug updates without actually updating
python main.py --csv-file bugs.csv --config-file config.json --mode update --dry-run
```

**Other Examples:**
```bash
# Offline CSV validation
python main.py --csv-file bugs.csv --config-file config.json --mode add --dry-run --skip-connection-test

# Debug mode with detailed logging
python main.py --csv-file bugs.csv --config-file config.json --mode add --log-level DEBUG
```

### Smart Transformations

The tool automatically applies smart transformations to your CSV data:

**Status Mapping (CSV → JIRA):**
- `New` or `Open` → `TO DO`
- `Cancelled` → `CANCELLED`
- `Fixed` → `READY FOR TESTING`
- `Closed` → `DONE`

**Assignee Transformation:**
- `"dolis yoav"` → `"yoav.dolis@elbs.com"`
- `"John Doe"` → `"doe.john@elbs.com"`
- Automatically converts names to firstname.lastname@elbs.com format

**Mode Differences:**
- **Add Mode**: Uses "QC ID {defect_id}" pattern for duplicate checking
- **Update Mode**: Uses "QC ID# {defect_id}" pattern to find existing bugs
- **Update Mode**: Handles JIRA workflow transitions (goes through IN PROGRESS if needed)
